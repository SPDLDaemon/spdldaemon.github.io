/****************************************************************************
 Module
   SMTransmit.c

 Description
   This module implements a state machine to transmit asynchronous UART
	communication using the ZigBee API Frame with ME218C 2011 Communication
	Committee's official protocol (see documentation in ME218C 2011 Final
	Project).

 Notes
	Changes from Ed's State Machine structure include:
		Removal of recursive function calling on state transitions
		Removal of startSM function (module variable is simply initialized)
		Removal of during functions (Actions to events are called in switch)

 History
 When           Who     What/Why
 -------------- ---     --------
 05/07/11  		ery      First Pass

****************************************************************************/

/*----------------------------- Include Files -----------------------------*/
/* include header files for this state machine as well as any machines at the
   next lower level in the hierarchy that are sub-machines to this machine
*/

#include "Pic16Zigbee.h"
	//#include "SMTransmit.h"
	//#include "SMEvents.h"
	//#include <htc.h>

/*----------------------------- Module Defines ----------------------------*/


/*---------------------------- Module Functions ---------------------------*/


/*---------------------------- Module Variables ---------------------------*/

// Initialize state machine in Transmit Waiting State
static TransmitState_t CurrentState = TRANSMIT_WAITING;

static unsigned int current_byte = 0;	// index for stepping though message
static unsigned int packet_length = 0;	// holds the length of the message to be sent
static unsigned char* packet_being_sent;

// Flags
static unsigned char transmit_complete_flag = FALSE;	// high when packet fully sent

/*------------------------------ Module Code ------------------------------*/
/****************************************************************************
 Function
    RunTransmitSM

 Parameters
   	Event_t: the event to process

 Returns
   Event_t: an event to return

 Description
   	Runs the Transmit Message State Machine that passes between 3 states while
	sendint out UART messages to the Zigbee.
 Notes
   	uses nested switch/case to implement the machine.
 Author
   	J. Edward Carryer, 2/11/05
	ERY, 5/7/2011
****************************************************************************/
void RunTransmitSM( Event_t CurrentEvent )
{
TransmitState_t NextState = CurrentState;

switch ( CurrentState )
{
	//----------------------------------------------------------------------
    case TRANSMIT_WAITING :  

        //process any events
        if ( CurrentEvent != EV_NO_EVENT )
        {
            switch (CurrentEvent)
            {
              	case EV_START_TRANSMIT :
					// MAKES TRANSITION: Select next state
                  	NextState = SENDING_PACKET;
					//PORTC = DEBUG_PORTC_PIN;
					
					// Actions to this event
					current_byte = 0;
					packet_length = getSendPacketLength();
					packet_being_sent = getSendPacket();
                 	break;
            }
        }
        break;

	//----------------------------------------------------------------------
    case SENDING_PACKET :
		//PORTC = DEBUG_PORTC_PIN;
        //process any events
        if ( CurrentEvent != EV_NO_EVENT )
        {
            switch (CurrentEvent)
            {
              	case EV_TRANSMIT_BUFFER_EMPTY :	
					// Actions to this event
					TXREG = packet_being_sent[current_byte];
					current_byte++;
					//PORTC = DEBUG_PORTC_PIN;

					// Check to see if the packet has more bytes to send
					if( current_byte >= (packet_length))
					{
						transmit_complete_flag = TRUE;
					}
                 	break;

              	case EV_TRANSMIT_COMPLETE :
					// MAKES TRANSITION: Select next state
                  	NextState = TRANSMIT_WAITING;
					//PORTC = DEBUG_PORTC_PIN;
                 	break;
            }
        }
        break;
} // End Switch fo States...

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
// Change state if states have been changed
    CurrentState = NextState; //Modify state variable

}



/****************************************************************************
 Function
    QueryTransmitSM

 Parameters
    None

 Returns
    ReceiveState_t The current state of the Receive 
	state machine

 Description
    returns the current state of the Receive state machine
 Notes

 Author
	J. Edward Carryer, 2/11/05
	ERY 5/7/2011
****************************************************************************/
TransmitState_t QueryTransmitSM ( void )
{
   return(CurrentState);
}

/***************************************************************************
 private functions
 ***************************************************************************/


/***************************************************************************
 more public functions
****************************************************************************/

/*--------------------------------------------------------------------------
Public Function
	isTransmitComplete

Description
    Returns the Transmit Complete Flag

Author
	ERY 5/8/2011
--------------------------------------------------------------------------*/
unsigned char isTransmitComplete(void){
	//PORTC = DEBUG_PORTC_PIN;
	if (transmit_complete_flag == TRUE)
	{
		transmit_complete_flag = FALSE;
		return TRUE;
		
	} else 
	{
		return FALSE;
	}
}