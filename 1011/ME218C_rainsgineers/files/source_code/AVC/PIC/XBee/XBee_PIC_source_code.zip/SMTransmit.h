/****************************************************************************
 Transmit header file 
 ****************************************************************************/

#ifndef SMTransmit_H
#define SMTransmit_H

//#include "SMEvents.h"
//#include <htc.h>

// Event Definitions

// typedefs for the states
// State definitions for use with the query function
typedef enum { TRANSMIT_WAITING, SENDING_PACKET } TransmitState_t ;


// Public Function Prototypes

void RunTransmitSM( Event_t CurrentEvent );
TransmitState_t QueryTransmitSM ( void );

unsigned char isTransmitComplete(void);

#endif /*SMTransmit_H */

