/****************************************************************************
 Module
   InterpretPacket.c

 Description
   Holds functions that will interpret an incoming packet after it has been
   confirmed to have a good checksum

	Receive packet will raise a goodPacketReceived event.  This module will
	hold the module variable of the 


 Notes

 History
 When           Who     What/Why
 -------------- ---     --------
 05/09/11  		ERY  	ME218C ATOLL Project

****************************************************************************/

#include "Pic16Zigbee.h"
	//#include "InterpretPacket.h"
	//#include <htc.h>
	//#include "SMEvents.h"
	//#include "218ZigbeeProtocol.h"

//------------------------------------------------------------
// FLAGS and Module Variables

// [RP]: Capture Reply from Atoll 
unsigned char atoll_capture_success_flag = FALSE;
unsigned char atoll_capture_failed_flag = FALSE;

// [C2B]: Receiving Command from the CVC 
unsigned char cvc_info = 0;
unsigned char cvc_info_flag = FALSE;

// [FTR1]: Receive Broadcast "Team Message" When Attempting to Find a Teammate
// [FTR2]: Receive Directed Reply Team Achnowledgement Message
unsigned char teammate_msb = 0;
unsigned char teammate_lsb = 0;
unsigned char teammate_searching_flag = FALSE;
unsigned char teammate_achknowleged_flag = FALSE;

// Transmit Success Message
unsigned char transmit_success_flag = FALSE;

//===========================================================================
// PUBLIC FUNCTIONS
//===========================================================================

/*------------------------------------------------------------
Function: interpretPacket

Arguments:
	unsigned char* data_received ... the array of data from Zigbee
	unsigned char data_length ... the number of elements in the array

Description:
	This function will determine what the incoming UART message
	from the Zigbee is and will save the important data to a module
	variable to be exported through a public function.  

	This function 
	also raises the appropriate flag for the event checker to be 
	alerted that a certain type of message has been received (so the right
	public function can be called to collect the data.

	NOTE:
	This function should be called in the SMReceive State Machine
	after the checksum has been confirmed.

Author:
	ERY 5/9/2011

------------------------------------------------------------*/
void interpretPacket(unsigned char* data_received, unsigned char data_length)
{
unsigned char extra_stack;
//------------------------------------------------------------
// [RP]: Capture Reply from Atoll 
	// If the command type byte in the received data is an RP Command
	if( data_received[R_DBYTE_NUM_CMD_T] == CMD_T_RP )
	{
		// If capture was a success
		if( data_received[RP_DBYTE_NUM_SF] == RP_SF_SUCCESS )
		{
			// Check Atoll # Change Error
			//if( data_received[RP_DBYTE_NUM_AN] != getAtollBytes() ){
			//	PORTC |= ERROR_PIN_RC0;	// Throw receiving error
			//}
			atoll_capture_success_flag = TRUE;
		} else
		{
			atoll_capture_failed_flag = TRUE;
		}
	}

//------------------------------------------------------------
// [C2B]: Receiving Command from the CVC 
	// If the command type byte in the received data is an RP Command
	if( data_received[R_DBYTE_NUM_CMD_T] == CMD_T_C2B )
	{
		cvc_info = data_received[C2B_DBYTE_NUM_INFO];
		//PORTC = cvc_info;
		cvc_info_flag = TRUE;
	}

//------------------------------------------------------------
// [FTR1]: Receive Broadcast "Team Message" When Attempting to Find a Teammate
// [FTR2]: Receive Directed Reply Team Achnowledgement Message
	// If the command type byte is Find Teammate Identifier, FT
	if( data_received[R_DBYTE_NUM_CMD_T] == CMD_T_FT )
	{
		// Store team color in this temporary variable
		extra_stack = getTeamColor();

		// If the signal is a broadcast
		if( (data_received[R_DBYTE_NUM_OPTIONS] & BIT1HI) != 0 )
		{
			if( data_received[FT_DBYTE_NUM_CLR] == extra_stack )
			{
				// Record teammate source address
				teammate_msb = data_received[R_DBYTE_NUM_SRC_MSB];
				teammate_lsb = data_received[R_DBYTE_NUM_SRC_LSB];
				// Raise flag to indicate teammate is searching for us
				teammate_searching_flag = TRUE;
			}
		} 
		// Else, the signal is a direct message
		else
		{
			// NOTE: could record teammate's address here, 
			//			but don't need to

			// Check to see that teamcolor is correct
			
			if( data_received[FT_DBYTE_NUM_CLR] == extra_stack )
			{
					teammate_achknowleged_flag = TRUE;
			}
		}
	}

//------------------------------------------------------------
// Transmit Success Message
	if( data_received[R_DBYTE_NUM_API_ID] == API_ID_TRANS_STAT )
	{
		if( data_received[R_DBYTE_NUM_STATUS] == TS_STATUS_SUCCESS )
		{
			transmit_success_flag = TRUE;
		}
	}
}

//===========================================================================
// PUBLIC FLAG FUNCTIONS
//===========================================================================

/*------------------------------------------------------------
Function: isPacketSuccessfulAtoll

Description:
	If flag atoll_capture_success_flag is high, 
		then returns TRUE and lowers the flag
	Else returns FALSE

Author:
	ERY 5/11/2011

------------------------------------------------------------*/
// [RP]: Capture Reply from Atoll 
unsigned char isPacketSuccessfulAtoll(void){
	if(atoll_capture_success_flag == TRUE)
	{
		atoll_capture_success_flag = FALSE;
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*------------------------------------------------------------
Function: isPacketFailedAtoll

Description:
	If flag atoll_capture_failed_flag is high, 
		then returns TRUE and lowers the flag
	Else returns FALSE

Author:
	ERY 5/11/2011

------------------------------------------------------------*/
// [RP]: Capture Reply from Atoll 
unsigned char isPacketFailedAtoll(void){
	if(atoll_capture_failed_flag == TRUE)
	{
		atoll_capture_failed_flag = FALSE;
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*------------------------------------------------------------
Function: isPacketCvcInfo

Description:
	If cvc_info_flag is high, 
		then returns TRUE and lowers the flag
	Else returns FALSE

Author:
	ERY 5/11/2011

------------------------------------------------------------*/
// [C2B]: Receiving Command from the CVC 
unsigned char isPacketCvcInfo(void){
	if(cvc_info_flag == TRUE)
	{
		cvc_info_flag = FALSE;
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*------------------------------------------------------------
Function: isPacketTeammateSearching

Description:
	If teammate_searching_flag is high, 
		then returns TRUE and lowers the flag
	Else returns FALSE

Author:
	ERY 5/11/2011

------------------------------------------------------------*/
// [FTR1]: Receive Broadcast "Team Message" When Attempting to Find a Teammate
// [FTR2]: Receive Directed Reply Team Achnowledgement Message
unsigned char isPacketTeammateSearching(void){
	if(teammate_searching_flag == TRUE)
	{
		teammate_searching_flag = FALSE;
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*------------------------------------------------------------
Function: isPacketTeammateAchknowleged

Description:
	If teammate_searching_flag is high, 
		then returns TRUE and lowers the flag
	Else returns FALSE

Author:
	ERY 5/11/2011

------------------------------------------------------------*/
// [FTR1]: Receive Broadcast "Team Message" When Attempting to Find a Teammate
// [FTR2]: Receive Directed Reply Team Achnowledgement Message
unsigned char isPacketTeammateAchknowleged(void){
	if(teammate_achknowleged_flag == TRUE)
	{
		teammate_achknowleged_flag = FALSE;
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*------------------------------------------------------------
Function: isPacketTransmitSuccess

Description:
	If transmit_success_flag is high, 
		then returns TRUE and lowers the flag
	Else returns FALSE

Author:
	ERY 5/11/2011

------------------------------------------------------------*/
// Transmit Success Message
unsigned char isPacketTransmitSuccess(void){
	if(transmit_success_flag == TRUE)
	{
		transmit_success_flag = FALSE;
		return TRUE;
	} else
	{
		return FALSE;
	}
}

//===========================================================================
// PUBLIC GET INFO FUNCTIONS
//===========================================================================

/*------------------------------------------------------------
Function: getCVCInfo

Description:
	returns the general data byte from the CVC to AVC

	* NOTE: PWM bytes right and left will be read by the
			pics PWMing the motors and not this Zigbee pic

Author:
	ERY 5/9/2011

------------------------------------------------------------*/
// [C2B]: Receiving Command from the CVC  
unsigned char getCVCInfo(void)
{
	return cvc_info;
}

/*------------------------------------------------------------
Function: getTeammateMsb

Description:
	returns the most signifigant byte of the source address
	of the ACV's teammate after teammate's signal received

Author:
	ERY 5/11/2011

------------------------------------------------------------*/
// [C2B]: Receiving Command from the CVC  
unsigned char getTeammateMsb(void)
{
	return teammate_msb;
}

/*------------------------------------------------------------
Function: getTeammateLsb

Description:
	returns the least signifigant byte of the source address
	of the ACV's teammate after teammate's signal received

Author:
	ERY 5/11/2011

------------------------------------------------------------*/
// [C2B]: Receiving Command from the CVC  
unsigned char getTeammateLsb(void)
{
	return teammate_lsb;
}