/****************************************************************************
 Module
   	SMReceive.c

 Description
   	This module implements a state machine to receive asynchronous UART
	communication using the ZigBee API Frame with ME218C 2011 Communication
	Committee's official protocol (see documentation in ME218C 2011 Final
	Project).

 Notes
	Changes from Ed's State Machine structure include:
		Removal of recursive function calling on state transitions
		Removal of startSM function (module variable is simply initialized)
		Removal of during functions (Actions to events are called in switch)

 History
 When           Who     What/Why
 -------------- ---     --------
 05/05/11  		ery      First Pass

****************************************************************************/

/*----------------------------- Include Files -----------------------------*/
/* include header files for this state machine as well as any machines at the
   next lower level in the hierarchy that are sub-machines to this machine
*/
#include "Pic16Zigbee.h"
	//#include "SMReceive.h"
	//#include "SMEvents.h"
	//#include <htc.h>
#include "InterpretPacket.h"

/*----------------------------- Module Defines ----------------------------*/
// define constants for the states for this machine
// and any other local defines

#define	MAX_RECEIVED_ARRAY 	25

static unsigned char current_byte = 0;	// keeps track of data byte index
static unsigned char sum_bytes = 0;		// keeps track of the sum of all data bytes

static unsigned char data_length = 0;	// holds recieved message length
static unsigned char data_length_msb = 0;	// always 0 in this project
static unsigned char packet_being_received[MAX_RECEIVED_ARRAY];

//Flags
static unsigned char sum_error_flag = FALSE;
static unsigned char received_message_flag = FALSE;
static unsigned char data_in_flag = FALSE;
static unsigned char start_delimiter_flag = FALSE;

/*---------------------------- Module Functions ---------------------------*/


/*---------------------------- Module Variables ---------------------------*/
// Start state machine in receive waiting state
static ReceiveState_t CurrentState = RECEIVE_WAITING;

/*------------------------------ Module Code ------------------------------*/

/****************************************************************************
 Function
    RunReceiveSM

 Parameters
   	Event_t: the event to process

 Returns
	void

 Description
   	Runs the Receive Message State Machine that passes between 5 states while
	reading in UART messages from the Zigbee.
 Notes
   	
 Author
	ERY, 5/5/2011
****************************************************************************/
void RunReceiveSM( Event_t CurrentEvent )
{
ReceiveState_t NextState = CurrentState;


switch ( CurrentState )
{
	//----------------------------------------------------------------------
    case RECEIVE_WAITING :  
        // Process any events
        if ( CurrentEvent != EV_NO_EVENT )        //If an event is active
        {
           	switch (CurrentEvent)
            {
				case EV_UART_BYTE_RECEIVED :
					// if the byte that is read in is the start delimiter
					if( RCREG == START_DELIMITER )
					{
                		// CHANGE STATES
                  		NextState = READING_MSB;
					}
					break;
            }
        }
        break;
    	
	//----------------------------------------------------------------------
    case READING_MSB :  
 		// Process any events
        if ( CurrentEvent != EV_NO_EVENT )        //If an event is active
        {
           	switch (CurrentEvent)
            {
              	case EV_UART_BYTE_RECEIVED : 
					// CHANGE STATES
                  	NextState = READING_LSB;
					// Handle in most sig bit of data
					// Actually won't need this
					data_length_msb = RCREG; // This should clear the RCIF flag
					//data_length = data_length<<8;
                  	break;
            }
        }
        break;
	//----------------------------------------------------------------------
    case READING_LSB :  
  		// Process any events
        if ( CurrentEvent != EV_NO_EVENT )        //If an event is active
        {
           	switch (CurrentEvent)
            {
              	case EV_UART_BYTE_RECEIVED : 
					// CHANGE STATES
                  	NextState = READING_DATA;
					// Handle in most sig bit of data			
					data_length = RCREG; // This should clear the RCIF flag
					// Reset current byte and sum bytes module variables
					sum_bytes = 0;
					current_byte = 0;
                  	break;
            }
        }
        break;
	//----------------------------------------------------------------------
    case READING_DATA :  
  		// Process any events
        if ( CurrentEvent != EV_NO_EVENT )        //If an event is active
        {
           	switch (CurrentEvent)
            {
              	case EV_UART_BYTE_RECEIVED : 
					// Store byte in data array
					packet_being_received[current_byte] = RCREG;
					sum_bytes += packet_being_received[current_byte];

					current_byte++;
					// Check to see if current byte is past the last data byte
					// Fencepost error avoided (matrix indexes are all -1, but
					//		current_byte incremented before this comparison)
					if (current_byte == data_length)
					{
						// CHANGE STATES
                  		NextState = CHECK_MESSAGE;
					}
                  	break;
            }
        }
        break;
	//----------------------------------------------------------------------
    case CHECK_MESSAGE :  
  		// Process any events
        if ( CurrentEvent != EV_NO_EVENT )        //If an event is active
        {
           	switch (CurrentEvent)
            {
              	case EV_UART_BYTE_RECEIVED : 
					// CHANGE STATES
                  	NextState = RECEIVE_WAITING;
					
    				//When exiting CHECK_MESSAGE state, 
					//	if sum_bytes + complement are equal received byte
					if ((sum_bytes + RCREG) == 0xFF)
					{
						received_message_flag = TRUE;
						// Sum bytes checks out...Call INTERPRET PACKET FUNCTION
						//	(separate c file)
						interpretPacket(packet_being_received, data_length);
					}else
					{
						sum_error_flag = TRUE;
					}
                  	break;
            }
        }
        break;
}// End of Switch(CurrentState)

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// Changes states if states have been changed
       	CurrentState = NextState; //Modify state variable

}


/****************************************************************************
 Function
    QueryReceiveSM

 Parameters
    None

 Returns
    ReceiveState_t The current state of the Receive 
	state machine

 Description
    returns the current state of the Receive state machine
 Notes

 Author
	ERY 5/6/2011
****************************************************************************/
ReceiveState_t QueryReceiveSM ( void )
{
   return(CurrentState);
}

/***************************************************************************
PRIVATE FUNCTIONS
***************************************************************************/



/***************************************************************************
MORE PUBLIC FUNCTIONS
***************************************************************************/

/*--------------------------------------------------------------------------
Public Function
	isDataBad

Description
	returns state of sum_error_flag
	clears the flag if true

Author
	ERY 5/8/2011
--------------------------------------------------------------------------*/
unsigned char isBadPacketReceived(void)
{
	if (sum_error_flag == TRUE)
	{
		sum_error_flag = FALSE;
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*--------------------------------------------------------------------------
Public Function
	isGoodPacketReceived

Description
	returns state of received_message_flag
	clears the flag if true

Author
	ERY 5/8/2011
--------------------------------------------------------------------------*/
unsigned char isGoodPacketReceived(void)
{
	if (received_message_flag == TRUE)
	{
		received_message_flag = FALSE;
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*--------------------------------------------------------------------------
Public Function
	getPacket()

Description
	returns the packet being recieved
	(as a pointer to the array that is a module variable for this module)

Author
	ERY 5/8/2011
--------------------------------------------------------------------------*/
//unsigned char* GetPacket(){
//	return packet_being_received;
//}