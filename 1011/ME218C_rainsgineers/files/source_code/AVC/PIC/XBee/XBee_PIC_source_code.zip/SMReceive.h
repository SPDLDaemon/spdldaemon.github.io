/****************************************************************************
 Receive header file 
 ****************************************************************************/

#ifndef SMReceive_H
#define SMReceive_H

//#include "SMEvents.h"
//#include <htc.h>

// Event Definitions

// typedefs for the states
// State definitions for use with the query function
typedef enum { RECEIVE_WAITING, READING_MSB, READING_LSB, READING_DATA, CHECK_MESSAGE } ReceiveState_t ;


// Public Function Prototypes

void RunReceiveSM( Event_t CurrentEvent );
ReceiveState_t QueryReceiveSM ( void );

unsigned char isBadPacketReceived(void);
unsigned char isGoodPacketReceived(void);

#endif /*SMReceive_H */

