/****************************************************************************
 Module
   BuildPacket.c

 Description
   Holds functions that will build and outgoing packet

 Notes

 History
 When           Who     What/Why
 -------------- ---     --------
 05/09/11  		ERY  	ME218C ATOLL Project

****************************************************************************/
#include "Pic16Zigbee.h"
	//#include "BuildPacket.h"
	//#include <htc.h>
	//#include "SMEvents.h"
	//#include "218ZigbeeProtocol.h"

//------------------------------------------------------------
// FLAGS and Module Variables

unsigned char send_packet_length = 0;
unsigned char packet_to_send[25];

//------------------------------------------------------------
// [RQ]: Request Capture of Atoll
unsigned char* atoll_bytes;

//===========================================================================
// PUBLIC FUNCTIONS
//===========================================================================

/*------------------------------------------------------------
Function: buildPacket

Arguments:

Description:
	This function will prepare the outgoining UART message array
	for the Zigbee.

	NOTE:
	This function should be called in the SMSpiIn State Machine.

Author:
	ERY 5/12/2011
------------------------------------------------------------*/
void buildPacket(TransmitPacket_t build_type)
{
	unsigned char i = 0;
	unsigned char checksum_compl = 0;
//------------------------------------------------------------
// General

	packet_to_send[0] = START_DELIMITER;	// start transmission
	packet_to_send[1] = LENGTH_MSB;			// length msb
	packet_to_send[3] = API_ID_TRANSMIT;	// transmit request 
	packet_to_send[4] = FRAME_ID;			// any number
	packet_to_send[7] = OPTIONS_ACK;		// allow achknowledged


//------------------------------------------------------------
// [RQ]: Request Capture of Atoll
	if(build_type == CAPTURE_ATOLL)
	{

		// Fill packet bytes unique to [RQ]
		packet_to_send[2] = RQ_LENGTH_LSB;
		packet_to_send[5] = DEST_ADDR_MSB_BRDCST;
		packet_to_send[6] = DEST_ADDR_LSB_BRDCST;

		
		atoll_bytes = getAtollBytes();
		packet_to_send[8] = atoll_bytes[0];
		packet_to_send[9] = atoll_bytes[1];
		packet_to_send[10] = atoll_bytes[2];
		packet_to_send[11] = atoll_bytes[3];
		packet_to_send[12] = atoll_bytes[4];
		packet_to_send[13] = atoll_bytes[5];
		packet_to_send[14] = atoll_bytes[6];
		packet_to_send[15] = atoll_bytes[7];
		packet_to_send[16] = atoll_bytes[8];

		// Calculate Checksum
		for(i=3;i<=16;i++)
		{
			checksum_compl += packet_to_send[i];
		}
		packet_to_send[17] = 0xFF - checksum_compl;

		// Calculate Length
		send_packet_length = 18;	//RQ_LENGTH_LSB+OUTER_FRAME
	}
//------------------------------------------------------------
// [AAC]: Announce Atoll Capture
	if(build_type == ANNOUNCE_ATOLL)
	{
		// Fill packet bytes unique to [AAC]
		packet_to_send[2] = AAC_LENGTH_LSB;
		packet_to_send[5] = DEST_ADDR_MSB_BRDCST;
		packet_to_send[6] = DEST_ADDR_LSB_BRDCST;

		// Data bytes unique to [AAC]
		packet_to_send[8] = CMD_T_AAC;
		packet_to_send[9] = getTeamColor();
		packet_to_send[10] = getAtollNumber();

		// Calculate Checksum
		for(i=3;i<=10;i++)
		{
			checksum_compl += packet_to_send[i];
		}
		packet_to_send[11] = 0xFF - checksum_compl;

		// Calculate Length
		send_packet_length = 12;	//AAC_LENGTH_LSB+OUTER_FRAME
	}

//------------------------------------------------------------
// [B2C]: ACV to CVC Communication 
	// Not implemented

//------------------------------------------------------------
// [FTT1]: Transmit Broadcast "Team Message" When Attempting to Find a Teammate
// [FTT2]: Transmit Directed Reply Team Achnowledgement Message
	if(build_type == SEARCH_TEAMMATE)
	{
		// Fill packet bytes unique to [AAC]
		packet_to_send[2] = FT_LENGTH_LSB;
		packet_to_send[5] = DEST_ADDR_MSB_BRDCST;
		packet_to_send[6] = DEST_ADDR_LSB_BRDCST;

		// Data bytes unique to [AAC]
		packet_to_send[8] = CMD_T_FT;
		packet_to_send[9] = getTeamColor();

		// Calculate Checksum
		for(i=3;i<=9;i++)
		{
			checksum_compl += packet_to_send[i];
		}
		packet_to_send[10] = 0xFF - checksum_compl;

		// Calculate Length
		send_packet_length = 11;	//FT_LENGTH_LSB+OUTER_FRAME
	}

	if(build_type == ACHKNOWLEDGE_TEAMMATE)
	{
		// Fill packet bytes unique to [AAC]
		packet_to_send[2] = FT_LENGTH_LSB;
		packet_to_send[5] = getTeammateMsb();
		packet_to_send[6] = getTeammateLsb();

		// Data bytes unique to [AAC]
		packet_to_send[8] = CMD_T_FT;
		packet_to_send[9] = getTeamColor();

		// Calculate Checksum
		for(i=3;i<=9;i++)
		{
			checksum_compl += packet_to_send[i];
		}
		packet_to_send[10] = 0xFF - checksum_compl;

		// Calculate Length
		send_packet_length = 11;	//FT_LENGTH_LSB+OUTER_FRAME
	}

}


/*------------------------------------------------------------
Function: getSendPacket
Description:
	Returns a pointer to the packet to send array module 
	variable

Author:
	ERY 5/8/2011

------------------------------------------------------------*/
unsigned char* getSendPacket(void){
	return packet_to_send;
}

/*------------------------------------------------------------
Function: getSendPacketLength
Description:
	Returns the element length of packet to send
	(number of bytes)

Author:
	ERY 5/8/2011

------------------------------------------------------------*/
unsigned char getSendPacketLength(void){
	return send_packet_length;
}

