/****************************************************************************
 Module
   	SMRobustComm.c

 Description
   	This module implements a state machine to ensure robust communication
   	events and timings when both:
   		Teamate searching
   		Atoll flag capturing

 Notes
	Changes from Ed's State Machine structure include:
		Removal of recursive function calling on state transitions
		Removal of startSM function (module variable is simply initialized)
		Removal of during functions (Actions to events are called in switch)

 History
 When           Who     What/Why
 -------------- ---     --------
 05/13/11  		ery      First Pass

****************************************************************************/

/*----------------------------- Include Files -----------------------------*/
/* include header files for this state machine as well as any machines at the
   next lower level in the hierarchy that are sub-machines to this machine
*/
#include "Pic16Zigbee.h"

/*----------------------------- Module Defines ----------------------------*/
// Transmission Delays
//	for ms counter to me compared to
#define LISTENING_TEAMMATE_DELAY		1000

#define FIVE_HZ_DELAY					200

#define CAPTURE_ATOLL_DELAY				500
#define ATOLL_WAITING_TIMEOUT			1000
#define ANNOUNCE_ATOLL_DELAY			200

// Local variables
unsigned char message_counter = 0;	// keeps track of # of message sends
unsigned int entrance_time = 0;		// keeps track of the time when entering a state

//Flags
unsigned char start_transmit_flag = FALSE;
unsigned char raise_team_flag = FALSE;

/*---------------------------- Module Functions ---------------------------*/


/*---------------------------- Module Variables ---------------------------*/
// Start state machine in receive waiting state
static ReceiveState_t CurrentState = RECEIVE_WAITING;

/*------------------------------ Module Code ------------------------------*/

/****************************************************************************
 Function
    RunRobustCommSM

 Parameters
   	Event_t: the event to process

 Returns
	void

 Description
   	Runs the Robust Communication State Machine that passes between 7 states 
   	while keeping track of communication broadcasts.
   	
 Author
	ERY, 5/13/2011
****************************************************************************/
void RunRobustCommSM( Event_t CurrentEvent )
{
ReceiveState_t NextState = CurrentState;


switch ( CurrentState )
{
	//----------------------------------------------------------------------
    case PLAYING :  
        // Process any events
        if ( CurrentEvent != EV_NO_EVENT )
        {
           	switch (CurrentEvent)
            {
				case EV_CMD_FIND_TEAMMATE :
					// Check to see if white token / team reset
					if (getTeamColor() == FT_CLR_WHITE){
						// Reset team
						PORTC = 0b00000000;
						PORTA = 0b00000000;
						break;
					}

					// Record entrance time to new state
					entrance_time = getTimeMs();
                	// CHANGE STATES
                	NextState = TEAMMATE_LISTENING;
					break;

				case EV_CMD_CAPTURE_ATOLL :
					// Prep Transmit Capture Atoll
					buildPacket(CAPTURE_ATOLL);
					start_transmit_flag = TRUE;
                	// CHANGE STATES
                	NextState = ATOLL_CAPTURING;
					// Next State has a message try counter
					message_counter = 0;
					// Record entrance time to new state
					entrance_time = getTimeMs();
					break;
            }
        }
        break;
    	
	//----------------------------------------------------------------------
    case TEAMMATE_LISTENING :  
		// Process Timeout
		if ( getTimeMs()-entrance_time > LISTENING_TEAMMATE_DELAY)
		{
			// Prep Transmit Search Teammate
			buildPacket(SEARCH_TEAMMATE);
			start_transmit_flag = TRUE;
            // CHANGE STATES
            NextState = TEAMMATE_SEARCHING;
			// Next State has a message try counter
			message_counter = 0;
			// Record entrance time to new state
			entrance_time = getTimeMs();
			PORTC |= ERROR_PIN_RC2;
		}

        // Process any events
        if ( CurrentEvent != EV_NO_EVENT )
        {
           	switch (CurrentEvent)
            {
				case EV_TEAMMATE_HEARD :
					// Prep Transmit Achknowledge Teammate
					buildPacket(ACHKNOWLEDGE_TEAMMATE);
					start_transmit_flag = TRUE;
                	// CHANGE STATES
                	NextState = TEAMMATE_ACK_WAITING;
					// Next State has a message try counter
					message_counter = 0;
					// Record entrance time to new state
					entrance_time = getTimeMs();
					//PORTC |= ERROR_PIN_RC2;
					break;
            }
        }
        break;
	//----------------------------------------------------------------------
    case TEAMMATE_ACK_WAITING :  
		// Process Timeout
		if ( getTimeMs()-entrance_time > FIVE_HZ_DELAY)
		{
			// Increment try counter
			message_counter++;
			// Reset entrance time
			entrance_time = getTimeMs();
			// If message attempts is more than 10 give up
			if( message_counter > 10)
			{
           		// CHANGE STATES
             	NextState = PLAYING;
				// Oh well, raise team flag anyway
				raise_team_flag = TRUE;	
				// ERROR
			}
			// Else RE-Transmit Achknowledge Teammate
			else
			{
				buildPacket(ACHKNOWLEDGE_TEAMMATE);
				start_transmit_flag = TRUE;
			}
		}

        // Process any events
        if ( CurrentEvent != EV_NO_EVENT )
        {
           	switch (CurrentEvent)
            {
				case EV_TRANSMIT_SUCCESS :
           			// CHANGE STATES
             		NextState = PLAYING;
					// Successful achknowledgement out
					raise_team_flag = TRUE;	
					break;
            }
        }
        break;
	//----------------------------------------------------------------------
    case TEAMMATE_SEARCHING :  
		// Process Timeout
		if ( getTimeMs()-entrance_time > FIVE_HZ_DELAY)
		{
			// Increment try counter
			message_counter++;
			// Reset entrance time
			entrance_time = getTimeMs();
			// If message attempts is more than 255 give up
			if( message_counter >= 255)
			{
           		// CHANGE STATES
             	NextState = PLAYING;
				// Oh well, raise team flag anyway
				raise_team_flag = TRUE;	
				// ERROR
			}
			// Else RE-Transmit Search Teammate
			else
			{
				//PORTC ^= ERROR_PIN_RC2;
				buildPacket(SEARCH_TEAMMATE);
				start_transmit_flag = TRUE;
			}
		}

        // Process any events
        if ( CurrentEvent != EV_NO_EVENT )
        {
           	switch (CurrentEvent)
            {
				case EV_TEAMMATE_ACHKNOWLEDGED :
           			// CHANGE STATES
             		NextState = PLAYING;
					// Successful achknowledgement returned
					raise_team_flag = TRUE;	
					break;
            }
        }
        break;

	//----------------------------------------------------------------------
    case ATOLL_CAPTURING :  
		// Process Timeout
		if ( getTimeMs()-entrance_time > CAPTURE_ATOLL_DELAY)
		{
			// Increment message counter
			message_counter++;
			// Reset entrance time
			entrance_time = getTimeMs();
			// If message attempts is more than 3, give up
			if( message_counter >= 3)
			{
           		// CHANGE STATES
             	NextState = PLAYING;	
				// ERROR
			}
			// Else Resend the message
			else
			{
				buildPacket(CAPTURE_ATOLL);  //already built
				start_transmit_flag = TRUE;	
			}
		}

        // Process any events
        if ( CurrentEvent != EV_NO_EVENT )
        {
           	switch (CurrentEvent)
            {
				case EV_TRANSMIT_SUCCESS :
					// Record entrance time to new state
					entrance_time = getTimeMs();
                	// CHANGE STATES
                	NextState = ATOLL_WAITING_REPLY;
					break;
            }
        }	
  		break;

	//----------------------------------------------------------------------
    case ATOLL_WAITING_REPLY : 
		// Process Timeout
		if ( getTimeMs()-entrance_time > ATOLL_WAITING_TIMEOUT)
		{
           	// CHANGE STATES
             NextState = PLAYING;	
			// ERROR
			//PORTC |= ERROR_PIN_RC0;
		}

        // Process any events
        if ( CurrentEvent != EV_NO_EVENT )
        {
           	switch (CurrentEvent)
            {
				// Atoll sends message back that capture worked
				case EV_ATOLL_CAPTURE_SUCCESS :
					// Prep Transmit Announce Atoll
					buildPacket(ANNOUNCE_ATOLL);
					start_transmit_flag = TRUE;
					message_counter = 0;
					// Record entrance time to new state
					entrance_time = getTimeMs();
                	// CHANGE STATES
                	NextState = ATOLL_ANNOUNCING;
					//PORTC |= ERROR_PIN_RC1;
					break;

				// Atoll sends back message of failure!
				case EV_ATOLL_CAPTURE_FAILED :
                	// CHANGE STATES
                	NextState = PLAYING;	
					// ERROR
					break;
            }
        }
    	break;
	//----------------------------------------------------------------------
    case ATOLL_ANNOUNCING :
		// Process Timeout
		if ( getTimeMs()-entrance_time > ANNOUNCE_ATOLL_DELAY)
		{
			message_counter++;
			// If message attempts is more than 2, done
			if( message_counter >= 2)
			{
           		// CHANGE STATES
           		NextState = PLAYING;
				//PORTC |= ERROR_PIN_RC2;	
			}
			// Else, send again
			else 
			{
				// buildPacket(ANNOUNCE_ATOLL);  //already built
				start_transmit_flag = TRUE;
				entrance_time = getTimeMs();	//restart timer
			}
		}

        // No Events to Process
       			 
    	break;
}// End of Switch(CurrentState)

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// Changes states if states have been changed
       	CurrentState = NextState; //Modify state variable
}


/****************************************************************************
 Function
    QueryRobustCommSM

 Parameters
    None

 Returns
    RobustCommState_t The current state of the RobustComm
	state machine

 Description
    returns the current state of the RobustComm state machine

 Author
	ERY 5/13/2011
****************************************************************************/
RobustCommState_t QueryRobustCommSM ( void )
{
   return(CurrentState);
}

/***************************************************************************
PRIVATE FUNCTIONS
***************************************************************************/


/***************************************************************************
MORE PUBLIC FUNCTIONS
***************************************************************************/

/*------------------------------------------------------------
Function: isStartTransmitFlagHi

Description:
	If start transmit flag is high, 
		then returns TRUE and lowers the flag
	Else returns FALSE

Author:
	ERY 5/15/2011

------------------------------------------------------------*/
unsigned char isStartTransmitFlagHi(void){
	if(start_transmit_flag == TRUE)
	{
		start_transmit_flag = FALSE;
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*------------------------------------------------------------
Function: isRaiseTeamFlagHi

Description:
	If raise team flag is high, 
		then returns TRUE and lowers the flag
	Else returns FALSE

Author:
	ERY 5/16/2011

------------------------------------------------------------*/
unsigned char isRaiseTeamFlagHi(void){
	if(raise_team_flag == TRUE)
	{
		raise_team_flag = FALSE;
		return TRUE;
	} else
	{
		return FALSE;
	}
}