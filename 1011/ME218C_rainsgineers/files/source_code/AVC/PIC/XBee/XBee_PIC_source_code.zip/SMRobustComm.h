/****************************************************************************
 Robust Communications header file 
 ****************************************************************************/

#ifndef SMRobustComm_H
#define SMRobustComm_H

// Event Definitions

// Typedefs for the States
typedef enum { 
				PLAYING, 
				TEAMMATE_LISTENING, 
				TEAMMATE_ACK_WAITING, 
				TEAMMATE_SEARCHING, 
				ATOLL_CAPTURING,
				ATOLL_WAITING_REPLY,
				ATOLL_ANNOUNCING
				} RobustCommState_t ;


// Public Function Prototypes

void RunRobustCommSM( Event_t CurrentEvent );
RobustCommState_t QueryRobustCommSM ( void );

unsigned char isStartTransmitFlagHi(void);
unsigned char isRaiseTeamFlagHi(void);

#endif /*SMReceive_H */

