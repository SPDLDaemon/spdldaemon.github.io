/****************************************************************************
Build Packet header file 
 ****************************************************************************/

#ifndef BuildPacket_H
#define BuildPacket_H

// Typedef of the types of packets that can be built
typedef enum {  
				SEARCH_TEAMMATE,
				ACHKNOWLEDGE_TEAMMATE,
				CAPTURE_ATOLL,
				ANNOUNCE_ATOLL
} TransmitPacket_t ;

// PUBLIC FUNCTIONS
void buildPacket(TransmitPacket_t);

// Public Functions
unsigned char* getSendPacket(void);
unsigned char getSendPacketLength(void);

#endif /*BuildPacket_H */