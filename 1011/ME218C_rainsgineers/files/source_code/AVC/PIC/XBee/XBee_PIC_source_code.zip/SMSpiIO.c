/****************************************************************************
 Module
   	SMSpiIO.c

 Description
   	This module implements a state machine to handle all synchonous
	communication to and from the Zigbee-linked-Pic16.  It sets up the SSP
	on the PIC 16 to SPI, and this device will act as the slave during the
	information exchange to a master Pic.

 Notes
	Changes from Ed's State Machine structure include:
		Removal of recursive function calling on state transitions
		Removal of startSM function (module variable is simply initialized)
		Removal of during functions (Actions to events are called in switch)

 History
 When           Who     What/Why
 -------------- ---     --------
 05/10/11  		ery      First Pass

****************************************************************************/

/*----------------------------- Include Files -----------------------------*/

#include "Pic16Zigbee.h"
	//#include "SMSpiIO.h"
	//#include "SMEvents.h"
	//#include <htc.h>
#include "BuildPacket.h"

/*----------------------------- Module Defines ----------------------------*/

// These are defined by our team protocol
//	and will be used to differentiate between these two command types
#define SPI_FIND_TEAM_LENGTH		1
#define SPI_CAPTURE_ATOLL_LENGTH	9

#define SPI_DBYTE_COLOR				0x00
#define SPI_DBYTE_ATOLL				0x02

#define SPI_WAITING_TIMEOUT			800


/*---------------------------- Module Functions ---------------------------*/


/*---------------------------- Module Variables ---------------------------*/
// Start state machine in receive waiting state
static ReceiveState_t CurrentState = SPI_WAITING;

static unsigned int spi_entrance_time = 0;

static unsigned char spi_in_index = 0;		
static unsigned char spi_in_length = 0;
static unsigned char spi_in_array[MAX_ARRAY_SIZE];

static unsigned char team_color = FT_CLR_WHITE;		// default is no team
static unsigned char atoll_number = 0;

static unsigned char cmd_capture_atoll_flag = FALSE;
static unsigned char cmd_find_teammate_flag = FALSE;

/*------------------------------ Module Code ------------------------------*/

/****************************************************************************
 Function
    RunSpiIOSM

 Parameters
   	Event_t: the event to process

 Returns
	void

 Description
   	Runs the Receive Message State Machine that passes between 5 states while
	reading in UART messages from the Zigbee.
 Notes
   	
 Author
	ERY, 5/5/2011
****************************************************************************/
void RunSpiIOSM( Event_t CurrentEvent )
{
ReceiveState_t NextState = CurrentState;

switch ( CurrentState )
{
	//----------------------------------------------------------------------
    case SPI_WAITING :  
        // Process any events
        if ( CurrentEvent != EV_NO_EVENT ) 
        {
           	switch (CurrentEvent)
            {
				case EV_SPI_BUFFER_FULL :
					//PORTC |= ERROR_PIN_RC0;
					spi_in_length = SSPBUF;
					spi_in_index = 0;
					// Record entrance time to new state
					spi_entrance_time = getTimeMs();
					// CHANGE STATES
					NextState = SPI_RECEIVING;
					break;
            }
        }
        break;
    	
	//----------------------------------------------------------------------
    case SPI_RECEIVING : 

  		// Process any events
        if ( CurrentEvent != EV_NO_EVENT )
        {
           	switch (CurrentEvent)
            {
              	case EV_SPI_BUFFER_FULL :
					// Store byte in data array
					spi_in_array[spi_in_index] = SSPBUF;
					spi_in_index++;

					// Check to see if index is past the last data byte
					// Fencepost error avoided (matrix indexes are all -1, but
					//		index incremented before this comparison)
					if (spi_in_index >= (spi_in_length))// not length-1 because incremented first
					{ 
						//PORTC |= ERROR_PIN_RC1;
						if( spi_in_length == (SPI_CAPTURE_ATOLL_LENGTH) )
						{
							// Save atoll number for later
							atoll_number = spi_in_array[SPI_DBYTE_ATOLL];
							// Set flag that incomming command was to capture atoll
							cmd_capture_atoll_flag = TRUE;
							// CHANGE STATES
                  			NextState = SPI_WAITING;
						}
						else if( spi_in_length == (SPI_FIND_TEAM_LENGTH) )
						{
							// Save team color for later
							team_color = spi_in_array[SPI_DBYTE_COLOR];
							// Set flag that incomming command was to find teammate
							cmd_find_teammate_flag = TRUE;
							// CHANGE STATES
                  			NextState = SPI_WAITING;
						}
						else
						{
							//ERROR
						}
					}
                  	break;
            }
        }
		// Process Timeout
		else if ( (getTimeMs()-spi_entrance_time) > SPI_WAITING_TIMEOUT)
		{
			// CHANGE STATES
        	NextState = SPI_WAITING;
			// ERROR
		}
        break;

}// End of Switch(CurrentState)

//- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
	// Changes states if states have been changed
       	CurrentState = NextState; //Modify state variable
}


/****************************************************************************
 Function
    QuerySpiIOSM

 Parameters
    None

 Returns
    ReceiveState_t The current state of the SpiIO
	state machine

 Description
    returns the current state of the SpiIO state machine
 Notes

 Author
	ERY 5/10/2011
****************************************************************************/
ReceiveState_t QuerySpiIOSM ( void )
{
   return(CurrentState);
}

/***************************************************************************
PRIVATE FUNCTIONS
***************************************************************************/



/***************************************************************************
MORE PUBLIC FUNCTIONS
***************************************************************************/

/*------------------------------------------------------------
Function: isSpiCmdTeamSearch

Description:
	If cmd_find_teammate_flag is high, 
		then returns TRUE and lowers the flag
	Else returns FALSE

Author:
	ERY 5/15/2011

------------------------------------------------------------*/
unsigned char isSpiCmdTeamSearch(void)
{
	if( cmd_find_teammate_flag == TRUE )
	{
		cmd_find_teammate_flag = FALSE;
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*------------------------------------------------------------
Function: isSpiCmdAtollCapture

Description:
	If cmd_capture_atoll_flag  is high, 
		then returns TRUE and lowers the flag
	Else returns FALSE

Author:
	ERY 5/15/2011

------------------------------------------------------------*/
unsigned char isSpiCmdAtollCapture(void)
{
	if( cmd_capture_atoll_flag == TRUE )
	{
		cmd_capture_atoll_flag = FALSE;
		return TRUE;
	} else
	{
		return FALSE;
	}
}

/*------------------------------------------------------------
Function: getTeamColor

Description:
	Returns team_color module variable

Author:
	ERY 5/15/2011

------------------------------------------------------------*/
unsigned char getTeamColor(void)
{
	return team_color;
}

/*------------------------------------------------------------
Function: getAtollNumber

Description:
	Returns atoll_number module variable

Author:
	ERY 5/15/2011

------------------------------------------------------------*/
unsigned char getAtollNumber(void)
{
	return atoll_number;
}

/*------------------------------------------------------------
Function: getAtollBytes

Description:
	Returns pointer to spi_in_array

Author:
	ERY 5/15/2011

------------------------------------------------------------*/
unsigned char* getAtollBytes(void)
{
	return spi_in_array;
}
