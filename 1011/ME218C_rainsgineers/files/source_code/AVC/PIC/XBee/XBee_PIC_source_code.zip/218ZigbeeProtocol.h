/****************************************************************************
 ME218C 2011 UART-ZIGBEE PROTOCOL
****************************************************************************/
		
//===========================================================================
// RECEIVE MESSAGES
//===========================================================================

//--------------------------------------------------------------------------
// General

// General Bytes *FOR INCOMING PACKET API ID
#define R_DBYTE_NUM_API_ID		0x00	// 1-1 = array index in data section
#define R_DBYTE_NUM_SRC_MSB		0x01	// 2-1 = array index in data section
#define R_DBYTE_NUM_SRC_LSB		0x02	// 3-1 = array index in data section
#define R_DBYTE_NUM_RSSI		0x03	// 4-1 = array index in data section
#define R_DBYTE_NUM_OPTIONS		0x04	// 5-1 = array index in data section
#define R_DBYTE_NUM_CMD_T		0x05	// 6-1 = array index in data section

// API ID Types
#define API_ID_TRANS_STAT	0x89	// For Transmit Success Receiving

// Command types
#define CMD_T_RP			0x67	// For [RP]: Capture Reply from Atoll 
#define CMD_T_C2B			0xCD	// For [C2B]: Receiving Command from the CVC
#define CMD_T_FT			0x89	// For [FTR1] & [FTR2] & [FTT1] & [FTT2]

//--------------------------------------------------------------------------
// Transmit Status Received

// General Bytes *FOR TRANSMIT STATUS API ID
#define R_DBYTE_NUM_STATUS		0x02	// 3-1

// Status values
#define TS_STATUS_SUCCESS		0x00
//#define TS_STATUS_NO_ACK		0x01
//#define TS_STATUS_FAILED		0x02

//--------------------------------------------------------------------------
// [RP]: Capture Reply from Atoll 

// Atoll Number Byte
#define RP_DBYTE_NUM_AN		0x06	// 7-1 = array index in data section

// Success or Failure Byte
#define RP_DBYTE_NUM_SF		0x07	// 8-1 = array index in data section
#define RP_SF_SUCCESS		0xFF
#define RP_SF_FAILURE		0x00

// New Owner Byte
#define RP_DBYTE_NUM_NO		0x08	// 9-1 = array index in data section
	
//--------------------------------------------------------------------------
// [C2B]: Receiving Command from the CVC 

#define C2B_DBYTE_NUM_INFO	0x06	// 7-1 = array index in data section

// NOTE: PWM Signals will be read directly by PWM Pics...
#define C2B_DBYTE_NUM_PWMR	0x07	// 8-1 = array index in data section
#define C2B_DBYTE_NUM_PWML	0x08	// 9-1 = array index in data section

//--------------------------------------------------------------------------
// [FTR1]: Receive Broadcast "Team Message" When Attempting to Find a Teammate
// [FTR2]: Receive Directed Reply Team Achnowledgement Message
// [FTT1]: Receive Broadcast "Team Message" When Attempting to Find a Teammate
// [FTT2]: Receive Directed Reply Team Achnowledgement Message

#define FT_DBYTE_NUM_CLR	0x06	// 7-1 = array index in data section

// Team Colors
#define FT_CLR_RED			0xFE
#define FT_CLR_GREEN		0x01
#define FT_CLR_WHITE		0x88	// no team / unoccupied atoll


//===========================================================================
// TRANSMIT MESSAGES
//===========================================================================

//--------------------------------------------------------------------------
// General

#define OUTER_FRAME			0x04	// start delimiter, 2 length bytes, checksum

// Command types
#define CMD_T_RQ			0x66	// For [RQ]: Capture Request to Atoll 
#define CMD_T_B2C			0xEF	// For [B2C]: Sending to CVC
#define CMD_T_AAC			0xAB	// For [AAC]: Announcing Atoll Capture
//CMD_T_FT defined above in transmit section

// General bytes in all transmissions
#define START_DELIMITER 		0x7E	// Marks the start of the transmission
#define LENGTH_MSB				0x00	// This is always the length msb
#define API_ID_TRANSMIT			0x01	// Transmit request
#define FRAME_ID				0xAA	// Any value
#define OPTIONS_ACK				0x00	// Don't disable achknowledged

// General bytes in some transmissions
#define DEST_ADDR_MSB_BRDCST	0xFF	
#define DEST_ADDR_LSB_BRDCST	0xFF

//--------------------------------------------------------------------------
// [RQ]: Capture Request to Atoll 

#define RQ_LENGTH_LSB		0x0E	// 18-4 data bytes

//--------------------------------------------------------------------------
// [AAC]: Capture Request to Atoll 

#define AAC_LENGTH_LSB		0x08	// 12-4 data bytes

//--------------------------------------------------------------------------
// [FTT1]: Receive Broadcast "Team Message" When Attempting to Find a Teammate
// [FTT2]: Receive Directed Reply Team Achnowledgement Message

#define FT_LENGTH_LSB		0x07	// 11-4 data bytes

//--------------------------------------------------------------------------
// Packet from AVC to CVC

// CVC
//#define ADDR_CVC_MSB			0x8
//#define ADDR_CVC_LSB			0x25	// 2085

// ACV
//#define ADDR_ACV_MSB			0x8
//#define ADDR_ACV_LSB			0x89	// 2185

//#define DATA_AVC_TO_CVC			0xEF	// This must be the first data byte
//#define TO_CVC_PACKET_LENGTH	0x0B	// 11: contains 1 data byte for our use
//#define TO_CVC_DATA_LSB			(TO_CVC_PACKET_LENGTH-OUTER_FRAME)