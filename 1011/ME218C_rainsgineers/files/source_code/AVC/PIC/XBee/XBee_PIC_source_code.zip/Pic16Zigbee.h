/****************************************************************************
 Pic16Zigbee header file 
****************************************************************************/

#ifndef Pic16Zigbee_H
#define Pic16Zigbee_H

//--------------------------------------------------------------------------
// Debugging stuff

// All ERRORS on Port C
#define ERROR_PIN_RC0	0b00000001;
#define ERROR_PIN_RC1	0b00000010;
#define ERROR_PIN_RC2	0b00000100;


//--------------------------------------------------------------------------
// Program Wide Constants

#define	MAX_ARRAY_SIZE 	25

//--------------------------------------------------------------------------
// Files to Include
#include <htc.h>
#include "SMEvents.h"
#include "SMReceive.h"
#include "SMTransmit.h"
#include "BuildPacket.h"
#include "InterpretPacket.h"
#include "SMSpiIO.h"
#include "218ZigbeeProtocol.h"
#include "SMRobustComm.h"

//--------------------------------------------------------------------------
// Public Functions
unsigned int getTimeMs(void);

//--------------------------------------------------------------------------
#endif