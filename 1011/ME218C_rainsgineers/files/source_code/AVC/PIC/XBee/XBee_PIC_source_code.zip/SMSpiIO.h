/****************************************************************************
 Receive header file 
 ****************************************************************************/

#ifndef SMSpiIO_H
#define SMSpiIO_H

// Event Definitions

// typedefs for the states
typedef enum { SPI_WAITING, SPI_RECEIVING } SMSpiIOState_t ;


// State Machine Public Functions
void RunSpiIOSM( Event_t CurrentEvent );
ReceiveState_t QuerySMSpiIOSM ( void );

// Flag Public Functions
unsigned char isSpiCmdTeamSearch(void);
unsigned char isSpiCmdAtollCapture(void);

// Get Public Functions
unsigned char getTeamColor(void);
unsigned char getAtollNumber(void);
unsigned char* getAtollBytes(void);

#endif /*SMSMSpiIO_H */

