/****************************************************************************
 Module
   Zigbee PIC16 Main

 Description
   PIC16F690 TO ZIGBEE

 Notes

 History
 When           Who     What/Why
 -------------- ---     --------
 05/06/11  		ERY     Start
 05/15/11  		ERY     Added timer and interrupts

****************************************************************************/


//===========================================================================
// SETUP
//===========================================================================
#include "Pic16Zigbee.h"

__CONFIG( HS & UNPROTECT & WDTDIS & BORDIS & IESODIS & FCMDIS);

//------------------------------------------------------------
// Constants

/* BAUD RATE CALCULATION
	Desired Baud Rate = Fosc / (64*([SPBRGH:SPBRG]+1)
	Desired Baud Rate = 9600
	Fosc = 20MHz
	Baud Const = (Fosc / Desired Baud Rate)/64 - 1 = 31.55
	Baud Const = 32 ==> Baud Rate = 9469
*/
#define BAUD_CONST	32

// 1ms = 1/f where f = 20MHz/4/prescale/MS_PRESCALE
#define MS_PRESCALE 19 // 20 ==> 1.024ms

//------------------------------------------------------------
// Module Variables
static unsigned char micro_count = 0;
static unsigned int ms_count = 0;
static unsigned int ms_count_event = 0;

static unsigned char debug_trigger = 0;

//------------------------------------------------------------
// Private Function Prototypes

void initIO(void);
void initUART(void);
void initSSP (void);
void initMsTimer(void);
void msCounterIncrement(void);
Event_t CheckEvents(void);

void debugColor(void);


//===========================================================================
//MAIN CODE
//===========================================================================

void main (void)
{
	Event_t event;
    
	initIO();			// Init Inputs/Outputs
	initUART();			// Init Asynchronous Comm with Zigbee
	initSSP();			// Init SSP Synchronous Comm with Master PIC
	initMsTimer();		// Init Timer to Count in ms

    while (1)
    {
		msCounterIncrement();
		// 4 Parallel State Machines
		event = CheckEvents();
		//if(debug_trigger == 0){
		//	debug_trigger = 1;
		//	event = EV_CMD_FIND_TEAMMATE;
		//}
		RunSpiIOSM(event);
		RunReceiveSM(event);
		RunTransmitSM(event);
		RunRobustCommSM(event);

		// Debugging Functions
		//debugColor();
    }
}

//===========================================================================
//FUNCTIONS
//===========================================================================

/*------------------------------------------------------------
Function: initIO

Description:
	Initializes all I/O ports

Author:
	ERY 5/5/2011

------------------------------------------------------------*/
void initIO(void)
{
	// Turn off Analogue Ports
	ANSEL = 0b00000000;
	ANSELH = 0b00000000;

	// Setup IO Ports
	TRISA = 0b11111100;	// team color fan control pins
	TRISB = 0b11111111;
	TRISC = 0b11111000;	// debug pins

	// Serial Data Output
	RC7 = 0;	// make output

	// Transmit
	RB7 = 0;	// make output

	PORTC = 0b00000000;
	PORTA = 0b00000000;
}

/*------------------------------------------------------------
Function: initUART

Description:
	Initializes UART Communication

Author:
	ERY 5/5/2011

------------------------------------------------------------*/
void initUART(void){
	// 1: Set Baud Rate
	SPBRG = BAUD_CONST;	// Set baud rate (see declarations)
	//BAUDCTL |= SCKP; 	// Use only if inverted output

	// 2: Enable the serial, transmission and reception pins
	SPEN = 1;	// Enable serial ports in RCSTA register
	CREN = 1;	// Enable continuous recieve in RCSTA register
	TXEN = 1;	// Enables transmission and sets TXIF in TXSTA register
}

/*------------------------------------------------------------
Function: initSSP

Description:
	This function initializes the SPI module.

Author:
	ERY 5/5/2011

------------------------------------------------------------*/
void initSSP (void) {
    CKE = 1;    // Data is transmitted on falling clock edge (CKP = 1)
    CKP = 1; 	// Transmit on falling edge, receive on rising, clock idles hi
   	
    SSPM3 = 0;  //SPI Slave mode, clock = SCK pin. SS pin control enabled.
    SSPM2 = 1;  
    SSPM1 = 0;
    SSPM0 = 0;
   
    TRISC7 = 0; // Configure SDO to output
	TRISC6 = 1; // Configure SS to input
    TRISB6 = 1; // Configure SCK to input

    SSPEN = 1;  // Enable SSP
}

/*------------------------------------------------------------
Function: initMsTimer

Description:
	This function initializes timer 0 to count milliseconds

Author:
	ERY 5/15/2011

------------------------------------------------------------*/
void initMsTimer(void)
{
	// Timer 0 increments on instruction clock
	T0CS = 0;
	//Prescale = /256  [OPTION_REG]
	PS0 = PS1 = PS2 = 1;	

	// Don't need to clear this bit despite data sheet chart
	//PSA = 0;

	// Remove timer 0 interrupt flag
	// 		This will go high every fosc/prescale
	T0IF = 0; 
				
	// Timer 0 interrupt enable
	//T0IE = 1; // Enable interrupt on TMR0 overflow	
	// Peripheral interrupt enable
	//PEIE = 1;
	// Global interrupt enable
	//GIE = 1;
}

/*------------------------------------------------------------
Function:  msCounterIncrement

Description:
	This interrupt increments the ms_count variable every 
	millisecond

Author:
	ERY 5/15/2011

------------------------------------------------------------*/
void msCounterIncrement(void)			
{
	// Clear the interrupt flag
	if(T0IF ==1)
	{
		T0IF = 0;

		// This if statement will execute every fosc/prescaler
		micro_count++;
	
		// These contents will execute one every millisecond
		if(micro_count == MS_PRESCALE)
		{
			// Increment ms count
			ms_count++;
			// Clear the microcount register and interrupt flag
			micro_count = 0;
		}
	}
}

/*------------------------------------------------------------
Function: getTimeMs

Description:
	Returns the ms_count variable (unsigned int)

Author:
	ERY 5/15/2011

------------------------------------------------------------*/
unsigned int getTimeMs(void)
{
	return ms_count;
}

/*------------------------------------------------------------
Function: CheckEvents

Description:
	Event Checker for the PIC16_Zigbee Master State Machine

Author:
	ERY 5/6/2011

------------------------------------------------------------*/
Event_t CheckEvents(void){

// Default is no event
	Event_t current_event = EV_NO_EVENT;

//----------------------------------------------------
// RECEIVE EVENTS

// ***EV_UART_BYTE_RECEIVED***
	if(RCIF) // in PIR1 register
	{
		current_event = EV_UART_BYTE_RECEIVED;
	}	

// If Good Packet In:
	//else if(isGoodPacketReceived())
	//{

	else if(isPacketSuccessfulAtoll())
	{
		current_event = EV_ATOLL_CAPTURE_SUCCESS;
	}
	else if(isPacketFailedAtoll())
	{
		current_event = EV_ATOLL_CAPTURE_FAILED;
	}
	else if(isPacketCvcInfo())
	{
		current_event = EV_NEW_CVC_INFO;
	}
	else if(isPacketTeammateSearching())
	{
		current_event = EV_TEAMMATE_HEARD;
	}
	else if(isPacketTeammateAchknowleged())
	{
		current_event = EV_TEAMMATE_ACHKNOWLEDGED;
	}
	else if(isPacketTransmitSuccess())
	{
		current_event = EV_TRANSMIT_SUCCESS;
	}

	//}

// ***EV_BAD_PACKET_IN***
	else if(isBadPacketReceived())
	{
		current_event = EV_BAD_PACKET_IN;
	}

//----------------------------------------------------
// TRANSMIT EVENTS

// ***EV_TRANSMIT_COMPLETE***
	// If transmit is complete and in sending packet state
	else if( isTransmitComplete() && (QueryTransmitSM() == SENDING_PACKET) )
	{
		current_event = EV_TRANSMIT_COMPLETE;
	}

// ***EV_TRANSMIT_BUFFER_EMPTY***
	// If transmit buffer is empty and in sending packet state
	else if(( QueryTransmitSM() == SENDING_PACKET ) && TXIF ) // in PIR1 register
	{
		current_event = EV_TRANSMIT_BUFFER_EMPTY;
	}

// ***EV_START_TRANSMIT***
	// if have a message to transmit and in transmit waiting	
	else if(isStartTransmitFlagHi() && (QueryTransmitSM() == TRANSMIT_WAITING))
	{
		current_event = EV_START_TRANSMIT;
	}

//----------------------------------------------------
// SPI EVENTS

// ***EV_SPI_BUFFER_FULL***
	// if the SSP buffer flag is high
	else if(BF) // SSPIF didn't work for some reason
	{
		current_event = EV_SPI_BUFFER_FULL;
	}

// ***EV_CMD_CAPTURE_ATOLL***
	else if(isSpiCmdAtollCapture())
	{
		current_event = EV_CMD_CAPTURE_ATOLL;
	}

// ***EV_CMD_FIND_TEAMMATE***
	else if(isSpiCmdTeamSearch())
	{
		current_event = EV_CMD_FIND_TEAMMATE;
	}

//----------------------------------------------------
// ROBUST COMM EVENTS
	else if(isRaiseTeamFlagHi())
	{
		// Raise teamline controlling fans
		if(getTeamColor() == FT_CLR_RED)
		{
			PORTC |= ERROR_PIN_RC0;
			PORTA = 0b00000001;
		}
		if(getTeamColor() == FT_CLR_GREEN)
		{
			PORTC |= ERROR_PIN_RC1;
			PORTA = 0b00000010;
		}
	}

// RETURN
	return current_event;
}


/*------------------------------------------------------------
Function: debugColor

Description:
	Lights up LED's corresponding to current team color

Author:
	ERY 5/15/2011

------------------------------------------------------------*/
void debugColor(void)
{
	PORTC = 0b00000000; // start low for debugging
	if(getTeamColor() == FT_CLR_GREEN)
	{
		PORTC |= ERROR_PIN_RC1;
	}
	if(getTeamColor() == FT_CLR_RED)
	{
		PORTC |= ERROR_PIN_RC0;
	}
}