/****************************************************************************
 InterpretPacket header file 
 ****************************************************************************/

#ifndef InterpretPacket_H
#define InterpretPacket_H

// PUBLIC FUNCTIONS
void interpretPacket(unsigned char*, unsigned char);

// Flags
unsigned char isPacketSuccessfulAtoll(void);
unsigned char isPacketFailedAtoll(void);
unsigned char isPacketCvcInfo(void);
unsigned char isPacketTeammateSearching(void);
unsigned char isPacketTeammateAchknowleged(void);
unsigned char isPacketTransmitSuccess(void);

// Get info functions
unsigned char getCVCInfo(void);
unsigned char getTeammateMsb(void);
unsigned char getTeammateLsb(void);

#endif /*InterpretPacket_H */