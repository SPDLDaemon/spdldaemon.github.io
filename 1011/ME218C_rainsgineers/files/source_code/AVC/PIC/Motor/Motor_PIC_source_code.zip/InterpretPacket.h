/****************************************************************************
 InterpretPacket header file 
 ****************************************************************************/

#ifndef InterpretPacket_H
#define InterpretPacket_H

// PUBLIC FUNCTIONS
void interpretPacket(unsigned char*, unsigned char);

// Flags
unsigned char isPacketCvcInfo(void);

// Get info functions
unsigned char getLeftPwm(void);
unsigned char getRightPwm(void);
unsigned char GetLeftDir(void);
unsigned char GetRightDir(void);

#endif /*InterpretPacket_H */