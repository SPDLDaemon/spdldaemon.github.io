/* ============================================================================
FILE: EventChecker.c 

DESCRIPTION:
This is the event checker for the motor pics
============================================================================ */

/* ----- INCLUDES ---------------------------------------------------------- */
#include <htc.h>
#include "Motors.h"
#include "SMReceive.h"
#include "SMEvents.h"
#include "EventChecker.h"
#include "InterpretPacket.h"



/* ----- CONSTANTS --------------------------------------------------------- */



/* ----- VARIABLES --------------------------------------------------------- */
static unsigned char time_bw_updates = 0;


/* ----- PROTOTYPES -------------------------------------------------------- */


/* ----- PROGRAM ----------------------------------------------------------- */

/*------------------------------------------------------------
Function: CheckEvents

Description:
	Event Checker for the PIC16_Zigbee Master State Machine

Author:
	ERY 5/6/2011

------------------------------------------------------------*/
Event_t CheckEvents(void){

// Default is no event
	Event_t current_event = EV_NO_EVENT;

// Check Motor Enable
	if (MTRE == 0 && PWME == 0) {
		// If the motors are currently enabled but the MTRE
		// pin, which is controlled by the master PIC is low,
		// Disable the motors.
		PWME = 1;	// set PWM to input (disabling it)
	} else if  (MTRE == 1 && PWME == 1) {
		MM_SetDC(NEUTRAL, FWD);
		PWME = 0;	// Enable PWM by setting it to output
	}
	
// Increment the update timer
	if (TMR1IF == 1) {
		// Reset the overflow flag
		TMR1IF = 0;
		
		// Increment the time between updates
		time_bw_updates++;
		
		// Shutdown the boat if there haven't been updates for a while
		if (time_bw_updates == MAX_TIME_BW_UPDATES) {
			MM_SetDC(NEUTRAL, FWD);
			LED ^= 1;
			time_bw_updates = 0;
		}
	}

// ***EV_UART_BYTE_RECEIVED***
	if(RCIF) // in PIR1 register
	{
		current_event = EV_UART_BYTE_RECEIVED;
	}	

// If Good Packet In:
	else if(isGoodPacketReceived())
	{
		if(isPacketCvcInfo())
		{
			if (MTRE == 1) {
				// getRightPwm() and getLeftPwm() now return updated values
				MM_UpdateMotorSpeed();
				time_bw_updates = 0;
			} 
		}
	}

// ***EV_BAD_PACKET_IN***
	else if(isBadPacketReceived())
	{
		current_event = EV_BAD_PACKET_IN;
	}

// RETURN
	return current_event;
}