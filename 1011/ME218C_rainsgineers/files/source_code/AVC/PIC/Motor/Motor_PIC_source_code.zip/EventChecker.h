/* ============================================================================
FILE: EventChecker.h
============================================================================ */

#ifndef _EVENTCHECKER_H_
#define _EVENTCHECKER_H_


// Constants
#define MAX_TIME_BW_UPDATES 10	// Number of overflows of TMR1 before the code
								// will stop the motors.
								
// Public Functions
Event_t CheckEvents(void);

#endif