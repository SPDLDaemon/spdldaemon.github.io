/* ============================================================================
FILE: ConfigFile.h 
============================================================================ */

#ifndef _CONFIGFILE_H_
#define	_CONFIGFILE_H_

// Config file for the program
__CONFIG (HS & UNPROTECT & WDTDIS & BORDIS & IESODIS & FCMDIS);

#endif