/****************************************************************************
 Header file for defining Events of the Zigbee Pic State Machine
 ****************************************************************************/
#ifndef SMEvents_H
#define SMEvents_H

#define	FALSE 			0
#define TRUE 			1

#define BIT0HI			0b00000001
#define BIT1HI			0b00000010
#define BIT2HI			0b00000100
#define BIT3HI			0b00001000
#define BIT4HI			0b00010000
#define BIT5HI			0b00100000
#define BIT6HI			0b01000000
#define BIT7HI			0b10000000

// Universal events take up 0,1 & 2. User Events start at 3
typedef enum {  
				// General Events
				EV_NO_EVENT,

				// Events for SMReceive
                EV_UART_BYTE_RECEIVED,
				//EV_GOOD_PACKET_IN,
				EV_BAD_PACKET_IN,

				EV_ATOLL_CAPTURE_SUCCESS,
				EV_ATOLL_CAPTURE_FAILED,
				EV_NEW_CVC_INFO,
				EV_TEAMMATE_HEARD,
				EV_TEAMMATE_ACHKNOWLEDGED,
				EV_TRANSMIT_SUCCESS,

			
} Event_t ;

#endif /*SMEvents_H */

