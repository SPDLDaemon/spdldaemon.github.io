/* ============================================================================
FILE: Motors.h
============================================================================ */

#ifndef _MOTORS_H_
#define _MOTORS_H_

// Test Harness
//#define TEST_MOTORS

//Pin Constants
#define LED 	RC0
#define BTN 	RC1
#define	MTRE	RC2	// Allows the master pic to turn the motors on/off
#define	DIR 	RC3	// Direction pin
#define ADDRESS RA2
#define PWME	TRISC5

// Address Definitions
#define LEFT_MTR 0	// Address pin low
#define RIGHT_MTR 1	// Address pin hi

// Speed definitions
#define NEUTRAL 0	// DC for the boat to stop
#define DC_SCALE 1/2 // Scales max DC down from 100 (DCmax = 80 here)
#define FWD 1		// Directions to drive the motor in
#define REV 0	

// Baud Rate
#define BAUD_CONST 129	// We use this constant to set the baud rate

// BitDefs
#define	BIT0HI	0b00000001
#define	BIT1HI	0b00000010
#define	BIT2HI	0b00000100
#define BIT3HI	0b00001000
#define BIT4HI	0b00010000
#define	BIT5HI	0b00100000
#define	BIT6HI	0b01000000
#define BIT7HI 	0b10000000

#define FALSE 0
#define TRUE 1

// Public Functions
void MM_InitPWM(void);
void MM_InitPins(void);
void MM_InitEUSART(void);
void MM_SetDC(signed char DC, unsigned char dir);
void MM_UpdateMotorSpeed(void);
void MM_InitTMR1(void);

#endif