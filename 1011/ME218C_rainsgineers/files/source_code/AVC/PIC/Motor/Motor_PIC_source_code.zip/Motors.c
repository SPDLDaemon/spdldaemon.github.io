/* ============================================================================
FILE: Motors.c 

DESCRIPTION:
This is a low level module that controls the initialization and operation of
the PWM system on the PIC.
============================================================================ */

/* ----- INCLUDES ---------------------------------------------------------- */
#include <htc.h>
#include "Motors.h"
#include "InterpretPacket.h"



/* ----- CONSTANTS --------------------------------------------------------- */



/* ----- VARIABLES --------------------------------------------------------- */


/* ----- PROTOTYPES -------------------------------------------------------- */


/* ----- PROGRAM ----------------------------------------------------------- */


/* ----------------------------------------------------------------------------
TEST HARNESS
---------------------------------------------------------------------------- */
#ifdef TEST_MOTORS

#include "ConfigFile.h"
void main(void);
	
void main(void) {
	MM_InitPins();
	MM_InitPWM();
	while (1) {
		if (BTN == 1) {
			MM_SetDC(78);
		}	
	}	
}

#endif

/* ----------------------------------------------------------------------------
FUNCTION: MM_InitPWM

DESCRIPTION:

PWM period = [(PR2) + 1]*4*Tosc*(TMR2 prescale value)
PWM high time = (CCPR1L:CCP1CON<5:4>)*Tosc*(TMR2 prescale value)
---------------------------------------------------------------------------- */
void MM_InitPWM(void) {
	/* Set PWM Operating Mode */
	CCP1M3 = 1;
	CCP1M2 = 1;
	CCP1M1 = 0; 
	CCP1M0 = 0; 	// CCP1M = 1100 PWM mode; P1A-P1D active high
	
	// P1M = 00 on reset, which corresponds to single output
	
	/* Set PWM Frequency */
	PR2 = 199;
	
	T2CKPS1 = 0;	// Set the timer 2 prescaler to 0 (00)
	T2CKPS0 = 0;
	
	/* Set PWM Duty Cycle */
	CCPR1L = 0;		// Set the duty cycle to 0% 
	DC1B1 = 0;		// DC = (CCPR1L:CCP1CON<5:4>)/([(PR2) + 1]*4)	
	DC1B0 = 0; 
	
	/* Enable PWM Output */
	TMR2IF = 0;		// Clear the timer 2 interrupt flag
	TMR2ON = 1;		// Turn on TMR 2
	TRISC5 = 0;		// Enable output
}	

/* ----------------------------------------------------------------------------
FUNCTION: MM_InitPins

DESCRIPTION:
Initializes the LED, BTN, and ADDRESS ports, turns off ANSEL and ANSELH
---------------------------------------------------------------------------- */
void MM_InitPins(void) {
	ANSEL = 0;
	ANSELH = 0;	// Turn off analog
	
	LED = 1;	// LED hi on powerup
	TRISC0 = 0;	// LED pin is an output
	
	// The Motor Enable pin (MTRE) is input by default
	
	DIR = FWD;	// Set DIR to FWD initially
	TRISC3 = 0; // Set DIR to output
	
	// the BTN pin is an input by default
	// the ADDRESS pin is also an input by default
}	

/* ----------------------------------------------------------------------------
FUNCTION: InitEUSART

This function initializes the UART hardware for communication with the security
controller.

Baud Rate = Fosc/[16(SPBRGH:SPBRG + 1)] = 9615
This particular equation applies when BRGH = 1, See pg 135 in the datasheet
---------------------------------------------------------------------------- */
void MM_InitEUSART(void) {
	BRGH = 1;			// Hi baud rate select bit
	SPBRG = BAUD_CONST;	// Set the baud rate
	SPEN = 1;			// Enable the serial ports
	CREN = 1;			// Enable continuous receive
	TXEN = 1;			// Enable transmit
}

void MM_InitTMR1(void) {
	T1CKPS1 = 1;	// T1CKPS = 11	1:8 prescaler
	T1CKPS0 = 1;
	
	TMR1IF = 0;		// Clear the overflow flag
	TMR1ON = 1;		// Enable timer 1
}

/* ----------------------------------------------------------------------------
FUNCTION: MM_SetDC

PARAMETERS:
DC:	A number from 0 to 100 specifying the duty cycle

DESCRIPTION:
The duty cycle in the PIC is a 10 bit number.  The code takes in a DC from
0-100, scales it to a DC from 0-1023 (rounding up when necessary), and
writes it to the three DC registers.


---------------------------------------------------------------------------- */
void MM_SetDC(signed char DC, unsigned char dir) {
	//DC = (DC - 50)*DC_SCALE + 50;
	DC = DC*DC_SCALE;
	CCPR1L = DC*2; 
	DIR = dir;
	//DC = (unsigned int) ((((unsigned long) DC)*1023 + 50)/100);
	//CCPR1L = (unsigned char) (DC>>2); // Upper 8 bits of DC
	//DC1B1 = ((DC & BIT1HI)>>1);		  // Bit 1 of DC
	//DC1B0 = (DC & BIT0HI);			  // Bit 0 of DC
}	

/* ----------------------------------------------------------------------------
FUNCTION: MM_UpdateMotorSpeed

DESCRIPTION:
This function is called everytime the ACV has received new motor speed commands
from the CVC.  It checks the address pin to determine whether this pic is the
left or the right motor, and updates the PWM accordingly.
---------------------------------------------------------------------------- */
void MM_UpdateMotorSpeed(void) {
	if (ADDRESS = LEFT_MTR) {
		MM_SetDC(getLeftPwm(), GetLeftDir());
	} else {
		MM_SetDC(getRightPwm(), GetRightDir());
	}			
}	
