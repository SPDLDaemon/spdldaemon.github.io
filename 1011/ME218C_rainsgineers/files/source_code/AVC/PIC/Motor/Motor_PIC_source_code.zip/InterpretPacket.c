/****************************************************************************
 Module
   InterpretPacket.c

 Description
   Holds functions that will interpret an incoming packet after it has been
   confirmed to have a good checksum

	Receive packet will raise a goodPacketReceived event.  This module will
	hold the module variable of the 


 Notes

 History
 When           Who     What/Why
 -------------- ---     --------
 05/09/11  		ERY  	ME218C ATOLL Project

****************************************************************************/
#include <htc.h>
#include "InterpretPacket.h"
#include "Motors.h"
#include "218ZigbeeProtocol.h"


//------------------------------------------------------------
// FLAGS and Module Variables


// [C2B]: Receiving Command from the CVC 
unsigned char cvc_right_pwm = 0;
unsigned char cvc_left_pwm = 0;
unsigned char cvc_info_flag = FALSE;
unsigned char cvc_left_dir = FWD;
unsigned char cvc_right_dir = FWD;


//===========================================================================
// PUBLIC FUNCTIONS
//===========================================================================

/*------------------------------------------------------------
Function: interpretPacket

Arguments:
	unsigned char* data_received ... the array of data from Zigbee
	unsigned char data_length ... the number of elements in the array

Description:
	This function will determine what the incoming UART message
	from the Zigbee is and will save the important data to a module
	variable to be exported through a public function.  

	This function 
	also raises the appropriate flag for the event checker to be 
	alerted that a certain type of message has been received (so the right
	public function can be called to collect the data.

	NOTE:
	This function should be called in the SMReceive State Machine
	after the checksum has been confirmed.

Author:
	ERY 5/9/2011

------------------------------------------------------------*/
void interpretPacket(unsigned char* data_received, unsigned char data_length)
{


//------------------------------------------------------------
// [C2B]: Receiving Command from the CVC 
	// If the command type byte in the received data is an RP Command
	if( data_received[R_DBYTE_NUM_CMD_T] == CMD_T_C2B )
	{
		//cvc_info = data_received[C2B_DBYTE_NUM_INFO];
		cvc_right_pwm = data_received[C2B_DBYTE_NUM_PWMR] & (~DIRBIT);
		cvc_right_dir = data_received[C2B_DBYTE_NUM_PWMR]>>7;
		cvc_left_pwm = data_received[C2B_DBYTE_NUM_PWML] & (~DIRBIT);
		cvc_left_dir = data_received[C2B_DBYTE_NUM_PWML]>>7;
		cvc_info_flag = TRUE;
		LED = 0;
	}

}

//===========================================================================
// PUBLIC FLAG FUNCTIONS
//===========================================================================

/*------------------------------------------------------------
Function: isPacketCvcInfo

Description:
	If cvc_info_flag is high, 
		then returns TRUE and lowers the flag
	Else returns FALSE

Author:
	ERY 5/11/2011

------------------------------------------------------------*/
// [C2B]: Receiving Command from the CVC 
unsigned char isPacketCvcInfo(void){
	if(cvc_info_flag == TRUE)
	{
		cvc_info_flag = FALSE;
		return TRUE;
	} else
	{
		return FALSE;
	}
}



//===========================================================================
// PUBLIC GET INFO FUNCTIONS
//===========================================================================

/*------------------------------------------------------------
Function: getRightPwm

Description:
	returns byte corresponding to right motor PWM

Author:
	ERY 5/13/2011

------------------------------------------------------------*/
// [C2B]: Receiving Command from the CVC  
unsigned char getRightPwm(void)
{
	return cvc_right_pwm;
}

/*------------------------------------------------------------
Function: getLeftPwm

Description:
	returns byte corresponding to left motor PWM

Author:
	ERY 5/13/2011

------------------------------------------------------------*/
// [C2B]: Receiving Command from the CVC  
unsigned char getLeftPwm(void)
{
	return cvc_left_pwm;
}

unsigned char GetLeftDir(void) {
	return cvc_left_dir;
}

unsigned char GetRightDir(void) {
	return cvc_right_dir;
}