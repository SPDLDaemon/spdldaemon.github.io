/* ============================================================================
FILE: MOTOR_PIC.c 

DESCRIPTION:
This is the main program for the motor PIC.  It runs the Receive State Machine,
which receives XBee messages over the UART and determines whether they are for
the motor PIC.  If they are, the PWM values are extracted and written to the
PWM register.
============================================================================ */

/* ----- INCLUDES ---------------------------------------------------------- */
#define _LEGACY_HEADERS
#include <htc.h>
#include "ConfigFile.h"
#include "Motors.h"
#include "SMReceive.h"
#include "EventChecker.h"
#include "SMEvents.h"

/* ----- CONSTANTS --------------------------------------------------------- */



/* ----- VARIABLES --------------------------------------------------------- */



/* ----- PROTOTYPES -------------------------------------------------------- */
void main(void);


/* ----- PROGRAM ----------------------------------------------------------- */
void main(void) {
	MM_InitPWM();
	MM_InitEUSART();
	MM_InitPins();
	MM_InitTMR1();
	InitReceiveSM();
	
	while (1) {
		RunReceiveSM(CheckEvents());
	}	
}	