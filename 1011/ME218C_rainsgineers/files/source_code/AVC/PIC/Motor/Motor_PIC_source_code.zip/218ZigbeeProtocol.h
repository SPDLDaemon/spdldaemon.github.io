/****************************************************************************
 ME218C 2011 UART-ZIGBEE PROTOCOL
****************************************************************************/
		
//===========================================================================
// RECEIVE MESSAGES
//===========================================================================

//--------------------------------------------------------------------------
// General

#define START_DELIMITER 		0x7E	// Marks the start of the transmission

// General Bytes *FOR INCOMING PACKET API ID
#define R_DBYTE_NUM_API_ID		0x00	// 1-1 = array index in data section
#define R_DBYTE_NUM_SRC_MSB		0x01	// 2-1 = array index in data section
#define R_DBYTE_NUM_SRC_LSB		0x02	// 3-1 = array index in data section
#define R_DBYTE_NUM_RSSI		0x03	// 4-1 = array index in data section
#define R_DBYTE_NUM_OPTIONS		0x04	// 5-1 = array index in data section
#define R_DBYTE_NUM_CMD_T		0x05	// 6-1 = array index in data section

// Command types
#define CMD_T_C2B			0xCD	// For [C2B]: Receiving Command from the CVC


//--------------------------------------------------------------------------
// [C2B]: Receiving Command from the CVC 

#define C2B_DBYTE_NUM_INFO	0x06	// 7-1 = array index in data section

// NOTE: PWM Signals will be read directly by PWM Pics...
#define C2B_DBYTE_NUM_PWMR	0x07	// 8-1 = array index in data section
#define C2B_DBYTE_NUM_PWML	0x08	// 9-1 = array index in data section
#define DIRBIT 0b10000000			// Direction bit in the PWM signal



