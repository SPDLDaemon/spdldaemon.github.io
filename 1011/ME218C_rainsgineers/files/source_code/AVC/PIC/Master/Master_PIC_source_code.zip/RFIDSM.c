/* ============================================================================
FILE: RFIDSM.c 

DESCRIPTION:
This is the code for the RFID state machine.  It reads RFID serials from the
RFID PIC, and determines whether they are atolls or team cards.
============================================================================ */

/* ----- INCLUDES ---------------------------------------------------------- */
#include <htc.h>
#include "EventChecker.h"
#include "Events.h"
#include "Initialization.h"
#include "RFIDSM.h"
#include "SPI_SM.h"
#include "XBeeSM.h"


/* ----- CONSTANTS --------------------------------------------------------- */

/*
unsigned char atollSerials[10] = {	0x47, 0x66,	// Atoll 1
									0xC8, 0xE0, // Atoll 2
									0x36, 0x31, // Atoll 3
							 		0xF5, 0xF0, // Atoll 4
									0x5E, 0x6A  // Atoll 5
};
*/

/* ----- VARIABLES --------------------------------------------------------- */
static RFIDSM_State_t currentState = ST_IDLING; // Initialize the SM to idling
static unsigned char RFID_Serials[NUM_RFID_SERIALS];
static unsigned char currentAtoll = 0;
static unsigned char myTeam = WHITE;




/* ----- PROTOTYPES -------------------------------------------------------- */
void ProcessData(void);


/* ----- PROGRAM ----------------------------------------------------------- */

/* ----------------------------------------------------------------------------
TEST HARNESS
---------------------------------------------------------------------------- */
#ifdef TEST_RFIDSM	

#include "ConfigFile.h"
void main(void);

void main(void) {
	Event_t event;
	InitSSP();
	InitPins();
	InitEventChecker();
	InitRFIDSM();
	
	while(1) {
		event = CheckEvents();
		RunRFIDSM(event);
		RunSPI_SM(event);
	}	
}

#endif

	



/* ----------------------------------------------------------------------------
FUNCTION: RunRFIDSM

This state machine receives RFID serial numbers from the RFID_PIC
---------------------------------------------------------------------------- */
void RunRFIDSM(Event_t event) {
	unsigned char i;	// Index for the RFID Data array
	unsigned char *ptr;	// Pointer used for copying received arrays
	
	// Do a switch on the state
	switch (currentState) {
		
		case ST_IDLING:
			// Do a switch on the event
			switch (event) {
				
				case EV_RFID_DATA_READY:
					// Receive the RFID data from the RFID_PIC
					ReceiveSPI(SS_RFID_PIC);
					
					// Change states
					currentState = ST_RX_RFID_DATA;
					break;
					
			}
			break;		
		
		case ST_RX_RFID_DATA:
			// Do a switch on the event
			switch (event) {
				
				case EV_RECEIVED_SPI_DATA_READY:
					// Copy the received data to a local array
					ptr = GetRxData();
					for (i = 0; i < NUM_RFID_SERIALS; i++) {
						RFID_Serials[i] = ptr[i];
					}
					// Process the data and change the state	
					ProcessData();	
					currentState = ST_IDLING;
					break;
					
			}
			break;
	}
}								
							

/* ----------------------------------------------------------------------------
FUNCTION: ProcessData

This function determines whether the serials from a recently-scanned RFID card
belong to a team card or an atoll card.
---------------------------------------------------------------------------- */
void ProcessData(void) {
	unsigned char i;
	
	switch (RFID_Serials[2]) {
		case RED_CARD:
			SetTeam(RED);
			SetNewTeamAssignedFlag();
			break;
		case GREEN_CARD:
			SetTeam(GREEN);
			SetNewTeamAssignedFlag();
			break;
		case WHITE_CARD:
			SetTeam(WHITE);
			SetNewTeamAssignedFlag();
			break;
		default:
			// It's an atoll not a team
			SetAtollSerialsArrivedFlag();
			break;
	}
}

/* ----------------------------------------------------------------------------
FUNCTION: GetRFIDSerials

Returns the pointer to the RFID Serial number array

Public function
---------------------------------------------------------------------------- */
unsigned char *GetRFIDSerials(void) {
	return RFID_Serials;
}

/* ----------------------------------------------------------------------------
FUNCTION: InitRFIDSM

Sets the initial state for the RFID SM
---------------------------------------------------------------------------- */		
void InitRFIDSM(void) {
	currentState = ST_IDLING;
}				