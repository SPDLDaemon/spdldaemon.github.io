/* ============================================================================
FILE: EventChecker.h 
============================================================================ */

#ifndef _EVENTCHECKER_H_
#define _EVENTCHECKER_H_
#include "Events.h"

// PUBLIC FUNCTIONS
Event_t CheckEvents(void);
void InitEventChecker(void);
void SetAtollSerialsArrivedFlag(void);
void SetAtollSKArrivedFlag(void);
void SetNewTeamAssignedFlag(void);
void SetReceivedDataReadyFlag(void);
void SetSendSPICompleteFlag(void);


#endif