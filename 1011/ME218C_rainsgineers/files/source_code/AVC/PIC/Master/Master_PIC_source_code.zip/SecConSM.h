/* ============================================================================
FILE: SecConSM.h
============================================================================ */

#ifndef _SECCONSM_H_
#define _SECCONSM_H_

// Test Harness
//#define TEST_SECCONSM

// State definitions - Security Controller State Machine
typedef enum {	ST_WAITING_FOR_SK_FLAG,
				ST_SENDING_SC_START_BYTE,	
				ST_SENDING_SC_RFID_DATA,
				ST_SENDING_SC_STOP_BYTE,
				ST_WAITING_FOR_SC_RESPONSE,
				ST_RECEIVING_SKEYS		
} SecConSM_State_t;

// Public Functions
void RunSecConSM(Event_t event);
void InitSecConSM(void);
unsigned char *GetSecurityKeys(void);

#endif