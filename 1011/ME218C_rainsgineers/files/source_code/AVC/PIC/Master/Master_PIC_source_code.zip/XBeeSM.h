/* ============================================================================
FILE: XBeeSM.h 
============================================================================ */

#ifndef _XBEESM_H_
#define _XBEESM_H_

// Test Harness
//#define TEST_XBEESM

// States
typedef enum {	ST_XBEE_SM_IDLING = 0,
				ST_WAITING_FOR_SPI = 1,
				ST_SENDING_MSG = 2 		 
} XBeeSMState_t;

// Public Functions
void RunXBeeSM(Event_t event);
void SetTeam(unsigned char TC);
void InitXBeeSM(void);

#endif