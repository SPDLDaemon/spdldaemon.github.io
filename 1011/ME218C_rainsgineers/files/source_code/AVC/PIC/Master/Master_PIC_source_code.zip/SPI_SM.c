/* ============================================================================
FILE: SPI_SM.c 

DESCRIPTION:
This state machine sends messages over SPI.  It must be run on the master.
============================================================================ */

/* ----- INCLUDES ---------------------------------------------------------- */
#include <htc.h>
#include "EventChecker.h"
#include "Events.h"
#include "SPI_SM.h"
#include "Initialization.h"


/* ----- CONSTANTS --------------------------------------------------------- */
#define RX_PACKET_ARRAY_LENGTH 25

/* ----- VARIABLES --------------------------------------------------------- */
static SPI_SM_State_t currentState;
static unsigned char *arrayPtr;		// Array containing packet to send
static unsigned char dataLength;	// Length of the data in the array
static unsigned char slave;			// Slave to send to
static unsigned char i;				// Array index
static unsigned char rxPacketArray[RX_PACKET_ARRAY_LENGTH];


/* ----- PROTOTYPES -------------------------------------------------------- */
void SendByte(unsigned char byte, unsigned char slave);


/* ----- PROGRAM ----------------------------------------------------------- */

/* ----------------------------------------------------------------------------
TEST HARNESS

Description
This test harness initializes all the necessary stuff to run the module.
When you press the debug pin, it will simulate a send command to the XBEE_PIC.
---------------------------------------------------------------------------- */
#ifdef TEST_SPI_SM
#include "ConfigFile.h"
void main(void);

// Test Sending
/*
void main(void) {
	unsigned char nPresses = 0;
	unsigned char testArray[8] = {0x20, 0x22, 0x24, 0x26, 0x28, 0x2A, 0x2C, 0x2E};
	InitSPI_SM();
	InitSSP();
	InitPins();
	
	while(1) {
		// If the button is pressed, send data
		if (DEBUG_PIN == 1 && nPresses < 1) {
			SendSPI(testArray, 8, SS_XBEE_PIC);
			nPresses = 1;
		}
		RunSPI_SM(CheckEvents());
	}
}
*/

// Test Receiving
void main(void) {
	unsigned char nPresses = 0;
	InitSPI_SM();
	InitSSP();
	InitPins();
	
	while(1) {
		// If the button is pressed, receive data
		if (DEBUG_PIN == 1 && nPresses < 1) {
			ReceiveSPI(SS_XBEE_PIC);
			nPresses = 1;
		}
		RunSPI_SM(CheckEvents());
	}
}

#endif


/* ----------------------------------------------------------------------------
FUNCTION: SendSPI

Parameters:
ptr - This is the pointer to the array containing the packet you want to send.
len - This is the length of the packet, in number of bytes
slv - This is the slave to who you are sending the packet to.

Returns:
1 - Command to send was successful
0 - Command to send was unsuccessful

Description:
This function is used to send a packet over SPI.  First it copies the
the parameters you give it to static module level variables.  Then it sends
the first byte of data.  Finally, it sets the state of the SendSPI_SM to
ST_SENDING_SPI_DATA

It returns a 1 if the command to send was successful and a 0 otherwise.
Commands to send will be unsuccessful if the SPI_SM is in the process
of sending or receiving something else.
---------------------------------------------------------------------------- */

unsigned char SendSPI(unsigned char *ptr, unsigned char len, unsigned char slv) {
	if (currentState == ST_WAITING_FOR_COMMAND) {
		// If the state machine is idling
		
		// Assign the parameters to static module level variables 
		arrayPtr = ptr;
		dataLength = len;
		slave = slv;
		
		// Send the first byte of data
		i = 0;
		SendByte(arrayPtr[i], slave);
		i++;
		
		// Change the current state
		currentState = ST_SENDING_SPI_DATA;
		
		// return 1  for success
		return 1;
		
	} else {
		// return 0 for failure
		return 0;
	}	
}

/* ----------------------------------------------------------------------------
FUNCTION: ReceiveSPI

PARAMETERS:
slv - This is the slave from whom you would like to receive the packet

RETURNS:
1 - Command to send was successful
0 - Command to send was unsuccessful

DESCRIPTION:
This function is used to receive a packet over SPI.  You just need to give it
the slave from whom it should receive, and then it will feed dummy bytes to it
until the slave's event line goes hi.  The received bytes are copied to a local
array, and you can use another function to obtain the pointer to that array.

It returns a 1 if the command to send was successful and a 0 otherwise.
Commands to send will be unsuccessful if the SPI_SM is in the process
of sending or receiving something else.
---------------------------------------------------------------------------- */
unsigned char ReceiveSPI(unsigned char slv) {
	if (currentState == ST_WAITING_FOR_COMMAND) {
		// If the state machine is idling
		
		// Copy the parameters
		slave = slv;
		
		// receive the first byte of data
		SendByte(DUMMY_BYTE, slave);
		// Change the current state
		currentState = ST_RECEIVING_SPI_LENGTH;
		
		// return 1 for success
		return 1;
		
	} else {
		// return 0 for failure
		return 0;
	}
}			

/* ----------------------------------------------------------------------------
FUNCTION: RunSPI_SM
 
This function runs the SPI State Machine.  If the SPI buffer is free, it
will send or receive another byte.  If all bytes have been sent/received,
it will change the state to idling.
---------------------------------------------------------------------------- */
void RunSPI_SM(Event_t event) {
	// Do a switch on the state
	switch (currentState) {
		
		case ST_SENDING_SPI_DATA:
			// Do a switch on the event
			switch (event) {
			
				case EV_SPI_BUFFER_FULL:
				// Sending has completed
				if (i < dataLength) {
					// If there's still more data to send, send it
					SendByte(arrayPtr[i], slave);
					i++;
					
				} else {
					// We've sent all our data
					// Read the SPI buffer to clear the BF flag
					SSPBUF;	
					// Change states 
					currentState = ST_WAITING_FOR_COMMAND;
					SetSendSPICompleteFlag();
				}
				break;
				
			}
			break;
		
		case ST_RECEIVING_SPI_LENGTH:
			// Do a switch on the event
			switch (event) {
				
				case EV_SPI_BUFFER_FULL:
					// We have received the length byte
					dataLength = SSPBUF;
					i = 0;
					//Receive the first data byte
					SendByte(DUMMY_BYTE, slave);
					// Change states
					currentState = ST_RECEIVING_SPI_DATA;
					break;
					
			}	
			break;
					
		case ST_RECEIVING_SPI_DATA:
			// Do a switch on the event
			switch (event) {
				
				case EV_SPI_BUFFER_FULL:
					// We have received a new byte.
					rxPacketArray[i] = SSPBUF;
					// Increment the index
					i++;
					
					if (i < dataLength) {
						// Receive another byte
						SendByte(DUMMY_BYTE, slave);
						
					} else {
						// We are finished receiving
						// Change states
						currentState = ST_WAITING_FOR_COMMAND;
						// Raise the flag
						SetReceivedDataReadyFlag();
					}								
					break;
					
			}		
			break;
			
	}
}

/* ----------------------------------------------------------------------------
FUNCTION: SendByte

Parameters:
byte - The byte you want to send
slave - The slave you want to send to

Description: 
This function sends a byte over SPI.  It asserts the appropriate slave select
line, and writes the byte to the SSPBUF for sending.
---------------------------------------------------------------------------- */
void SendByte(unsigned char byte, unsigned char slave) {
	PORTC &= ~slave;	// Drop the SS line low for that slave
	SSPBUF = byte;		// Load the message in the SSP Buffer
}	


/* ----------------------------------------------------------------------------
FUNCTION: GetStateSPI_SM

Returns:
Returns the current state of the SPI state machine
---------------------------------------------------------------------------- */
SPI_SM_State_t GetStateSPI_SM(void) {
	return currentState;
}

/* ----------------------------------------------------------------------------
FUNCTION: InitSPI_SM

DESCRIPTION:
This  function initializes the SPI_SM by setting the currentState to
ST_WAITING_FOR_DATA
---------------------------------------------------------------------------- */
void InitSPI_SM(void) {
	currentState = ST_WAITING_FOR_COMMAND;
}

/* ----------------------------------------------------------------------------
FUNCTION: GetRxData

DESCRIPTION:
This function returns the pointer to the array containing recently received
data
---------------------------------------------------------------------------- */
unsigned char *GetRxData(void) {
	return rxPacketArray;
}	


/* ----------------------------------------------------------------------------
FUNCTION: IsSPIFree

DESCRIPTION:
This function returns true if the SPISM is idling, false otherwise.
---------------------------------------------------------------------------- */
unsigned char IsSPIFree(void) {
	if (currentState == ST_WAITING_FOR_COMMAND) {
		return  TRUE;
	} else {
		return FALSE;
	}
}