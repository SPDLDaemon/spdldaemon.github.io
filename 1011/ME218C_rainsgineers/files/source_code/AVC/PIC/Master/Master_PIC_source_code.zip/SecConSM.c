/* ============================================================================
FILE: SecConSM.c 

DESCRIPTION:
This is the state machine that runs from the MASTER_PIC and interfaces with the
security controller.  It sends RFID bytes to the SC and receives the encrypted
security keys back.
============================================================================ */

/* ----- INCLUDES ---------------------------------------------------------- */
#include <htc.h>
//#include "ConfigFile.h"
#include "EventChecker.h"
#include "Events.h"
#include "SecConSM.h"
#include "RFIDSM.h"
#include "Initialization.h"


/* ----- CONSTANTS --------------------------------------------------------- */
#define SC_START_BYTE	0x04	// Start byte for the sec controller packet
#define	SC_STOP_BYTE	0x08	// Stop byte for the Security Controller Packet
#define SK_ARRAY_LG		6		// The array of serial keys is 6 long


/* ----- VARIABLES --------------------------------------------------------- */
static SecConSM_State_t currentState = ST_WAITING_FOR_SK_FLAG;
static unsigned char *RFIDSerialsPtr;	// Pointer used to access the serials
static unsigned char SKArray[SK_ARRAY_LG];




/* ----- PROTOTYPES -------------------------------------------------------- */
void InitEUSART(void);

// For testing
#ifdef TEST_SECCONSM
unsigned char *GetRFIDSerials(void);
void main(void);
#endif


/* ----- PROGRAM ----------------------------------------------------------- */

/* ----------------------------------------------------------------------------
TEST HARNESS

The test harness allows this module to run independently.  It hardcodes the
RFID serial input as {0x83, 0xE0, 0xF5}, initializes EUSART pin
---------------------------------------------------------------------------- */
#ifdef TEST_SECCONSM

void main(void) {
	InitEUSART();
	InitPins();
	InitEventChecker();
	while(1) {
		if (DEBUG_PIN == 1) {
			SetAtollSerialsArrivedFlag();
		}	
		RunSecConSM(CheckEvents());
	}
}

unsigned char *GetRFIDSerials(void) {
	static unsigned char RFIDSerialArray[LENGTH_RFID_SERIALS] = {0x83, 0xE0, 0xF5};
	return RFIDSerialArray;
}
	
#endif



/* ----------------------------------------------------------------------------
FUNCTION: RunSecConSM

This function runs the security controller state machine, which shuttles bytes
to and from the security controller via EUSART.
---------------------------------------------------------------------------- */
void RunSecConSM(Event_t event) {
	static unsigned char i;
	
	// Do a switch on the current state
	switch(currentState) {
		
		// ------------------------------------------------
		
		case ST_WAITING_FOR_SK_FLAG:
			// do a switch on the event
			switch (event) {
				
				case EV_ATOLL_SERIALS_ARRIVED:
					// Send the packet start byte
					TXREG = SC_START_BYTE;
					// Initialize the array index for later
					i = 0;
					// Change states
					currentState = ST_SENDING_SC_START_BYTE;
					// Get a pointer to the array of RFID Serials
					RFIDSerialsPtr = GetRFIDSerials();
					break;
					
			}
			break;
		
		// ------------------------------------------------
		
		case ST_SENDING_SC_START_BYTE:
			// Do a switch on the event
			switch (event) {
				
				case EV_TX_BUFFER_EMPTY:
					
					// Send the first byte of RFID data
					TXREG = RFIDSerialsPtr[i];
					// Increment the index
					i++;
					// Change states
					currentState = ST_SENDING_SC_RFID_DATA;
					break;
			
			}
			break;
		
		// ------------------------------------------------
			
		case ST_SENDING_SC_RFID_DATA:
			// Do a switch on the event
			switch(event) {
				
				case EV_TX_BUFFER_EMPTY:
					if (i < 3) {
						// If there is more data to send, send data
						TXREG = RFIDSerialsPtr[i];
						// Increment the index
						i++;
					} else {
						// We are done sending the serials and need to send
						// the stop byte
						TXREG = SC_STOP_BYTE;
						// Change states
						currentState = ST_SENDING_SC_STOP_BYTE;
					}	
					break;	
					
			}
			break;
		
		// ------------------------------------------------
			
		case ST_SENDING_SC_STOP_BYTE:
			// Do a switch on the event
			switch (event) {
				
				case EV_TX_BUFFER_EMPTY:
					// Change states
					currentState = ST_WAITING_FOR_SC_RESPONSE;
					break;
					
			}
			break;
			
		// ------------------------------------------------
		
		case ST_WAITING_FOR_SC_RESPONSE:
			// Do a switch on the event
			switch(event) {
				
				case EV_RX_BUFFER_FULL:
					// Initialize the index
					i = 0;
					// Store first serial key in the array
					SKArray[i] = RCREG;
					i++;
					// Change states
					currentState = ST_RECEIVING_SKEYS;
					break;
					
			}
			break;
		
		// ------------------------------------------------\
		
		case ST_RECEIVING_SKEYS:
			// Do a switch on the event
			switch (event) {
				case EV_RX_BUFFER_FULL:
					// Store the SK in the array
					SKArray[i] = RCREG;
					i++;
					if (i >= SK_ARRAY_LG) {
						// If we've received all the SKs, change states
						currentState = ST_WAITING_FOR_SK_FLAG;
						// Raise the flag
						SetAtollSKArrivedFlag();
						//STATUS_LT ^= 1;
					}
					break;
			}
			break;
										
	}
}	
					
/* ----------------------------------------------------------------------------
FUNCTION: InitSecConSM

Sets the initial state of the SecCon SM
---------------------------------------------------------------------------- */				
void InitSecConSM(void) {
	currentState = ST_WAITING_FOR_SK_FLAG;
}	

/* ----------------------------------------------------------------------------
FUNCTION: GetAtollSKs

returns the pointer to the atoll security key array
---------------------------------------------------------------------------- */	
unsigned char *GetSecurityKeys(void) {
	return SKArray;
}