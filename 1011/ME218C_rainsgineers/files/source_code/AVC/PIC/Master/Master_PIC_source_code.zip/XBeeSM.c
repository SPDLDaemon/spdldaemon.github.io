/* ============================================================================
FILE: XBeeSM.c 

DESCRIPTION:
This is the state machine that sends messages to the XBee Pic.
============================================================================ */

/* ----- INCLUDES ---------------------------------------------------------- */
#include <htc.h>
#include "EventChecker.h"
#include "Events.h"
#include "Initialization.h"
#include "SPI_SM.h"
#include "XBeeSM.h"
#include "RFIDSM.h"
#include "SPI_SM.h"
#include "SecConSM.h"


/* ----- CONSTANTS --------------------------------------------------------- */
unsigned char atollSerials[10] = {	0x47, 0x66,	// Atoll 1
									0xC8, 0xE0, // Atoll 2
									0x36, 0x31, // Atoll 3
							 		0xF5, 0xF0, // Atoll 4
									0x5E, 0x6A  // Atoll 5
};

#define RQ_PKT_LEN 9	// 9 data bytes required for atoll capture
#define	FT_PKT_LEN 1	// 1 byte of data (TC) to find a teammate
#define NUM_ATOLLS 5	// The  number of atolls on the field


/* ----- VARIABLES --------------------------------------------------------- */
// The max length of the packet array is RQ_PKT_LEN + 1, which is enough to
// contain the 9 bytes of data necessary to capture an atoll plus the one byte
// denoting the packet length.
static unsigned char packet [RQ_PKT_LEN + 1];
static unsigned char pktLen;
static XBeeSMState_t currentState;
static unsigned char teamColor;



/* ----- PROTOTYPES -------------------------------------------------------- */
void MakeAtollPacket(void);
unsigned char GetAtollNum(unsigned char S3);
void MakeTeamPacket(void);

/* ----- PROGRAM ----------------------------------------------------------- */


/* ----------------------------------------------------------------------------
TEST HARNESS
---------------------------------------------------------------------------- */
#ifdef TEST_XBEESM
#include "ConfigFile.h"
void main(void);
unsigned char *GetSecurityKeys(void);
unsigned char *GetRFIDSerials(void);

unsigned char *GetSecurityKeys(void) {
	static unsigned char array[6] = {0x10, 0x20, 0x30, 0x40, 0x50, 0x60};
	return array;
}

unsigned char *GetRFIDSerials(void) {
	static unsigned char array[3] = {0xA1, 0xA2, 0xE0};
	return array;
}

void main(void) {
	static unsigned char nPresses = 0;
	Event_t event;
	InitSSP();
	InitPins();
	InitEventChecker();
	InitXBeeSM();
	SetTeam(RED);
	while (1) {
		if (DEBUG_PIN == 1) {
			//SetAtollSKArrivedFlag();
			SetNewTeamAssignedFlag();
			nPresses++;
		}
		event = CheckEvents();
		RunXBeeSM(event);
		RunSPI_SM(event);
	}
}
#endif

/* ----------------------------------------------------------------------------
FUNCTION: RunXBeeSM

DESCRIPTION
This function handles all the state and event checking for the XBeeSM.
---------------------------------------------------------------------------- */
void RunXBeeSM(Event_t event) {
	// Do a switch on the state
	switch (currentState) {
		
		case ST_XBEE_SM_IDLING:
			// Do a switch on the event
			switch (event) {
				
				case EV_SK_ARRIVED:
					// Assemble the packet to send to the XBee Pic
					MakeAtollPacket();
					// Change states
					currentState = ST_WAITING_FOR_SPI;
					break;
					
				case EV_NEW_TEAM_ASSIGNED:
					// Assemble the packet
					MakeTeamPacket();
					// Change states
					currentState = ST_WAITING_FOR_SPI;
					
			}
			break;
			
		case ST_WAITING_FOR_SPI:
			if (IsSPIFree() == TRUE)  {
				// If the SPI module is free, send the packet and change states
				SendSPI(packet, pktLen, SS_XBEE_PIC);
				currentState = ST_SENDING_MSG;
			}
			break;
			
		case ST_SENDING_MSG:
			// Do a switch on the event
			switch (event) {
			
				case EV_SPI_SEND_COMPLETE:
					// We've sent the message, the XBee pic will take
					// care of the rest.
					currentState = ST_XBEE_SM_IDLING;
					break;
					
			}
			break;
			
	}
}

/* ----------------------------------------------------------------------------
FUNCTION: MakeAtollPacket

DESCRIPTION
This function collects the security keys and RFID serials and creates the
packet to send to the XBee in order to capture the atoll.

The atoll  packet should contain
LN,RQ,TC,AN,S1,S2,S3,SK1,SK2,SK3

LN:      The length of the rest of the packet (this is required by our team
		 communication protocol)

RQ:		 the Request Capture Byte (0x66) 

TC:		 the current team color of the ACV attempting to take control 
		 (Red = 0xFE, Green = 0x01, unoccupied = 0x88)
		 
AN:		 the Atoll number

S1-S3:	 the serial number bytes from the RFID tag read from the Atoll

SK1-SK3: the security key values obtained by the security controller
		 S1 and SK1 are the most significant bytes (received first)
		 and S3 and SK3 are the least significant. 
---------------------------------------------------------------------------- */
void MakeAtollPacket(void) {
	// Acquire the neccesary arrays to create the packet
	unsigned char *sk = GetSecurityKeys();
	unsigned char *serials = GetRFIDSerials();
	
	// Build the packet
	packet[0] = RQ_PKT_LEN;		// LN = number of bytes to follow
	packet[1] = RQ;
	packet[2] = teamColor;		// TC
	packet[3] = GetAtollNum(serials[2]); 	// AN
	packet[4] = serials[0];
	packet[5] = serials[1];
	packet[6] = serials[2];
	packet[7] = sk[0];
	packet[8] = sk[2];
	packet[9] = sk[4];
	
	pktLen = RQ_PKT_LEN + 1;	// Length of atoll capture data + a length byte
}


/* ----------------------------------------------------------------------------
FUNCTION: GetAtollNum

PARAMETERS:
S3 = the LSB of the atoll serial number

DESCRIPTION
This function returns the number of the atoll that corresponds  to the serial
number you give it.  You must give it S3, the least significant byte of the
serial number.
---------------------------------------------------------------------------- */
unsigned char GetAtollNum(unsigned char S3) {
	unsigned int i;
	
	for (i = 0; i < 2*NUM_ATOLLS; i++) {
		if (atollSerials[i] == S3) {
			return (i/2 + 1);
		}
	}
	
	// If we haven't returned anything
	return 0xFF;
}

/* ----------------------------------------------------------------------------
FUNCTION: MakeTeamPacket

PARAMETERS:
None

DESCRIPTION
This function compiles the packet commanding the XBee to find a teammate.  The
packet contains:
LN, TC

LN = the length of the data following (1 in this case)
TC = the team color (Red = 0xFE, Green = 0x01, unoccupied = 0x88)
---------------------------------------------------------------------------- */
void MakeTeamPacket(void) {
	packet[0] = FT_PKT_LEN;
	packet[1] = teamColor;
	
	pktLen = FT_PKT_LEN + 1; // We need to send  a total of 2 bytes
}

/* ----------------------------------------------------------------------------
FUNCTION: SetTeam

PARAMETERS:
TC = the team color (Red = 0xFE, Green = 0x01, unoccupied = 0x88)

DESCRIPTION
This function sets the module level variable  for team color in the XBee SM.
---------------------------------------------------------------------------- */
void SetTeam(unsigned char TC) {
	teamColor = TC;
}

/* ----------------------------------------------------------------------------
FUNCTION: InitXBeeSM

DESCRIPTION:
Initializes the state machine by setting the current state to IDLING
---------------------------------------------------------------------------- */
void InitXBeeSM(void) {
	currentState = ST_IDLING;
	teamColor = WHITE;
}