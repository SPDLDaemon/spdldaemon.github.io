/* ============================================================================
FILE: Initialization.c 

DESCRIPTION:
This module contains all the initialization functions for the MASTER_PIC
============================================================================ */

/* ----- INCLUDES ---------------------------------------------------------- */
#include <htc.h>
#include "Initialization.h"

/* ----- CONSTANTS --------------------------------------------------------- */


/* ----------------------------------------------------------------------------
FUNCTION: InitEUSART

This function initializes the UART hardware for communication with the security
controller.

Baud Rate = Fosc/[16(SPBRGH:SPBRG + 1)] = 9615
This particular equation applies when BRGH = 1, See pg 135 in the datasheet
---------------------------------------------------------------------------- */
void InitEUSART(void)	{
	BRGH = 1;			// Hi baud rate select bit
	SPBRG = BAUD_CONST;	// Set the baud rate
	SPEN = 1;			// Enable the serial ports
	CREN = 1;			// Enable continuous receive
	TXEN = 1;			// Enable transmit
}



/* ----------------------------------------------------------------------------
FUNCTION: InitSSP

This function initializes the SPI module.
---------------------------------------------------------------------------- */
void InitSSP (void) {
	CKE = 1;	// Data is transmitted on falling clock edge (CKP = 1)
	CKP	= 1;	// Transmit on falling edge, receive on rising, clock idles hi
	
	SSPM3 = 0;	// SSPM = 0010 Master mode
	SSPM2 = 0;	// clock = OSC/64 = (20 MHz)/64 = 312.5 KHz
	SSPM1 = 1;
	SSPM0 = 0;
	
	TRISC7 = 0;	// Configure SDO to output
	TRISB6 = 0;	// Configure SCK to output
	
	ANSEL = 0;	// Turn off analog pins
	ANSELH = 0;

	PORTC |= (SS_RFID_PIC | SS_XBEE_PIC);	// Set the SS lines HI
	TRISC &= ~(SS_RFID_PIC | SS_XBEE_PIC);	// Set the SS lines to output

	SSPEN = 1;	// Enable SSP
}

/* ----------------------------------------------------------------------------
FUNCTION: InitPins

This function initializes any Pins
---------------------------------------------------------------------------- */
void InitPins(void) {
	ANSEL = 0;	// Turn off analog pins
	ANSELH = 0;
	
	STATUS_LT = 1;	// Set debug pin (RA2) to hi
	TRISA2 = 0;	// Set debug pin to output
	
	TRISC3 = 1; // RC3 set to input, for RFID Events
	
	TRISC2 = 1; // Input for debugging
}