/* ============================================================================
FILE: SPI_SM.h
============================================================================ */

#ifndef _SPI_SM_H_
#define _SPI_SM_H_

// TEST HARNESS
//#define TEST_SPI_SM


// STATE DEFINITIONS
typedef enum {	ST_WAITING_FOR_COMMAND,
				ST_SENDING_SPI_DATA,
				ST_RECEIVING_SPI_DATA,
				ST_RECEIVING_SPI_LENGTH
} SPI_SM_State_t;

// CONSTANTS 

// PUBLIC FUNCTIONS
unsigned char SendSPI(unsigned char *ptr, unsigned char len, unsigned char slv);
unsigned char ReceiveSPI(unsigned char slv);
void RunSPI_SM(Event_t event);
SPI_SM_State_t GetStateSPI_SM(void);
void InitSPI_SM(void);
unsigned char *GetRxData(void);
unsigned char IsSPIFree(void);

#endif