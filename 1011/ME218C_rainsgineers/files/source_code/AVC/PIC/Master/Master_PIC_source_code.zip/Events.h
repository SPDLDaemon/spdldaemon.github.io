/* ============================================================================
FILE: Events.h
============================================================================ */

#ifndef _EVENTS_H_
#define _EVENTS_H_

// Event Definitions
typedef enum {	
	EV_NO_EVENT,
	EV_RFID_DATA_READY,
	EV_RECEPTION_FINISHED,
	EV_SPI_BUFFER_FULL,
	EV_TX_BUFFER_EMPTY,			// EUSART transmit buffer
	EV_RX_BUFFER_FULL,			// EUSART receive buffer	
	EV_ATOLL_SERIALS_ARRIVED,	// New atoll serials have arrived
	EV_NEW_TEAM_ASSIGNED,
	EV_RECEIVED_SPI_DATA_READY,
	EV_SPI_SEND_COMPLETE,
	EV_SK_ARRIVED				// New atoll security keys have arrived
} Event_t;

#endif