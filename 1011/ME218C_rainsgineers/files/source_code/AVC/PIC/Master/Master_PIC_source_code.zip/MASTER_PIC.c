/* ============================================================================
FILE: MASTER_PIC.c 

DESCRIPTION:
This is the code for the master pic.  It runs the RFID, security controller, 
and xbee pic state machines
============================================================================ */

/* ----- INCLUDES ---------------------------------------------------------- */
#include <htc.h>
#include "ConfigFile.h"
#include "EventChecker.h"
#include "Events.h"
#include "Initialization.h"
#include "RFIDSM.h"
#include "SecConSM.h"
#include "SPI_SM.h"
#include "XBeeSM.h"


/* ----- CONSTANTS --------------------------------------------------------- */


/* ----- VARIABLES --------------------------------------------------------- */


/* ----- PROTOTYPES -------------------------------------------------------- */
void main(void);

/* ----- PROGRAM ----------------------------------------------------------- */

/* ----------------------------------------------------------------------------
MAIN PROGRAM
---------------------------------------------------------------------------- */
void main(void) {
	Event_t event;
	
	InitSSP();
	InitPins();
	InitEventChecker();
	InitEUSART();
	InitRFIDSM();
	InitSPI_SM();
	InitSecConSM();
	InitXBeeSM();
	
	while (1) {
		event = CheckEvents();
		RunRFIDSM(event);
		RunSecConSM(event);
		RunXBeeSM(event);
		RunSPI_SM(event);
	}
}		