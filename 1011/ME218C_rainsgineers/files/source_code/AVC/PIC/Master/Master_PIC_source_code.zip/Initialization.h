/* ============================================================================
FILE: Initialization.h
============================================================================ */

#ifndef _INITIALIZATION_H_
#define _INITIALIZATION_H_

// Constants
#define BAUD_CONST 129	// We use this constant to set the baud rate

#define TRUE 1
#define FALSE 0

#define SS_RFID_PIC	0b00000001	// Slave select line for RFID PIC on PORTA
#define	SS_XBEE_PIC	0b00000010	// Slave select line for XBEE PIC on PORTA

#define DUMMY_BYTE 0xFF			// Dummy byte used for reception

#define NUM_RFID_SERIALS	3	// Length of array storing incoming RFIDSerials

#define STATUS_LT	RA2			// Use this light for debuging
#define DEBUG_PIN	RC2			// Used to input commands
#define	RFID_EVENT_PIN RC3		// Communicates events from RFID pic

// Team cards - least significany bytes
#define RED_CARD 0xEC
#define GREEN_CARD 0x5A
#define	WHITE_CARD 0x06

// Constants for team assignments
/* If you are capturing an atoll, one of these values needs to be in the TC
byte */
#define RED		0xFE
#define GREEN	0x01
#define WHITE 	0x88

// Constants for packets
#define RQ 0x66	// Request capture byte

// Public Function Prototypes
void InitEUSART(void);
void InitSSP (void);
void InitPins(void);

#endif