/* ============================================================================
FILE: RFIDSM.h 
============================================================================ */
		
#ifndef _RFIDSM_H_
#define	_RFIDSM_H_			

// Test Harness
//#define TEST_RFIDSM	
			
// State definitions
typedef enum {	// RFID State Machine
				ST_IDLING,
				ST_RX_RFID_DATA,			
} RFIDSM_State_t;



// Public Functions
void RunRFIDSM(Event_t event);
unsigned char *GetRFIDSerials(void);
void InitRFIDSM(void);

#endif