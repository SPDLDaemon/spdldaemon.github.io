/* ============================================================================
FILE: EventChecker.c 

DESCRIPTION:
This is the event checker for the MASTER_PIC.  It has a public function,
CheckEvents(), that checks various inputs for communication events and
throws out events that trickle down to the state machines.
============================================================================ */

/* ----- INCLUDES ---------------------------------------------------------- */
#include <htc.h>
#include "EventChecker.h"
#include "Events.h"
#include "Initialization.h"


/* ----- VARIABLES --------------------------------------------------------- */
static unsigned char atollSerialsArrivedFlag = 0;
static unsigned char atollSKArrivedFlag = 0;
static unsigned char newTeamAssignedFlag = 0;
static unsigned char receivedDataReadyFlag = 0;
static unsigned char sendSPICompleteFlag = 0;

/* ----------------------------------------------------------------------------
FUNCTION: CheckEvents
---------------------------------------------------------------------------- */
Event_t CheckEvents(void) {
	Event_t event = EV_NO_EVENT;
	
	// Check for events from the RFID_PIC
	if (RFID_EVENT_PIN == 1) {
		event = EV_RFID_DATA_READY;
		return event;
	}	
	
	// Check the received data ready flag
	if (receivedDataReadyFlag == 1) {
		event = EV_RECEIVED_SPI_DATA_READY;
		receivedDataReadyFlag = 0;
		return event;
	}
	
	// Check atollSerialsArrivedFlag
	if (atollSerialsArrivedFlag == 1) {
		event = EV_ATOLL_SERIALS_ARRIVED;
		atollSerialsArrivedFlag = 0;
		return event;
	}	

	// Check newTeamAssignedFlag
	if (newTeamAssignedFlag == 1) {
		event = EV_NEW_TEAM_ASSIGNED;
		newTeamAssignedFlag = 0;
		return event;
	}	
	
	// Check Atoll SK Arrived Flag
	if (atollSKArrivedFlag == 1) {
		event = EV_SK_ARRIVED;
		atollSKArrivedFlag = 0;
		return event;
	}
	
	// Check SPI send complete flag
	if (sendSPICompleteFlag == 1) {
		event = EV_SPI_SEND_COMPLETE;
		sendSPICompleteFlag = 0;
		return event;
	}
	
	// Check the SPI Buffer
	if (BF == 1) {
		PORTC |= (SS_RFID_PIC | SS_XBEE_PIC);	// Raise the Slave Select lines
		event = EV_SPI_BUFFER_FULL;	
		return event;
	}	
	
	// Check the EUSART RX Buffer
	if (RCIF == 1) {
		event = EV_RX_BUFFER_FULL;		
		return event;
	}
	
	// Check the EUSART TX buffer
	if (TXIF == 1) {
		event = EV_TX_BUFFER_EMPTY;
		return event;
	}
	
		

	return event;
}	

void InitEventChecker(void) {
	atollSerialsArrivedFlag = 0;
	atollSKArrivedFlag = 0;
	newTeamAssignedFlag = 0;
	receivedDataReadyFlag = 0;
	sendSPICompleteFlag = 0;
}	
/* ----------------------------------------------------------------------------
Setting Flag Functions
---------------------------------------------------------------------------- */
void SetAtollSerialsArrivedFlag(void) {
	atollSerialsArrivedFlag = 1;
}	

void SetAtollSKArrivedFlag(void) {
	atollSKArrivedFlag = 1;
}	

void SetNewTeamAssignedFlag(void) {
	newTeamAssignedFlag = 1;
}

void SetReceivedDataReadyFlag(void) {
	receivedDataReadyFlag = 1;
}	

void SetSendSPICompleteFlag(void) {
	sendSPICompleteFlag = 1;	
}