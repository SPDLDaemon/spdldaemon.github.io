/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| UltrasonicSensor.c
|
=============================================================================*/

/*---------------------------Include Files-----------------------------------*/
#include "UltrasonicSensor.h"
/*---------------------------Module Definitions------------------------------*/

/*---------------------------Private Function Prototypes---------------------*/

/*---------------------------Module Variables--------------------------------*/
static unsigned int current_period_1;
static unsigned int current_period_2;
static unsigned char ultrasonic_state = ULTRASONIC_FREE;

/*---------------------------Module Test Code--------------------------------*/

#ifdef TestUltrasonicSensor
#include "Timer_E128.h"

#define TEST_TIMER   0
#define _100ms       97

void main(void) {
  InitTimers(RATE_1MS);
  SetTimer(TEST_TIMER, _100ms);
  StartTimer(TEST_TIMER);
  
  InitUltrasonic();
  RequestUltrasonicData();
  (void) printf("In main\r\n");
  while( TRUE )  {
      if( IsTimerExpired(TEST_TIMER) && IsUltrasonicDataAvailable() ) {
          (void) printf("left: %d    | right: % d\r\n", GetLeftUltrasonicData(), GetRightUltrasonicData() );          
          RequestUltrasonicData();
          ResetTimer(TEST_TIMER, _100ms);
      }
  }
}
#endif // TestUltrasonicSensor


/*---------------------------Module Code-------------------------------------*/
void InitUltrasonic( void ) {
    TIM1_TSCR1 = _S12_TEN;             // turn on timer 1
    
    // Set pre-scale to /32 ==> 750 kHz, tick = 1.3 us,  overflow at 87.38ms
    // We could probably go with higher resolution, but this should work
    TIM1_TSCR2 = _S12_PR2 | _S12_PR0;  // configure the tick-rate for timer 1
}


unsigned char IsUltrasonicDataAvailable( void ) {
   if( ultrasonic_state == ULTRASONIC_FREE ) {
      return( 1 );
   } else {
      return( 0 );   
   }
}


unsigned int GetLeftUltrasonicData( void ) {
   /*
   static unsigned int last_period = 500;
   current_period_1 = (current_period_1 + last_period)/2; // average the output
   last_period = current_period_1;                        // update the last variable
   */
   return( current_period_1  );
}




unsigned int GetRightUltrasonicData( void ) {
   /*
   static unsigned int last_period = 500;   
   current_period_2 = (current_period_2 + last_period)/2;// average the output
   last_period = current_period_2;                       // update the last variable
   */
   return( current_period_2  );
}


void RequestUltrasonicData( void ) {    
    // Set up output-compare 4 to pulse 5us
    TIM1_TIOS |= _S12_IOS4;                              // set input-capture/output-compare 4 to output-compare
    TIM1_TCTL1 &= ~(_S12_OL4 | _S12_OM4);                // associate the output pin tied to this this channel (port T pin 4)
    
    // begin the pulse
    TIM1_TC4 = TIM1_TCNT + _5ms;                         // schedule first rise one period after current time in TCNT
    TIM1_TFLG1 = _S12_C4F;                               // clear OC4 flag (write a "1"!)
    DDRT |= BIT4HI;                                      // make sure pin T4 is an output
    PTT |= BIT4HI;                                       // set port T pin 4 high (the interrupt will set this low again)
    TIM1_TIE |= _S12_C4I;                                // enable IC4/OC4 interrupt


    // Set up output-compare 6 (OC6)to pulse ~5us to signal the ultrasonic circuit module to ping-and-listen-for-echo
    TIM1_TIOS |= _S12_IOS6;                              // set input-capture/output-compare 6 to output-compare
    TIM1_TCTL1 &= ~(_S12_OL6 | _S12_OM6);                // associate the output pin tied to this this channel (port T pin 6) 

    ultrasonic_state = ULTRASONIC_1_REQUEST_WAITING;     // begin the process by updating the state
}


/*---------------------------Interrupt Service Routines----------------------*/
/* 
   Interrupt:  LeftPing()
*/
void interrupt _Vec_tim1ch4 LeftPing( void ) {
    static unsigned int first_edge_1;
    TIM1_TFLG1 = _S12_C4F;                               // clear timer 1 channel 4 flag
    
    switch(ultrasonic_state) {
        case ULTRASONIC_1_REQUEST_WAITING:
            PTT &= ~BIT4HI;
            TIM1_TIOS &= ~_S12_IOS4;
            TIM1_TCTL3 &= ~_S12_EDG4B;                   // un-configure timer 1 channel 4 to capture on FALLING edge
            TIM1_TCTL3 |= _S12_EDG4A;                    // configure timer 1 channel 4 to capture on RISING edge
            DDRT &= BIT4LO;
            ultrasonic_state = ULTRASONIC_1_PULSE_WAITING;
            break;
        case ULTRASONIC_1_PULSE_WAITING:
            TIM1_TCTL3 &= ~_S12_EDG4A;                   // un-configure timer 1 channel 4 to capture on RISING edge
            TIM1_TCTL3 |= _S12_EDG4B;                    // configure timer 1 channel 4 to capture on FALLING edge
            first_edge_1 = TIM1_TC4;
            ultrasonic_state = ULTRASONIC_1_ECHO_WAITING;
            break;
        case ULTRASONIC_1_ECHO_WAITING:
            current_period_1 = TIM1_TC4 - first_edge_1;
            
            // begin the pulse for the next ultrasonic sensor, 
            // now that this one is done
            TIM1_TC6 = TIM1_TCNT + _5ms;                 // schedule first rise one period after current time in TCNT
            TIM1_TFLG1 = _S12_C6F;                       // clear OC6 flag (write a "1"!)
            DDRT |= BIT6HI;                              // make sure port T pin 6 is an output
            PTT |= BIT6HI;                               // set port T pin 6 high (the interrupt will set this low again)
            TIM1_TIE |= _S12_C6I;                        // enable IC6/OC6 interrupt
            
            ultrasonic_state = ULTRASONIC_2_REQUEST_WAITING;   // update the state to transition to the other ultrasonic
            break;
    }
}



/* 
   Interrupt:  RightPing
*/
void interrupt _Vec_tim1ch6 RightPing( void ) {
    static unsigned int last_edge_2;
    TIM1_TFLG1 = _S12_C6F;                               // clear timer 1 channel 6 flag
    
    switch(ultrasonic_state) {
        case ULTRASONIC_2_REQUEST_WAITING:       
            PTT &= ~BIT6HI;                              // lower port T pin 6
            TIM1_TIOS &= ~_S12_IOS6;                     // configure port T  pin 6 as input capture
            TIM1_TCTL3 &= ~_S12_EDG6B;                   // un-configure timer 1 channel 6 to capture on FALLING edge
            TIM1_TCTL3 |= _S12_EDG6A;                    // configure timer 1 channel 6 to capture on RISING edge            
            DDRT &= BIT6LO;                              // make sure port T pin 6 is configured as an input
            ultrasonic_state = ULTRASONIC_2_PULSE_WAITING;// update the state to wait for the ping (send pulse to request)
            break;
       case ULTRASONIC_2_PULSE_WAITING:  
            TIM1_TCTL3 &= ~_S12_EDG6A;                   // un-configure timer 1 channel 6 to capture on RISING edge
            TIM1_TCTL3 |= _S12_EDG6B;                    // configure timer 1 channel 6 to capture on FALLING edge            
            DDRT &= BIT6LO;                              // make sure port T pin 6 is an output
            last_edge_2 = TIM1_TC6;                      // capture the time the ping is sent out
            ultrasonic_state = ULTRASONIC_2_ECHO_WAITING;// update the state to wait for the echo
            break;
        case ULTRASONIC_2_ECHO_WAITING:
            current_period_2 = TIM1_TC6 - last_edge_2;   // capture the time (the difference between the ping and the echo is proportional to the distance) 
            ultrasonic_state = ULTRASONIC_FREE;          // update the state to waiting
            break;
    }
}

/*---------------------------End of File-------------------------------------*/



