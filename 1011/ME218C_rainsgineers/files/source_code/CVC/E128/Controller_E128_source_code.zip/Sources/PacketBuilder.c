/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| PacketBuilder.c
|
| Description: Interprets a message to be transmitted and assembles it into
| a single packet.  The XBee protocol limits the amount of data that can be
| sent per transmission to 100 bytes.
|
=============================================================================*/

/*---------------------------Include Files-----------------------------------*/
#include "PacketBuilder.h"

/*---------------------------Module Defines----------------------------------*/


/*---------------------------Module Helper Functions-------------------------*/

/*---------------------------Module Variables--------------------------------*/
static unsigned char packet[MAX_NUM_BYTES];   // overall packet to transmit

/*---------------------------Module Code-------------------------------------*/

#ifdef TestPacketBuilder
void main() {
    unsigned char* blah;
    int keystroke;
    unsigned int counter = 0;
    
    // values with which to build the packet
    unsigned char to_addr_hb = AVC_05_HB;
    unsigned char to_addr_lb = AVC_05_LB;
    unsigned char length_frame_hb = 0x00;
    unsigned char length_frame_lb = 0x15;
    unsigned char data[15] = {0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17};


    (void) printf("In main\r\n");

    while( TRUE ) {
      if( kbhit() != 0 ) {                // if a key has been pressed
        if( counter > MAX_NUM_BYTES ) {
            counter = 0;
        }
        keystroke = toupper( getchar() );
        (void) printf("Keyboard Hit: %c\r\n", keystroke);
        switch( keystroke ) {
            case 'H':
              BuildPacket(to_addr_hb, to_addr_lb, length_frame_hb, length_frame_lb, data);
              blah = GetPacket();              
              break;
        }
        (void) printf("packet[%d]: %X\r\n", counter, blah[counter]);
        counter++;   
      }
    }
}
#endif // TestPacketBuilder




/****************************************************************************
 Function
   BuildPacket( unsigned char to_addr_hb, unsigned char to_addr_lb, unsigned char length_frame_hb, unsigned char length_frame_lb, unsigned char* data )

 Parameters
   unsigned char to_addr_hb, the hardware address for which the message is intended, high-byte
   unsigned char to_addr_lb, the hardware address for which the message is intended, low-byte
   unsigned char length_frame_hb, the number of bytes in the frame to be transmitted measured from first byte after length byte to first byte before checksum, high-byte
   unsigned char length_frame_lb, the number of bytes in the frame to be transmitted, low-byte
   unsigned char* length_data, the number of bytes in the data array, integer from 0 to 100 as limited by the XBee protocol

 Returns
   N/A

 Description
   Assembles the provided information into a transmittable packet
 Notes
   BUG ALERT: The length_frame variable is measured as the number of 
   bytes between length_frame_lb and the checksum.
   
 Author
   S. Zacharias Leventis, 09 May 2011, 3:34
****************************************************************************/
void BuildPacket( unsigned char to_addr_hb, unsigned char to_addr_lb, unsigned char length_frame_hb, unsigned char length_frame_lb, unsigned char* data ) {
   unsigned int ii;
   unsigned int jj;
   unsigned int length_data = length_frame_hb + length_frame_lb - NUM_ME218C_BYTES;

   // API mode = 1, (configured from manufacturer)
   unsigned char API_ID          = 0x01;
   unsigned char frame_ID        = 0x00;     // 0 = disable response frame

   unsigned char options         = 0x01;     // 0x01 = disable ACKnowledgement
   unsigned char command_type    = 0xCD;     // for an AVC
   unsigned char checksum;
   
   packet[0] = START_DELIMETER;
   packet[1] = length_frame_hb;
   packet[2] = length_frame_lb;
   packet[3] = API_ID;
   packet[4] = frame_ID;
   packet[5] = to_addr_hb;
   packet[6] = to_addr_lb;
   packet[7] = options;
   packet[8] = command_type;
   for( ii = 0; ii < length_data; ++ii) {
      packet[ii+9] = data[ii];
   }
   
   /* To calculate the checksum, add all bytes (4-N) keeping only the lowest 8 bits
      of the result and subtract from 0xFF */
   checksum = API_ID + frame_ID + to_addr_hb + to_addr_lb + options + command_type;
   for( jj = 0; jj < length_data; ++jj) {
      checksum += data[jj];
   }
   checksum = 0xFF - checksum;
   packet[(9+length_data)] = checksum;
   
}


/****************************************************************************
 Function
   GetBuiltPacket()

 Parameters
   N/A

 Returns
   unsigned char* packet, 

 Description
   Returns the assembled packet
 
 Notes
   N/A
 
 Author
   S. Zacharias Leventis, 09 May 2011, 22:08
****************************************************************************/
unsigned char* GetBuiltPacket() {
   return packet;
}







