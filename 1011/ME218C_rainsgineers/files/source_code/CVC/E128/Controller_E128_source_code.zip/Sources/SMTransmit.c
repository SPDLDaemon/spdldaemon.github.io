/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| SMTransmit.h
|
=============================================================================*/

/*------------------------------Include Files--------------------------------*/
#include "SMTransmit.h"

/*------------------------------Module Defines ------------------------------*/
#define MAX_NUM_BYTES         25
#define NUM_REQD_BYTES        3           // number of required bytes, 0-based counting, by the XBee
#define LENGTH_HB_INDEX       1
#define LENGTH_LB_INDEX       2   

/*---------------------------- Module Functions -----------------------------*/
static void TransmitByte( unsigned char transmit_buffer );

/*---------------------------Module Variables--------------------------------*/
static TransmitState_t CurrentState;

static unsigned char* packet;             // get the packet to send
static unsigned int  packet_length;       // the packet length is specified to be two bytes long
static unsigned char current_byte_index;  // maximum number of bytes = 100 which is less than the 255 this data type offers
static unsigned char transmit_buffer; 

// flags
static unsigned char is_transmit_complete_flag_hi = 0;

/*---------------------------Module Code-------------------------------------*/

#ifdef TestSMTransmit
#include "EventChecker.h" // for CheckEvents() function
#include "Init.h"         // for hardware initializations

void main( void ) {
    Event_t StartupEvent = EV_ENTRY;// irrelevant (we don't care about history)
    MCU_t my_micro = E128;
    Comm_t my_protocol = UART;
   
    // values with which to build a test packet
    unsigned char to_addr_hb = AVC_05_HB;
    unsigned char to_addr_lb = AVC_05_LB;
    unsigned char length_frame_hb = 0x00;
    unsigned char length_frame_lb = 0x15;
    unsigned char data[15] = {0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17};


    (void) printf("In TestSMTransmit Main\r\n");
    
    InitCommunication(my_protocol, my_micro);
    StartTransmitSM( StartupEvent );
    
    
    BuildPacket( to_addr_hb, to_addr_lb, length_frame_hb, length_frame_lb, data);
    while( TRUE ) {
      RunTransmitSM( CheckEvents() );
    }
    
}
#endif // TestSMTransmit


/****************************************************************************
 Function
      RunTransmitSM

 Parameters
      Event_t: the event to process

 Returns
      Event_t: an event to return

 Description
      add your description here
 Notes
      uses nested switch/case to implement the machine.
 Author
      S. Zacharias Leventis, 05 May 2011, 00:10
****************************************************************************/
void RunTransmitSM( Event_t CurrentEvent ) {
   unsigned char MakeTransition = FALSE;
   TransmitState_t NextState = CurrentState;
   Event_t NewEvent;

   switch( CurrentState ) {
       case WAITING_TO_TRANSMIT:
         if( CurrentEvent != EV_NO_EVENT ) {
            switch( CurrentEvent ) {
               case EV_TX_FLAG_HI:
                  packet = GetBuiltPacket();                     // get the packet to send
                  packet_length = packet[LENGTH_HB_INDEX] + packet[LENGTH_LB_INDEX] + NUM_REQD_BYTES;       // find the size of the packet
                  current_byte_index = 0;                       // initialize the current_byte counter
                  
                  
                  NextState = SENDING_PACKET;  
                  CurrentEvent = NewEvent;
                  break;
                  // repeat cases as required for relevant events
            }
         }
         break;
      // repeat state pattern as required for other states
      case SENDING_PACKET:
         if( CurrentEvent != EV_NO_EVENT ) {
            // (void) printf("State: SENDING_PACKET\r\n");
            switch( CurrentEvent ) {
               case EV_TX_REG_EMPTY:
                  transmit_buffer = packet[current_byte_index];
                  current_byte_index++;   // increment the current data byte to transfer
                  TransmitByte( transmit_buffer );
   
                  if( current_byte_index > packet_length) {
                    NextState = WAITING_TO_TRANSMIT;
                    is_transmit_complete_flag_hi = 1;
                  } else {
                     NextState = SENDING_PACKET;
                  }
                  break;
            }
         }
         break;
    }
    CurrentState = NextState; // update the current state
}



unsigned char IsTransmitComplete( void ) {
   if(is_transmit_complete_flag_hi == TRUE) {
      is_transmit_complete_flag_hi = FALSE;     // clear the flag
      return( TRUE );
   } else {
      return( FALSE );
   }
}


/****************************************************************************
 Function
     StartTransmitSM

 Parameters
     None

 Returns
     None

 Description
     Does any required initialization for this state machine
 Notes

 Author
     S. Zacharias Leventis, 05 May 2011, 00:14
****************************************************************************/
void StartTransmitSM( void ) {
   CurrentState = WAITING_TO_TRANSMIT;
   RunTransmitSM( EV_NO_EVENT );
}

/****************************************************************************
 Function
     QueryTransmitSM

 Parameters
     None

 Returns
     TransmitState_t The current state of the Transmit state machine

 Description
     returns the current state of the Transmit state machine
 Notes

 Author
     S. Zacharias Leventis, 05 May 2011, 00:16
****************************************************************************/
TransmitState_t QueryTransmitSM( void ) {
   return( CurrentState );
}




/***************************************************************************
 private functions
 ***************************************************************************/
static void TransmitByte( unsigned char transmit_buffer ) {
      SCI1DRL = transmit_buffer;       // load in the current byte to send
}   







