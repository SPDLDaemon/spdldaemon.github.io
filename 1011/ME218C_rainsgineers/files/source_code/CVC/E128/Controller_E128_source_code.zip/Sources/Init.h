/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| Init.h
|
=============================================================================*/

#ifndef Init_H
#define Init_H
/*---------------------------Include Files-----------------------------------*/
#include "ME218_E128.h"          // for E128 register macros
#include "AD_E128.h"             // to initialize port AD pins
#include "UltrasonicSensor.h"    // for this module's initialization function



/*---------------------------Module Defines----------------------------------*/
// Baud Rate = 24MHz/(16*SBR) ~= 9600
         // So SBR[0:12] = 156 = 00000000 10011100
// For hardware initialization
#define BR_MASK_HIGH 	        0b00000000   // Baud Rate Mask High byte    
#define BR_MASK_LOW		        0b10011101   // 157 // 0b10011011   // 155 //0b10011100   // 156, Baud Rate Mask Low byte

// types of microcontrollers we for which we want to initialize SPI communication 
typedef enum {
   E128,
   PIC16F690
} MCU_t;


// types of inter-microcontroller communication protocols for which we want to initialize
typedef enum {
   UART,
   SPI      // this not yet implemented for E128
} Comm_t;

/*---------------------------Public Functions--------------------------------*/
void InitCommunication( Comm_t my_comm_protocol, MCU_t my_micro );
void InitIO( void );

#endif // Init_H
