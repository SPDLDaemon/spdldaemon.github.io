/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| PacketInterpreter.c
|
| Description: Protocol Layer.  Also directly handles result of interpretation
|  right now.
|
=============================================================================*/

/*---------------------------Include Files-----------------------------------*/
#include "PacketInterpreter.h"

/*---------------------------Module Defines----------------------------------*/
#define NUM_RECEIVE_PROTOCOL_BYTES 5      // specific to the XBee
#define ATOLL_NUM_DATA_INDEX       2      // specific to our protocol

/*---------------------------Module Helper Functions-------------------------*/

/*---------------------------Module Variables--------------------------------*/
// initialize LED's to be off
static unsigned char LED_01 = OFF_LED;
static unsigned char LED_02 = OFF_LED;
static unsigned char LED_03 = OFF_LED; 
static unsigned char LED_04 = OFF_LED; 
static unsigned char LED_05 = OFF_LED; 

static unsigned char is_atoll_captured_flag_hi = 0;   // for public getter for event checker

/*---------------------------Module Code-------------------------------------*/


/*****************************************************************************
 Function
         TurnOffDisplay

 Parameters
         N/A

 Returns
         N/A

 Description
         Sets all LED_XX module variables to off and then updates the display.
         
 Notes
         N/A
         
 Author
         S. Zacharias Leventis, 24 May 2011, 16:51
******************************************************************************/
void TurnOffDisplay( void ) {
   LED_01 = OFF_LED;
   LED_02 = OFF_LED;
   LED_03 = OFF_LED;
   LED_04 = OFF_LED;
   LED_05 = OFF_LED;
   UpdateDisplay();
}



/*****************************************************************************
 Function
         UpdateDisplay

 Parameters
         N/A

 Returns
         N/A

 Description
         Lights the LED light display according to the latest status.  Both 
         colors of the two-color LED should never be on simultaneously, but 
         in case they are, both lights are cleared before updating the current
         color.
         
 Notes
         Beacuse the pin connections from the E128 are not always grouped by 
         port, there are some messy pairings.  See circuit diagram for further
         clarification.
         
 Author
         S. Zacharias Leventis, 23 May 2011, 15:57
******************************************************************************/
void UpdateDisplay( void ) {
   // no hardware references should be at the interpretation level, but
   // easy to implement here for now
   switch(LED_01) {           // port P pin 2, port P pin 0
      case GREEN_LED:
	      PTP &= 0b11111010;   // clear the previous color(s)
         PTP |= 0b00000100;   // update the current color         
         break;
      case RED_LED:
	      PTP &= 0b11111010;   // clear the previous color(s)
         PTP |= 0b00000001;   // update the current color  
         break;
      case OFF_LED:
	      PTP &= 0b11111010;   // clear the previous color(s)
         break;
   }
   switch(LED_02) {           // port AD pin 0, port AD pin 1
      case GREEN_LED:
	      PTAD &= 0b11111100;  // clear the previous color(s)
         PTAD |= 0b00000001;  // update the current color         
         break;
      case RED_LED:
	      PTAD &= 0b11111100;  // clear the previous color(s)
         PTAD |= 0b00000010;  // update the current color
         break;
      case OFF_LED:
	      PTAD &= 0b11111100;  // clear the previous color(s)
         break;
   }
   switch(LED_03) {           // port AD pin 2, port AD pin 3
      case GREEN_LED:
	      PTAD &= 0b11110011;  // clear the previous color(s)
         PTAD |= 0b00000100;  // update the current color         
         break;
      case RED_LED:
	      PTAD &= 0b11110011;  // clear the previous color(s)
         PTAD |= 0b00001000;  // update the current color
         break;
      case OFF_LED:
	      PTAD &= 0b11110011;  // clear the previous color(s)
         break;
   }
   switch(LED_04) {           // port P pin 4, port P pin 3
      case GREEN_LED:
	      PTP  &= 0b11111101;   // clear the previous color(s)
         PTAD &= 0b11101111;
         PTP  |= 0b00000010;   // update the current color         
         break;
      case RED_LED:
	      PTP  &= 0b11111101;   // clear the previous color(s)
         PTAD &= 0b11101111;
         PTAD |= 0b00010000;  // update the current color   
         break;
      case OFF_LED:
         PTP  &= 0b11111101;   // clear the previous color(s)
         PTAD &= 0b11101111;
         break;
   }
   switch(LED_05) {           // port P pin 1, port AD pin 4
      case GREEN_LED:
	      PTP &= 0b11100111;   // clear the previous color(s)
         PTP |= 0b00010000;   // update the current color         
         break;
      case RED_LED:
	      PTP &= 0b11100111;   // clear the previous color(s)
         PTP |= 0b00001000;   // update the current color
         break;
      case OFF_LED:
	      PTP &= 0b11100111;   // clear the previous color(s)
         break;
   }
}




/*****************************************************************************
 Function
         InterpretMessage

 Parameters
         unsigned char* incoming_packet

 Returns
         N/A

 Description
         Filters a given structured packet of data according to our protocol,
         and sets the appropriate module-level variables to communicate what 
         it discovers to the event checker.        
         
 Notes
         N/A
 
 Author
         S. Zacharias Leventis, 23 May 2011, 15:57
******************************************************************************/
void InterpretMessage( unsigned char* incoming_packet ) {
   // unsigned int ii;
   // for atoll-capture message   
   unsigned char team;
   unsigned char atoll_number;
   unsigned char capture;

   // for atoll-capture message
   capture = incoming_packet[CAPTURE_INDEX];
   team = incoming_packet[TEAM_COLOR_INDEX];
   atoll_number = incoming_packet[ATOLL_NUM_INDEX];
   
   
   // if we have a successfull capture
	// and the atoll number is within a valid range
	// update the appropriate light
   if( (capture == SUCCESSFUL_CAPTURE) && (atoll_number >= ATOLL_NUM_MIN) && (atoll_number <= ATOLL_NUM_MAX) ) {
	   is_atoll_captured_flag_hi = TRUE;
	   if( team == GREEN_TEAM ) {
	      switch(atoll_number) {
	         case 1:
	            LED_01 = GREEN_LED;
	            (void) printf("team green captured atoll: 1");
	            break;
	         case 2:
	            LED_02 = GREEN_LED;
	            (void) printf("team green captured atoll: 2");
	            break;
	         case 3:
	            LED_03 = GREEN_LED;
	            (void) printf("team green captured atoll: 3");
	            break;
	         case 4:
	            LED_04 = GREEN_LED;
	            (void) printf("team green captured atoll: 4");
	            break;
	         case 5:
	            LED_05 = GREEN_LED;
   	         (void) printf("team green captured atoll: 5\r\n");
	            break;
	      }
	   } else if( team == RED_TEAM ) {
	      switch(atoll_number) {
	         case 1:
	            LED_01 = RED_LED;
	            (void) printf("team red captured atoll: 1");
	            break;
	         case 2:
	            LED_02 = RED_LED;
	            (void) printf("team red captured atoll: 2");
	            break;
	         case 3:
	            LED_03 = RED_LED;
	            (void) printf("team red captured atoll: 3");
	            break;
	         case 4:
	            LED_04 = RED_LED;
	            (void) printf("team red captured atoll: 4");
	            break;
	         case 5:
	            LED_05 = RED_LED;
	            (void) printf("team red captured atoll: 5\r\n");
               break;
	      }
	   } else {
	   	(void) printf("ERROR in PacketInterpreter.c: unrecognized team color\r\n");
	   }
   }
   
   /*
   for( ii = 0; ii < 25; ++ii ) {
      printf("incoming_packet[%d]: %X\r\n", ii, incoming_packet[ii]);
   }
   */
}


/****************************************************************************
 Function
   ParsePacket()

 Parameters
   N/A

 Returns
   N/A

 Description
   Breaks down the packet and assigns the relevant information to the message
   module variable.
 
 Notes
   DEPRECATED
 
 Author
   S. Zacharias Leventis, 09 May 2011, 11:24
****************************************************************************/


/*---------------------------Getters for the Event Checker-------------------*/
unsigned char IsAtollCapturedFlagHi( void ) {
   if(is_atoll_captured_flag_hi == TRUE) {
      is_atoll_captured_flag_hi = FALSE; // clear the flag
      return( TRUE );
   } else {
      return( FALSE );
   }
}


/*---------------------------Module Test Code--------------------------------*/
#ifdef TestPacketInterpreter

#include "Init.h"

void main( void ) {
    int keystroke;
    unsigned char ii = 1;
    
    InitIO();
    (void) printf("In PacketInterpreter main\r\n");
    
    while( TRUE ) {
      if( kbhit() != 0 ) {                // if a key has been pressed

        keystroke = toupper( getchar() );
        (void) printf("Keyboard Hit: %c\r\n", keystroke);
         
         // cycle through each LED with a keyboard hit, making sure we get the
         // expected response
         switch(ii) {
            case 1:
               TurnOffDisplay();    // this should be unnecessary since the display was just turned off
               LED_01 = GREEN_LED;
               UpdateDisplay();
               break;
            case 2:
               TurnOffDisplay();
               LED_01 = RED_LED;
               UpdateDisplay();
               break;
            case 3:
               TurnOffDisplay();
               LED_02 = GREEN_LED;
               UpdateDisplay();
               break;
            case 4:
               TurnOffDisplay();
               LED_02 = RED_LED;
               UpdateDisplay();
               break;
            case 5:
               TurnOffDisplay();
               LED_03 = GREEN_LED;
               UpdateDisplay();
               break;       
            case 6:
               TurnOffDisplay();
               LED_03 = RED_LED;
               UpdateDisplay();
               break;               
            case 7:
               TurnOffDisplay();
               LED_04 = GREEN_LED;
               UpdateDisplay();
               break;               
            case 8:
               TurnOffDisplay();
               LED_04 = RED_LED;
               UpdateDisplay();
               break;              
            case 9:
               TurnOffDisplay();
               LED_05 = GREEN_LED;
               UpdateDisplay();
               break;             
            case 10:
               TurnOffDisplay();
               LED_05 = RED_LED;
               UpdateDisplay();
               break;                 
            case 11:
               TurnOffDisplay();
               ii = 0;  // reset the counter
               break;
        }
        ii++;   
      }
    }
}
#endif // TestPacketInterpreter


/*---------------------------End of File-------------------------------------*/
