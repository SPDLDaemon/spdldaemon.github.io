/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| EventChecker.c
|
=============================================================================*/
/*---------------------------Include Files-----------------------------------*/
#include "EventChecker.h"


/*---------------------------Module Defines ---------------------------------*/
/*---------------------------Module Variables--------------------------------*/

/*---------------------------Module Code-------------------------------------*/
Event_t CheckEvents( void ) {
   unsigned char CurrentEvent = EV_NO_EVENT;
  // int keystroke;             // for debugging
   
  // general timeout
   if( IsTimerExpired(TIMEOUT_TIMER) ) {
      (void) printf("The overall state machine timed out!\r\n");
      ResetTimer(TIMEOUT_TIMER, TIMEOUT_TIME);
      
      // re-initialize everything
      StartGameSM();      
      StartTransmitSM();
      StartReceiveSM();
   }
  
   // TRANSMIT STATE MACHINE events
   else if( ((SCI1SR1 & _S12_TDRE) != 0) && (QueryTransmitSM() == SENDING_PACKET) ) {  // E128-specific: Make sure the register is clear (TDRE bit high in Status Reg 1)
      CurrentEvent = EV_TX_REG_EMPTY;
   } else if( IsTransmitComplete() ) {
      CurrentEvent = EV_TX_COMPLETE;
   }
   
   // RECEIVE STATE MACHINE events
   if( (SCI1SR1 & _S12_RDRF) != 0 ) {  // if SCI Control Register 1, receive register full
      ResetTimer(TIMEOUT_TIMER, TIMEOUT_TIME);
      CurrentEvent = EV_RX_REG_FULL;
   } else if( IsPacketAvailable() ) {
      ResetTimer(TIMEOUT_TIMER, TIMEOUT_TIME);
      InterpretMessage( GetReceivedPacket() );
      CurrentEvent = EV_PACKET_AVAIL;
   }

      
   // GAME STATE MACHINE events
   // outgoing information to transmit state machine (to AVC)
   else if( IsTransmitFlagHi() ) {
      ResetTimer(TIMEOUT_TIMER, TIMEOUT_TIME);
      CurrentEvent = EV_TX_FLAG_HI;
   } 
   // incoming information from receive state machine (from AVC)
   else if( IsAtollCapturedFlagHi() ) {
      ResetTimer(TIMEOUT_TIMER, TIMEOUT_TIME);
      CurrentEvent = EV_ATOLL_CAPTURED;
   }
   
   // game state machine created events
   else if( IsTimerExpired(PING_UPDATE_TIMER) ) {
      ResetTimer(TIMEOUT_TIMER, TIMEOUT_TIME);
      CurrentEvent = EV_PING_UPDATE_TIMER_EXP;
   } else if( IsTimerExpired(MOTOR_UPDATE_TIMER) ) {
      ResetTimer(TIMEOUT_TIMER, TIMEOUT_TIME);
      CurrentEvent = EV_MOTOR_UPDATE_TIMER_EXP;
   }
   

   
  /* 
  if( kbhit() != 0 ) {                  // if a key has been pressed
     //(void) printf("Keyboard was hit!\r\n");
     keystroke = getchar();
     switch( toupper(keystroke) ) {    // BUG ALERT: getchar() is NECESSARY to clear the array returned by kbhit()               
         // acheivable from WAITING_TO_PLAY state, test that other cannot change state from hererom here
         case 'A':
           CurrentEvent = EV_TEAM_COLOR_FOUND;
           break;
           
         // acheiveable from JOINING_TEAM state
         case 'S':
           CurrentEvent = EV_NO_TEAM_FOUND;
           break;           
         case 'D':
           CurrentEvent = EV_TEAM_FOUND;
           break;
           
         // acheivable from PLAYING state
         case 'F':
           CurrentEvent = EV_MOTOR_UPDATE_TIMER_EXP;
           break;
         case 'G':
           CurrentEvent = EV_TURNAROUND_BUTTON_PRESSED;
           break;
         case 'H':
           CurrentEvent = EV_TURNAROUND_TIMER_EXP;
           break;
         case 'J':
           CurrentEvent = EV_ATOLL_CAPTURED;
           break; 
         case 'K':
           CurrentEvent = EV_GAME_TIMER_EXP;
           break;
         
         // testing motor direction change
         case 'Q':
           ChangeMotorDirection(1,0); // left motor, reverse
           break;
         case 'W':
           ChangeMotorDirection(1,1); // left motor, forward
           break;
         case 'E':
           ChangeMotorDirection(0,0); // right motor, reverse
           break;
         case 'R':
           ChangeMotorDirection(0,1); // right motor, forward
           break;

     }
  }
   
  */

  /*
 if( kbhit() != 0 ) {                  // if a key has been pressed
     //(void) printf("Keyboard was hit!\r\n");
     keystroke = getchar();
     switch( toupper(keystroke) ) {    // BUG ALERT: getchar() is NECESSARY to clear the array returned by kbhit()
         case 'H':
           CurrentEvent = EV_TX_FLAG_HI; 
           break;
         case 'J':
           CurrentEvent = EV_TX_REG_EMPTY;
           break;
         case 'K': 
           CurrentEvent = EV_TX_COMPLETE;
           break;
         
     }
 }
 */
    
 return( CurrentEvent );
}
