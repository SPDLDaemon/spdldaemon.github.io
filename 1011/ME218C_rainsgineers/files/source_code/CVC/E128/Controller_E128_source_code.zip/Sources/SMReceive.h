/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| SMReceive.h
|
=============================================================================*/

#ifndef SMReceive_H
#define SMReceive_H

// our header files
#include "SMEvents.h"            // event definitions
#include "PacketInterpreter.h"   // to get access to GetPacket()

#include <hidef.h>        // common defines and macros
#include <mc9s12e128.h>   // derivative information
#include "ME218_E128.h"

/*----------------------Module MACROS----------------------------------------*/
//#define TestSMReceive

typedef enum {
   WAITING_TO_RECEIVE,
   RECEIVING_PACKET,
   CHECKING_RECEIVED_PACKET 
} ReceiveState_t;


/*----------------------Public Function Prototypes---------------------------*/
void RunReceiveSM( Event_t CurrentEvent );
void StartReceiveSM( void );
ReceiveState_t QueryReceiveSM( void );
unsigned char* GetReceivedPacket( void );
unsigned char IsPacketAvailable( void );

#endif // SMReceive_H