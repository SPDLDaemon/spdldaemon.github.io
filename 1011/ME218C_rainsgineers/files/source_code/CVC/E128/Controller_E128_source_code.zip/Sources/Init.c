/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| Init.c
|
=============================================================================*/

/*---------------------------Include Files-----------------------------------*/
#include "Init.h"

/*---------------------------Module Defines ---------------------------------*/


/*---------------------------Module Functions--------------------------------*/


/*---------------------------Module Variables--------------------------------*/
   


/*---------------------------Module Code-------------------------------------*/




void InitCommunication(Comm_t my_comm_protocol, MCU_t my_micro) {
   if( my_micro == E128 ) {
      if( my_comm_protocol == UART ) {
      // 1/3. Configure the Baud Rate (see declarations for mask information)
   	   SCI1BDH |= BR_MASK_HIGH;
   	   SCI1BDL = BR_MASK_LOW;
      // 2/3. Configure the SCI Control Register 1
   	   // SCI enabled in wait, eight bit data, idle line wakeup, idle bit count 
   	   //		after start, no parity
   	   //SCI1CR1 |= S12_LOOPS;	// reciever input connected externally to transmitter
   	   //SCI1CR1 |= S12_RSRC;	// reciever input connected externally to transmitter
         
         //SCI1CR1 = 0x00; // 8 data bits, no parity  
      // 3/3. Configure the SCI Control Register 2
   	   SCI1CR2 |= _S12_TE;		// enable transmitter
   	   SCI1CR2 |= _S12_RE;		// enable reciever
   	   
         (void) printf("E128 UART communication initialization successful\r\n");     
      }
      if( my_comm_protocol == SPI ) {
         (void) printf("Sorry, SPI communication initialization is not yet available on the E128\r\n");
      }
   }
   
}



void InitIO( void ) {
   // configure input/output direction of required pins
      
   // Tx heartbeat and LED_01 LED_04 and LED_05
   DDRP |= ( BIT5HI | BIT4HI | BIT3HI | BIT2HI | BIT1HI | BIT0HI );
   
   // for LED_02, LED_03, LED_05
   //DDRAD |= ( BIT4HI | BIT3HI | BIT2HI | BIT1HI | BIT0HI );
   
   ADS12_Init("AOOOOOOO");
   
   // for digital sensors (switches)
   DDRT &= ( BIT2LO & BIT1LO & BIT0LO);
   
   
   // for ultrasonic pins
   // DON'T TOUCH PTT pin 4 or 6!
   
   (void) printf("E128 I/O initialized successfully\r\n");     
}

