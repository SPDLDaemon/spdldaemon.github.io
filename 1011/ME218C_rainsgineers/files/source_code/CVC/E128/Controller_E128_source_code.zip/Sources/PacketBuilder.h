/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| PacketBuilder.h
|
=============================================================================*/

#ifndef PacketBuilder_H
#define PacketBuilder_H

#include <stdio.h>         // for printf()
#include <ctype.h>         // for character classification functions
#include <hidef.h>      	// common defines and macros
#include "ME218_E128.h"

/*----------------------Module MACROS----------------------------------------*/
//#define TestPacketBuilder

#define START_DELIMETER     0x7E
#define MAX_NUM_BYTES         25    // the maximum number of bytes our 
                                    // character array packet will ever hold 
                                    // (because we don't want to do dynamic 
                                    // array sizing)
#define NUM_ME218C_BYTES       6     // the number of bytes added to the XBee 
                                    // protocol by the ME218C communication 
                                    // committee
                                    
// XBee Addresses
// number_object_byte-type
#define CVC_01_HB           0x20
#define CVC_01_LB           0x81
#define AVC_01_HB           0x21
#define AVC_01_LB           0x81
#define CVC_02_HB           0x20
#define CVC_02_LB           0x82
#define AVC_02_HB           0x21
#define AVC_02_LB           0x82
#define CVC_03_HB           0x20
#define CVC_03_LB           0x83
#define AVC_03_HB           0x21
#define AVC_03_LB           0x83
#define CVC_04_HB           0x20
#define CVC_04_LB           0x84
#define AVC_04_HB           0x21
#define AVC_04_LB           0x84
#define CVC_05_HB           0x20
#define CVC_05_LB           0x85
#define AVC_05_HB           0x21
#define AVC_05_LB           0x85
#define CVC_06_HB           0x20
#define CVC_06_LB           0x86
#define AVC_06_HB           0x21
#define AVC_06_LB           0x86
#define CVC_07_HB           0x20
#define CVC_07_LB           0x87
#define AVC_07_HB           0x21
#define AVC_07_LB           0x87
#define CVC_08_HB           0x20
#define CVC_08_LB           0x88
#define AVC_08_HB           0x21
#define AVC_08_LB           0x88
#define CVC_09_HB           0x20
#define CVC_09_LB           0x89
#define AVC_09_HB           0x21
#define AVC_09_LB           0x89
#define CVC_10_HB           0x20
#define CVC_10_LB           0x8A
#define AVC_10_HB           0x21
#define AVC_10_LB           0x8A
#define CVC_11_HB           0x20
#define CVC_11_LB           0x8B
#define AVC_11_HB           0x21
#define AVC_11_LB           0x8B
#define CVC_12_HB           0x20
#define CVC_12_LB           0x8C
#define AVC_12_HB           0x21
#define AVC_12_LB           0x8C
#define CVC_13_HB           0x20
#define CVC_13_LB           0x8D
#define AVC_13_HB           0x21
#define AVC_13_LB           0x8D
#define CVC_14_HB           0x20
#define CVC_14_LB           0x8E
#define AVC_14_HB           0x21
#define AVC_14_LB           0x8E
#define CVC_15_HB           0x20
#define CVC_15_LB           0x8F
#define AVC_15_HB           0x21
#define AVC_15_LB           0x8F
#define BROADCAST_HB        0xFF
#define BROADCAST_LB        0xFF

// Atoll Addresses
// number_object_byte-type
#define ATOLL_01_HB         0x11
#define ATOLL_01_LB         0x11
#define ATOLL_02_HB         0x22
#define ATOLL_02_LB         0x22
#define ATOLL_03_HB         0x33
#define ATOLL_03_LB         0x33
#define ATOLL_04_HB         0x44
#define ATOLL_04_LB         0x44
#define ATOLL_05_HB         0x55
#define ATOLL_05_LB         0x55


/*----------------------Public Function Prototypes---------------------------*/
unsigned char* GetBuiltPacket();
void BuildPacket( unsigned char to_addr_hb, unsigned char to_addr_lb, unsigned char length_frame_hb, unsigned char length_frame_lb, unsigned char* data );


#endif // Packet_H






