/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| SMGame.h
|
=============================================================================*/

#ifndef SMGame_H
#define SMGame_H


#include "SMEvents.h"
#include "EventChecker.h"
#include "PacketBuilder.h"
#include "PacketInterpreter.h"       
#include "Timer_E128.h"                   // for timer library
#include "UltrasonicSensor.h"             // for ultrasonic sensor functions


/*----------------------Module MACROS----------------------------------------*/
#define TestSMGame


// Timers
#define PING_UPDATE_TIMER        0
#define MOTOR_UPDATE_TIMER       1
#define TIMEOUT_TIMER            2

// Times
#define _1ms                     1        // for "fence-post" issue, to expire each timer so we can just reset it when necessary
#define _100ms                   97       // 100ms ~= 1.024ms/tick*97ticks 
#define _200ms                   195
#define _255s                    249024   // 255s  ~= 1.024ms/tick*249024ticks
#define _2s                      1954     // 2s ~= 1.024ms/tick*1954ticks
#define _5s                      4882     // 5s ~= 1.024ms/tick*4882ticks
#define PING_UPDATE_TIME         _100ms
#define MOTOR_UPDATE_TIME        _200ms
#define TIMEOUT_TIME             _5s      // general timeout time in case caught in any state

// for scaling ultrasonic data
// pot data ranges from ~250 to 1023, mapped so most clockwise is greatest range
#define ULTRA_POT_PIN            7        // port AD, pin 7
#define POT_TALL_MIN             0
#define POT_TALL_MAX             500      
#define POT_MED_MIN              501      // 800 to 15000
#define POT_MED_MAX              750
                                          // 800 to 20000


// for motor direction
#define LEFT_MOTOR               1
#define RIGHT_MOTOR              0
#define FORWARD                  1
#define REVERSE                  0
#define FORWARD_MASK             0b10000000  // to be |'ed with
#define REVERSE_MASK             0b01111111  // to be &'ed with

              
// our protocol layer when communicating between CVC and ACV
typedef enum {
   change_DC
} Command_t;

// for Game state machine
typedef enum {
  WAITING_TO_PLAY,
  JOINING_TEAM,
  PLAYING,
  TURNING_AROUND
} GameState_t;


/*----------------------Public Function Prototypes---------------------------*/
void StartGameSM( void );
void RunGameSM( Event_t CurrentEvent );

unsigned char IsDeadmanSwitchDepressed( void );
unsigned char IsTransmitFlagHi( void );
unsigned char IsAtollCapturedFlagHi( void );

/*
unsigned char IsLeftReverseButtonDepressed( void );
unsigned char IsRightReverseButtonDepressed( void );
void ChangeMotorDirection(unsigned char motor_number, unsigned char direction);
*/


#endif // SMGame_H