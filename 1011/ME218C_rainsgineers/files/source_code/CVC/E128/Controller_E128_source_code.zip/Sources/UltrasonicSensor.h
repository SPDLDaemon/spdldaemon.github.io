/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| UltrasonicSensor.h
|
| Notes:
|     Uses timer 1, channel 4 and channel 6 which takes control of port T pin 
|     4 and port T pin 6 respectively.  The pulses are programmed to happen
|     sequentially, that is, one AFTER another to guarantee no overlap issues.
|     channel 6 was used because channel 5 had significant (~1V) noise
|
| See also: 
|     Ultrasonic_StateDiagram.pdf, Ultrasonic_Diagram.pdf, 
|     Ultrasonic_CircuitDiagram.pdf
|
=============================================================================*/
#ifndef UltrasonicSensor_H
#define UltrasonicSensor_H
/*---------------------------Include Files-----------------------------------*/
#include "ME218_E128.h"       
#include <stdio.h>            // for printf()
#include "S12eVec.h"          // for interrupt macros

#include <hidef.h>            // common defines and macros
#include <mc9s12e128.h>       // derivative information


/*---------------------------Module Defines----------------------------------*/
//#define TestUltrasonicSensor





#define _5ms                           4     // 5ms ~= 1.3ms/tick*4ticks, 
// the typical time needed to pull the ultrasonic line high to signal a 
// request for ping-echo sequence

// state for the psuedo-state machine
#define ULTRASONIC_FREE                0
#define ULTRASONIC_1_REQUEST_WAITING   1
#define ULTRASONIC_1_PULSE_WAITING     2
#define ULTRASONIC_1_ECHO_WAITING      3

#define ULTRASONIC_2_REQUEST_WAITING   4
#define ULTRASONIC_2_PULSE_WAITING     5
#define ULTRASONIC_2_ECHO_WAITING      6


/*---------------------------Public Function Prototypes----------------------*/
void InitUltrasonic( void );
void RequestUltrasonicData( void );
unsigned char IsUltrasonicDataAvailable( void );
unsigned int GetLeftUltrasonicData( void );
unsigned int GetRightUltrasonicData( void );

#endif // UltrasonicSensor_H