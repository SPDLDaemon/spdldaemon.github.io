/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| SMEvents.h
|
| Notes: see also state machine diagrams
|
=============================================================================*/


#ifndef SMEvents_H
#define SMEvents_H

typedef enum {
  // universal events
  EV_NO_EVENT,
  
  
  EV_ENTRY,
  EV_EXIT,          // not used
  EV_ENTRY_HISTORY, // not used
  
  // out of WAITING_TO_TRANSMIT state
  // FOR TRANSMIT STATE MACHINE FROM GAME
  EV_TX_FLAG_HI,

  // out of SENDING_PACKET state
  EV_TX_REG_EMPTY,
  EV_TX_COMPLETE,
  
  
  // out of WAITING_TO_RECEIVE state
  EV_RX_REG_FULL,
  
  // FOR GAME STATE MACHINE FROM RECEIVE
  EV_PACKET_AVAIL,
  
  // out of WAITING_TO_PLAY state
  EV_TEAM_COLOR_FOUND,
  
  // out of JOINING_TEAM state
  EV_NO_TEAM_FOUND,
  EV_TEAM_FOUND,
  
  // out of PLAYING state
  EV_MOTOR_UPDATE_TIMER_EXP,
  EV_TURNAROUND_BUTTON_PRESSED,
  EV_ATOLL_CAPTURED,
  EV_GAME_TIMER_EXP,
  EV_PING_UPDATE_TIMER_EXP,
  
  // out of TURNING_AROUND state
  EV_TURNAROUND_TIMER_EXP


} Event_t;

#endif // SMEvents_H

