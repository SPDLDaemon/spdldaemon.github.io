/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| Timer_E128.c
|
| Description: This is a module implementing  8 16 bit timers all using the RTI
|     timebase.
|
| Notes: Everything is done in terms of RTI Ticks, which can change from
|     application to application.
|
|
| See also: Timer_E128.h, E128_datasheet_TimerBlock.pdf 
|
|
=============================================================================*/

/*---------------------------Include Files-----------------------------------*/
#include "Timer_E128.h"

/*---------------------------Module Definitions------------------------------*/


/*---------------------------Module Variables--------------------------------*/
static Timer_t TMR_TimerArray[sizeof(Tflag_t)*8]=
                                            {{BIT0HI, 0xffff},
                                             {BIT1HI, 0xffff},
                                             {BIT2HI, 0xffff},
                                             {BIT3HI, 0xffff},
                                             {BIT4HI, 0xffff},
                                             {BIT5HI, 0xffff},
                                             {BIT6HI, 0xffff},
                                             {BIT7HI, 0xffff}};

/*
   the size of Tflag sets the number of timers, char = 8, int = 16 ...)
   to add more timers, you will need to change the data type and modify
   the initializaiton of TMR_TimerArray
*/

static Tflag_t TMR_ActiveFlags;
static Tflag_t TMR_EventFlags;
static unsigned int time;           // used by the default RTI (Real Time Interrupt) routine

/*---------------------------Private Function Prototypes---------------------*/



/*---------------------------Module Code-------------------------------------*/

void InitTimers( TimerRate_t rate ) {
   RTICTL = (unsigned char)rate;    // set RTI (Real Time Interrupt) Rate, how much time elapses per interrupt cycle
   CRGFLG = _S12_RTIF;              // clear any pending int
   CRGINT |= _S12_RTIE;             // enable the RTI int
   EnableInterrupts;                // make sure that interrupts are enabled
}


void SetTimer( unsigned char timer_number, unsigned int new_time ) {
   if( timer_number >= (sizeof(TMR_TimerArray)/sizeof(Timer_t)))
      (void) printf("Error: You tried to set a timer that doesn't exist\r\n"); 
   TMR_TimerArray[timer_number].Time = new_time;
}


void StartTimer( unsigned char timer_number ) {
   if( timer_number >= (sizeof(TMR_TimerArray)/sizeof(Timer_t))) {
      (void) printf("Error: You tried to start a timer that doesn't exist\r\n");
   }
   TMR_ActiveFlags |= TMR_TimerArray[timer_number].Mask; // set timer as active
}


void StopTimer( unsigned char timer_number ) {
   if( timer_number >= (sizeof(TMR_TimerArray)/sizeof(Timer_t))) {
      (void) printf("Error: You tried to stop a timer that doesn't exist\r\n");  
   }
   TMR_ActiveFlags &= ~TMR_TimerArray[timer_number].Mask; // set timer as inactive
}

unsigned char IsTimerActive( unsigned char timer_number ) {
   if( timer_number >= (sizeof(TMR_TimerArray)/sizeof(Timer_t)) ) {
      (void) printf("Error: You tried to check whether a nonexistent timer is active\r\n");  
   } else if( (TMR_ActiveFlags & TMR_TimerArray[timer_number].Mask)!= 0 ) {     
     return( 1 );
   } else {  
     return( 0 );
   }
}


unsigned char IsTimerExpired( unsigned char timer_number ) {
   if( timer_number >= (sizeof(TMR_TimerArray)/sizeof(Timer_t))) {
      (void) printf("Error: You tried to check whether a nonexistent timer is expired\r\n");  
   } else if( TMR_EventFlags & TMR_TimerArray[timer_number].Mask ) { // and expired
        return( 1 );
   } else {  
      return( 0 );
   }
}


void ClearExpiredTimer( unsigned char timer_number ) {
   if( timer_number >= (sizeof(TMR_TimerArray)/sizeof(Timer_t))) {
      (void) printf("Error: You tried to clear a nonexistent timer\r\n");
   } else {  
      TMR_EventFlags &= ~TMR_TimerArray[timer_number].Mask;
   }
}


void ResetTimer( unsigned char timer_number, unsigned int new_time ) {
   ClearExpiredTimer( timer_number );
   SetTimer( timer_number, new_time );
   StartTimer( timer_number );
   
   /*
   // the order in which Ed's init happens
   SetTimer( timer_number, new_time );
   ClearExpiredTimer( timer_number );
   StartTimer( timer_number );
   */
}

unsigned int GetTime( void ) {
   return( time );
}

/****************************************************************************
 Function
     TMRS12_RTI_Resp

 Parameters
     None.

 Returns
     None.

 Description
     This is the new RTI response routine to support the timer module.
     It will increment time, to maintain the functionality of the
     GetTime() timer and it will check through the active timers,
     decrementing each active timers count, if the count goes to 0, it
     will set the associated event flag and clear the active flag to
     prevent further counting.

 Notes
     None.

 Author
     J. Edward Carryer, 02/24/97 15:06
****************************************************************************/
void interrupt 7 RTI_Resp() { // why does 7 work and the macro for 7 (_Vec_rti) does not? 
unsigned char i;

   CRGFLG = _S12_RTIF;     // clear the source of the int
   ++time;                 // keep the GetTime() timer running
   if( TMR_ActiveFlags != 0 ) {
      for( i = 0; i < (sizeof(Tflag_t)*8); i++ ) {
        if( (TMR_ActiveFlags & TMR_TimerArray[i].Mask) != 0 )  // if active
            if( --TMR_TimerArray[i].Time == 0 ) {              // if timed out
                TMR_EventFlags |= TMR_TimerArray[i].Mask;      // note the event
                TMR_ActiveFlags &= ~TMR_TimerArray[i].Mask;    // stop counting
            }
      }
   }
}








/*---------------------------Module Test Harness-----------------------------*/

#ifdef TestTimer_E128

#define MS_PER_TICK        RATE_1MS // milliseconds per tick, 1/tick_rate
#define _500ms             488      // 500ms ~= 1.024ms/tick*488
#define HEARTBEAT_TIMER    1
#define HEARTBEAT_PIN      5

void main() {
   InitTimers( MS_PER_TICK );
   
   // Initialize any input/output pins
   DDRP |= 0b00100000;         // enable port P pin 5 as an output ( 1 = output, 0 = input on E128 )
   
   // set up the first timer
   SetTimer( HEARTBEAT_TIMER, _500ms );
   StartTimer( HEARTBEAT_TIMER );

   while( TRUE ) {
      if( IsTimerExpired( HEARTBEAT_TIMER ) ) {
         PTP ^= 0b00100000;                     // toggle port P pin 5
         ResetTimer( HEARTBEAT_TIMER, _500ms ); // reset the timer (immediately begins counting down)
         (void) printf("timer reset\r\n");
      }
   }
}

#endif // TestTimer_E128
/*---------------------------End of file-------------------------------------*/

