/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| EventChecker.h
|
=============================================================================*/
#ifndef EventChecker_H
#define EventChecker_H

#include <stdio.h>         // for printf()
#include <ctype.h>         // for character classification functions
#include <hidef.h>         // for common defines and macros
#include "ME218_E128.h"
#include <mc9s12e128.h>                   // derivative information

#include "SMEvents.h"     // for Event_t return type and event definitions

// for state type definitions (to compare against the output of the 
//"QueryState()" functions for Transmit state machine 
#include "SMTransmit.h"
#include "SMReceive.h"
#include "SMGame.h"

/*----------------------------Public Functions-------------------------------*/
Event_t CheckEvents( void );









#endif // EventChecker_H