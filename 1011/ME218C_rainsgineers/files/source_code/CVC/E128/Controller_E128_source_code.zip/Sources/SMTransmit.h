/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| SMTransmit.h
|
=============================================================================*/

#ifndef SMTransmit_H
#define SMTransmit_H

// our header files
#include "SMEvents.h"      // event definitions
#include "PacketBuilder.h" // to get access to GetBuiltPacket()

#include <hidef.h>         // common defines and macros
#include <mc9s12e128.h>    // derivative information
#include "ME218_E128.h"

#pragma LINK_INFO DERIVATIVE "SampleS12"	// ?
#pragma MESSAGE INFORMATION C1855			// to avoid warnings of recursion??


/*----------------------Module MACROS----------------------------------------*/
//#define TestSMTransmit

typedef enum {
  WAITING_TO_TRANSMIT,
  SENDING_PACKET 
} TransmitState_t;

/*----------------------Public Function Prototypes---------------------------*/
void RunTransmitSM( Event_t CurrentEvent );
void StartTransmitSM( void );
TransmitState_t QueryTransmitSM( void );
unsigned char IsTransmitComplete( void );


#endif // SMTransmit_H