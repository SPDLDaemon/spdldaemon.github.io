/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| SMReceive.c
|
=============================================================================*/

/*------------------------------Include Files--------------------------------*/
#include "SMReceive.h"

/*------------------------------Module Defines ------------------------------*/
#define MAX_NUM_BYTES            25
#define FRAME_LENGTH_INDEX_HB    1
#define FRAME_LENGTH_INDEX_LB    2
#define NUM_XBEE_BYTES           3 // number of additional bytes

/*---------------------------- Module Functions -----------------------------*/
static unsigned char ReadReceiveBuffer();

/*---------------------------Module Variables--------------------------------*/
static ReceiveState_t CurrentState;
static unsigned char packet[MAX_NUM_BYTES];
static unsigned char current_byte_index = 0;              // maximum number of bytes = 100 which is less than the 255 this data type offers
static unsigned int packet_length = MAX_NUM_BYTES;
static unsigned char is_packet_avail_flag_hi = 0;

/*---------------------------Module Code-------------------------------------*/


/****************************************************************************
 Function
      RunReceiveSM

 Parameters
      Event_t: the event to process

 Returns
      Event_t: an event to return

 Description
      add your description here
 Notes
      uses nested switch/case to implement the machine.
 Author
      S. Zacharias Leventis, 05 May 2011, 00:10
****************************************************************************/
void RunReceiveSM( Event_t CurrentEvent ) {
   unsigned char MakeTransition = FALSE;
   ReceiveState_t NextState = CurrentState;
   unsigned char ii;       // counter for the for-loop that clears packet
   unsigned char dummy_buffer;

   switch( CurrentState ) {
       case WAITING_TO_RECEIVE:
         if( CurrentEvent != EV_NO_EVENT ) {
            switch( CurrentEvent ) {
               case EV_RX_REG_FULL:
                  // execute any actions associated with this event in this state
                  current_byte_index = 0;   // increment the current data byte to transfer
                  dummy_buffer = SCI1DRL;
                  
                  packet[current_byte_index] = dummy_buffer;
                  current_byte_index++; 
                  
                  if( dummy_buffer == START_DELIMETER ) {
                     NextState = RECEIVING_PACKET;
                  } else {
                     // reset the array and try again
                     for( ii = 0; ii < MAX_NUM_BYTES; ++ii ) {
                        packet[ii] = 0;
                     }
                     NextState = WAITING_TO_RECEIVE;
                  }             
                  break;
            }
         }
         break;
      case RECEIVING_PACKET:
         if( CurrentEvent != EV_NO_EVENT ) {
            switch( CurrentEvent ) {
               case EV_RX_REG_FULL:
                  // execute any actions associated with the event                  
                  packet[current_byte_index] = SCI1DRL;
                  current_byte_index++;   // increment the current data byte to transfer
                  
                  // determine the packet length once we've found it
                  if( current_byte_index == 3 ) {
                     packet_length = packet[FRAME_LENGTH_INDEX_HB] + packet[FRAME_LENGTH_INDEX_LB] + NUM_XBEE_BYTES;
                  }
                  
                  if( current_byte_index > packet_length ) {
                     // cleanup
                     current_byte_index = 0;                   // reset the byte index counter
                     packet_length = MAX_NUM_BYTES;            // reset the packet length
                     is_packet_avail_flag_hi = 1;              // set a flag to inform that a packet is available

                     NextState = WAITING_TO_RECEIVE;
                  } else {
                     NextState = RECEIVING_PACKET;
                  }
                  break;
                   
            }
         }
         break;
    }
    
    CurrentState = NextState; // update the current state
}

/****************************************************************************
 Function
     StartReceiveSM

 Parameters
     None

 Returns
     None

 Description
     Does any required initialization for this state machine
 Notes

 Author
     S. Zacharias Leventis, 05 May 2011, 00:14
****************************************************************************/
void StartReceiveSM( void ) {
   // call the entry function (if any) for the ENTRY_STATE
   CurrentState = WAITING_TO_RECEIVE;
   RunReceiveSM( EV_ENTRY );
}

/****************************************************************************
 Function
     QueryReceiveSM

 Parameters
     None

 Returns
     ReceiveState_t CurrentState, the current state of the Receive state machine

 Description
     returns the current state of the Receive state machine
 Notes

 Author
     S. Zacharias Leventis, 05 May 2011, 00:16
****************************************************************************/
ReceiveState_t QueryReceiveSM( void ) {
   return( CurrentState );
}


/****************************************************************************
 Function
     IsPacketAvailable

 Parameters
     N/A

 Returns
     unsigned char, a boolean (0 or 1) describing whether a message is 
     currently available to be read.

 Description
     N/A
     
 Notes
     N/A

 Author
     S. Zacharias Leventis, 12 May 2011, 20:07
****************************************************************************/
unsigned char IsPacketAvailable( void ) {
   if(is_packet_avail_flag_hi == TRUE) {
      is_packet_avail_flag_hi = FALSE; // clear the flag
      return( TRUE );
   } else {
      return( FALSE );
   }
}


/****************************************************************************
 Function
     GetReceivedPacket

 Parameters
     N/A

 Returns
     unsigned char* packet, the current packet found by the state machine

 Description
     N/A
 Notes

 Author
     S. Zacharias Leventis, 09 May 2011, 22:00
****************************************************************************/
unsigned char* GetReceivedPacket( void ) {   
   /*
   unsigned int ii;

   for(ii = 0; ii < 25; ++ii ) {
      (void) printf("packet[%d]: %X\r\n", ii, packet[ii]);
   }
   */
   
   return( packet );
}


/*---------------------------Module Test Code--------------------------------*/
#ifdef TestSMReceive

#include "EventChecker.h" // for CheckEvents() function
#include "Init.h"         // for InitCommunication() function

void main() {
    Event_t StartupEvent = EV_ENTRY;
    MCU_t my_micro = E128;
    Comm_t my_protocol = UART;
    unsigned char* my_packet;
    unsigned char CurrentEvent;
    unsigned char ii;
    
    InitCommunication(my_protocol, my_micro);
    
    (void) printf("\r\nIn TestSMReceive main\r\n");
    
    StartReceiveSM( StartupEvent );
    
    while( TRUE ) {
      CurrentEvent = CheckEvents();
      RunReceiveSM( CurrentEvent );
      // hit the keyboard (sufficiently) after a 
      // transmission to break out and check the result
      if( CurrentEvent == EV_PACKET_AVAIL ) {
         // print the results to verify
         my_packet = GetReceivedPacket();
         for( ii = 0; ii < MAX_NUM_BYTES; ++ii ) {
            (void) printf("packet[%d]: %X\r\n", ii, my_packet[ii]);
         }
         (void) printf("\r\n\r\n");
      }
    }
}
#endif // TestSMReceive



/*---------------------------End of File-------------------------------------*/

