/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| SMGame.c
|
=============================================================================*/

/*---------------------------Include Files-----------------------------------*/
#include "SMGame.h"

/*---------------------------Module Defines ---------------------------------*/

/*---------------------------Private Functions Prototypes--------------------*/
static void SendMessage( unsigned char to_addr_hb, unsigned char to_addr_lb, unsigned char length_frame_hb, unsigned char length_frame_lb, unsigned char *data);


/*---------------------------Module Variables--------------------------------*/
static Command_t command;
static GameState_t CurrentState;

// for ultrasonic data scaling
unsigned int max_ultra;
unsigned int min_ultra;
unsigned int ultra_per_percent;
unsigned int ultra_offset;

unsigned char left_direction_mask = FORWARD_MASK;
unsigned char right_direction_mask = FORWARD_MASK;
   
// event checking flags
static unsigned char is_transmit_flag_hi = 0;
static unsigned char is_message_avail_flag_hi = 0;
static unsigned char is_team_color_found_flag_hi = 0;
static unsigned char is_no_team_found_flag_hi = 0;
static unsigned char is_team_found_flag_hi = 0;
static unsigned char is_atoll_captured_flag_hi = 0;


/*---------------------------Module Code-------------------------------------*/
#ifdef TestSMGame
#include "Init.h"                   // for InitCommunication() function
#include "SMEvents.h"
#include "EventChecker.h"
#include <hidef.h>                  // common defines and macros
#include <mc9s12e128.h>             // derivative information
#include "ME218_E128.h"
         

void main() {
    Event_t CurrentEvent;
    MCU_t my_micro = E128;
    Comm_t my_protocol = UART;
    unsigned int V_pot; 
    
    InitCommunication( my_protocol, my_micro );
    InitIO();  // initialize input-output directions for pins
    InitUltrasonic();
    
    // scale the coefficients of the linear ultrasonic data mapping
    // depending on the setting of a knob 
    V_pot = ADS12_ReadADPin(ULTRA_POT_PIN);  // set the ultrasonic scaling as a function of the 
                                             // potentiometer position on startup
   
    
    if( (POT_TALL_MIN < V_pot) && (V_pot <= POT_TALL_MAX) ) {      // tall range
      max_ultra = 10000;
      min_ultra = 800;
      ultra_per_percent = 92;
      ultra_offset = 8;       // rounded down
      (void) printf("tall range\r\n");
    } else if( (POT_MED_MIN < V_pot) && (V_pot < POT_MED_MAX) ) {    // medium range
      max_ultra = 8000;
      min_ultra = 800;
      ultra_per_percent = 72;
      ultra_offset = 11;      // rounded down
      (void) printf("medium range \r\n");
    } else {                                                         // small range
      max_ultra = 6000;
      min_ultra = 3500;
      ultra_per_percent = 29;
      ultra_offset = 120;      // rounded down
      (void) printf("small range \r\n");
    }
    
    
    // Initialize Timer Subsytem
    // prime each timer we plan on using by first expiring it. 
    // then, we can simply reset them when needed
    InitTimers( RATE_1MS );               // actually 1.024ms/tick
    SetTimer( PING_UPDATE_TIMER, _1ms );
    StartTimer( PING_UPDATE_TIMER );
    SetTimer( MOTOR_UPDATE_TIMER, _1ms );
    StartTimer( MOTOR_UPDATE_TIMER );
    SetTimer( TIMEOUT_TIMER, _1ms );
    StartTimer( TIMEOUT_TIMER );
    while( TRUE ){
      if( IsTimerExpired(PING_UPDATE_TIMER) && IsTimerExpired(MOTOR_UPDATE_TIMER) && IsTimerExpired(TIMEOUT_TIMER) ) {
         break;
      }
    }
   
    ResetTimer(TIMEOUT_TIMER, TIMEOUT_TIME);
    (void) printf("\r\nIn SMGame main\r\n");
    
    StartReceiveSM();
    StartTransmitSM();
    StartGameSM();

    while( TRUE ) {
      CurrentEvent = CheckEvents();
      RunReceiveSM( CurrentEvent );
      RunTransmitSM( CurrentEvent );
      RunGameSM( CurrentEvent );
    }
}
#endif TestSMGame



/****************************************************************************
 Function
      RunGameSM

 Parameters
      Event_t, the event to process

 Returns
      Event_t, an event to return

 Description
      N/A
      
 Notes
      N/A
      
 Author
      S. Zacharias Leventis, 12 May 2011, 21:50
****************************************************************************/
void RunGameSM( Event_t CurrentEvent ) {
   unsigned char MakeTransition = FALSE;
   GameState_t NextState = CurrentState;

   // for communication
   unsigned char to_addr_hb;
   unsigned char to_addr_lb;
   unsigned char length_frame_hb;
   unsigned char length_frame_lb;
   unsigned char data[MAX_NUM_BYTES];
   
   // for speed "knobs"
   static unsigned int left_ultrasonic_data = 0;
   static unsigned int right_ultrasonic_data = 0;
   static unsigned char left_duty_cycle = 0;
   static unsigned char right_duty_cycle = 0;
   
   // for printing
   static unsigned char ii = 0;
   
   switch( CurrentState ) {
       case WAITING_TO_PLAY:
         if( CurrentEvent != EV_NO_EVENT ) {
            switch( CurrentEvent ) {
               case EV_TEAM_COLOR_FOUND:
                  // execute any actions associated with this event in this state
    
                  (void) printf("state: WAITING_TO_PLAY\r\n");
                  (void) printf("case: EV_TEAM_COLOR_FOUND\r\n");
                  (void) printf("next state: JOINING_TEAM\r\n\r\n");

                  NextState = JOINING_TEAM;
                  break;
            }
         }
         break;
      case JOINING_TEAM:
         if( CurrentEvent != EV_NO_EVENT ) {
            switch( CurrentEvent ) {
               case EV_NO_TEAM_FOUND:
                                 
                  (void) printf("state: JOINING_TEAM\r\n");
                  (void) printf("case: EV_NO_TEAM_FOUND\r\n");
                  (void) printf("next state: PLAYING\r\n\r\n");
                  
                  NextState = PLAYING;  
                  break;
               case EV_TEAM_FOUND:
                  // display our team color
                  // turn the appropriate snow-globe on (handled in AVC)
                                 
                  // start the timers for the next state
                  ResetTimer( PING_UPDATE_TIMER, PING_UPDATE_TIME );                  
                  ResetTimer( MOTOR_UPDATE_TIMER, MOTOR_UPDATE_TIME );
                  
                  (void) printf("state: JOINING_TEAM\r\n");
                  (void) printf("case: EV_TEAM_FOUND\r\n");
                  (void) printf("next state: PLAYING\r\n\r\n");
                  
                  NextState = PLAYING; 
                  break;
            }
         }
         break;
      case PLAYING:         
         if( CurrentEvent != EV_NO_EVENT ) {
            switch( CurrentEvent ) {
               case EV_PING_UPDATE_TIMER_EXP:
                  // BUG ALERT: waiting for the switch to be depressed introduces the edge case that
                  // the first non-zero transmission is the last distance sensed
                  //if( IsDeadmanSwitchDepressed() && IsUltrasonicDataAvailable() ) {
                    if( IsUltrasonicDataAvailable() ) {
                     
                     left_ultrasonic_data = GetLeftUltrasonicData();
                     right_ultrasonic_data = GetRightUltrasonicData();
                     RequestUltrasonicData();   // begin the ping-echo process so we'll have new data the next time around
                     
                     // bracket the output of the sensor
                     if( left_ultrasonic_data > max_ultra ) {
                        left_ultrasonic_data = max_ultra;
                     } else if( left_ultrasonic_data < min_ultra ) {
                        left_ultrasonic_data = min_ultra;
                     }
                     if( right_ultrasonic_data > max_ultra ) {
                        right_ultrasonic_data = max_ultra;
                     } else if( right_ultrasonic_data < min_ultra ) {
                        right_ultrasonic_data = min_ultra;
                     }
                  }

                  ResetTimer( PING_UPDATE_TIMER, PING_UPDATE_TIME );
                  NextState = PLAYING;
                  break;     
               case EV_MOTOR_UPDATE_TIMER_EXP:
                  PTP ^= BIT5HI;    // toggle a heartbeat LED for each transmission
                  
                  // compute the duty cycle to be sent to each motor
                  if( IsDeadmanSwitchDepressed() ) {
                     left_duty_cycle = (unsigned char) ((left_ultrasonic_data/ultra_per_percent) - ultra_offset);
                     right_duty_cycle = (unsigned char) ((right_ultrasonic_data/ultra_per_percent) - ultra_offset);
                  } else {
                     left_duty_cycle = 0;
                     right_duty_cycle = 0;
                  }
                  
                  //(void) printf("rdata: %d \r\n", right_ultrasonic_data);
                  //(void) printf("left: %d | right: %d \r\n", left_duty_cycle, right_duty_cycle);
                  
                  /*
                  // incorporate the direction in bit 7 of the byte
                  if( IsLeftReverseButtonDepressed() ) {
                     left_direction_mask = REVERSE_MASK;
                  } else {
                     left_direction_mask = FORWARD_MASK;
                  }
                  if( IsRightReverseButtonDepressed() ) {
                     right_direction_mask = REVERSE_MASK;
                  } else {
                     right_direction_mask = FORWARD_MASK;
                  }
                  */
                  
                  // Transmit the message 
                  to_addr_hb = AVC_05_HB;
                  to_addr_lb = AVC_05_LB;
                  length_frame_hb = 0x00;
                  length_frame_lb = 3 + NUM_ME218C_BYTES;
                  command = change_DC;
                  data[0] = command;                                       // our command type
                  data[1] = (left_duty_cycle | FORWARD_MASK);             // left motor duty cycle and direction
                  data[2] = (right_duty_cycle | FORWARD_MASK);            // left motor duty cycle and direction

                  /*
                  if( left_direction_mask == FORWARD_MASK ) {
                     data[1] = (left_duty_cycle |= left_direction_mask);   // left motor duty cycle and direction
                  } else if(left_direction_mask == REVERSE_MASK) {
                     data[1] = (left_duty_cycle &= left_direction_mask);   // left motor duty cycle and direction
                  } else {
                     (void) printf("ERROR: left direction not recognized!\r\n");
                  }
                  if( right_direction_mask == FORWARD_MASK ) {
                     data[2] = (right_duty_cycle |= right_direction_mask);  // left motor duty cycle and direction
                  } else if(right_direction_mask == REVERSE_MASK) {
                     data[2] = (right_duty_cycle &= right_direction_mask);  // left motor duty cycle and direction
                  } else {
                     (void) printf("ERROR: right direction not recognized!\r\n");
                  }
                  */
                  
                  SendMessage(to_addr_hb, to_addr_lb, length_frame_hb, length_frame_lb, data);
                  
                  ResetTimer( MOTOR_UPDATE_TIMER, MOTOR_UPDATE_TIME );
                                    
                  NextState = PLAYING;
                  break;                        
               case EV_ATOLL_CAPTURED:                  
                  UpdateDisplay(); // light up the LED's appropriately
                  
                  /*
                  (void) printf("state: PLAYING\r\n");
                  (void) printf("case: EV_ATOLL_CAPTURED\r\n");
                  (void) printf("next state: PLAYING\r\n\r\n");
                  */
                  
                  NextState = PLAYING;  
                  break;
            }
         }
   }
   CurrentState = NextState; // update the current state
}


/*
void ChangeMotorDirection(unsigned char motor_number, unsigned char direction) {
   if(motor_number == LEFT_MOTOR){
      if( direction == FORWARD ) {
         left_direction_mask = FORWARD_MASK;
      } else if( direction == REVERSE ) {
         left_direction_mask = REVERSE_MASK;
      } else {
         (void) printf("ERROR in ChangeMotorDirection: motor not recognized!\r\n");
      }
   } else if(motor_number == RIGHT_MOTOR) {
      if( direction == FORWARD ) {
         right_direction_mask = FORWARD_MASK;
      } else if( direction == REVERSE ) {
         right_direction_mask = REVERSE_MASK;
      } else {
         (void) printf("ERROR in ChangeMotorDirection: motor not recognized!\r\n");
      }
   } else {
      (void) printf("ERROR in ChangeMotorDirection: motor not recognized!\r\n");
   }
}
*/


/****************************************************************************
 Function
     StartGameSM

 Parameters
     N/A
                                                                                                                                                             
 Returns
     N/A

 Description
     N/A
 
 Notes

 Author
     S. Zacharias Leventis, 12 May 2011, 20:55
****************************************************************************/
void StartGameSM( void ) {
   //CurrentState = WAITING_TO_PLAY;
   CurrentState = PLAYING;
   ResetTimer( PING_UPDATE_TIMER, PING_UPDATE_TIME );                  
   ResetTimer( MOTOR_UPDATE_TIMER, MOTOR_UPDATE_TIME );
   RunGameSM( EV_ENTRY );
}

/****************************************************************************
 Function
     QueryGameSM

 Parameters
     N/A

 Returns
     GameState_t The current state of the Game state machine

 Description
     N/A
     
 Notes

 Author
     S. Zacharias Leventis, 12 May 2011, 20:53
****************************************************************************/
GameState_t QueryGameSM() {
   return( CurrentState );
}


/****************************************************************************
 Function
      SendMessage

 Parameters
      N/A

 Returns
      N/A

 Description
      N/A
      
 Notes
      N/A
      
 Author
      S. Zacharias Leventis, 12 May 2011, 02:38
****************************************************************************/
static void SendMessage( unsigned char to_addr_hb, unsigned char to_addr_lb, unsigned char length_frame_hb, unsigned char length_frame_lb, unsigned char *data) {
   BuildPacket( to_addr_hb, to_addr_lb, length_frame_hb, length_frame_lb, data );
   is_transmit_flag_hi = 1;
}

// Flag Checking Public Functions
unsigned char IsTransmitFlagHi( void ) {
   if(is_transmit_flag_hi == TRUE) {
      is_transmit_flag_hi = FALSE; // clear the flag
      return( TRUE );
   } else {
      return( FALSE );
   }
}

unsigned char IsDeadmanSwitchDepressed( void ) {
   if( (PTT & BIT0HI) == 1 ) {
      return( TRUE );
   } else {
      return( FALSE );
   }
}

/*
unsigned char IsLeftReverseButtonDepressed( void ) {
   if( (PTT & BIT1HI) == 1 ) {
      return( TRUE );
   } else {
      return( FALSE );
   }
}

unsigned char IsRightReverseButtonDepressed( void ) {
   if( (PTT & BIT2HI) == 1 ) {
      return( TRUE );
   } else {
      return( FALSE );
   }
}

*/

