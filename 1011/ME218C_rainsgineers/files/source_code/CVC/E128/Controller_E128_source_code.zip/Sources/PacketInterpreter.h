/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| PacketInterpreter.h
|
=============================================================================*/

#ifndef PacketInterpreter_H
#define PacketInterpreter_H

//#include Message_H       // upper level module which gives use of GetMessage();

#include <stdio.h>         // for printf()
#include <ctype.h>         // for character classification functions
#include <hidef.h>      	// common defines and macros
#include "ME218_E128.h"
#include <mc9s12e128.h>                   // derivative information
#include <hidef.h>         // for common defines and macros
#include "SMReceive.h"  // for GetReceivedPacket() from parallel, receive state machine



/*----------------------Module MACROS----------------------------------------*/
//#define TestPacketInterpreter

#define START_DELIMETER    0x7E

// atoll capture message 
#define RED_TEAM           0xFE
#define GREEN_TEAM         0x01
#define SUCCESSFUL_CAPTURE 0xAB
#define CAPTURE_INDEX      8
#define TEAM_COLOR_INDEX   9

#define ATOLL_NUM_INDEX    10    // index of the atoll packet
#define ATOLL_NUM_MAX      5     // the maximum of the possible atoll numbers
#define ATOLL_NUM_MIN      1     // the minimum of the possible atoll numbers

#define GREEN_LED          0b10
#define RED_LED            0b01
#define OFF_LED            0b00



/*----------------------Public Function Prototypes---------------------------*/
void TurnOffDisplay( void );
void UpdateDisplay( void );
unsigned char IsAtollCapturedFlagHi( void );
void InterpretMessage( unsigned char* packet );


#endif // PacketInterpreter_H






