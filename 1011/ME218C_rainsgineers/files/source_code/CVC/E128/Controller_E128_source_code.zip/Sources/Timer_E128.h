/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| Timer_E128.h
|
=============================================================================*/
#ifndef Timer_E128_H
#define Timer_E128_H

/*---------------------------Code Level-----------------------------------*/
// Production Level
// Development Level
// Testing Level

//#define TestTimer_E128     // comment this out once sufficient testing has 
                           // proved a robust module

/*---------------------------Include Files-----------------------------------*/
#include <stdio.h>         // for printf()
#include <mc9s12e128.h>    // derivative information
#include <S12e128bits.h>   // bit definitions


/*---------------------------Module Definitions------------------------------*/
/* these assume an 8MHz OSCCLK, they are the values to be used to program
    the RTICTL regiser
 */

 /*
 RTICTL = 0yyyxxxx   // Real Time Interrupt ConTroL register
 xxxx = real-time interrupt modulus counter bits
 yyy = real-time interrupt pre-scale rate select bits
*/


typedef enum { RATE_OFF  = 0b00000000,
               RATE_1MS  = 0b00100011, // 1.024ms/clock_tick
               RATE_2MS  = 0b00110011, // 2.048ms/clock_tick
               RATE_4MS  = 0b01000011, // 4.096ms/clock_tick
               RATE_8MS  = 0b01010011, // 8.196ms/clock_tick
               RATE_16MS = 0b01100011, // 16.384ms/clock_tick
               RATE_32MS = 0b01110011  // 32.768ms/clock_tick 
} TimerRate_t;


typedef unsigned char Tflag_t;

typedef struct timer_struc {
   Tflag_t Mask;
   unsigned int Time;
} Timer_t;


/*----------------------------Public Functions-------------------------------*/
void InitTimers( TimerRate_t rate );
void StartTimer( unsigned char timer_number );
void StopTimer( unsigned char timer_number );
void ResetTimer( unsigned char timer_number, unsigned int new_time );
unsigned char IsTimerActive( unsigned char timer_number );
unsigned char IsTimerExpired( unsigned char timer_number );
void SetTimer( unsigned char timer_number, unsigned int new_time );
// not used
void ClearExpiredTimer( unsigned char timer_number );
unsigned int GetTime( void );

#endif // Timer_E128_H





