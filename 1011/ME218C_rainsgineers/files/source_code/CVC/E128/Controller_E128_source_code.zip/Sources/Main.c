/*=============================================================================
|
| ME 218C: Final Project
| Spring 2010
| Team Rainsgineers
| 
| Main.c
|
=============================================================================*/

/*---------------------------Include Files-----------------------------------*/
#include "Init.h"                         // for InitCommunication() function
#include "SMEvents.h"
#include "EventChecker.h"
#include <hidef.h>                        // common defines and macros
#include <mc9s12e128.h>                   // derivative information
#include "ME218_E128.h"

#pragma LINK_INFO DERIVATIVE "SampleS12"	// ?
#pragma MESSAGE INFORMATION C1855			// to avoid warnings of recursion??


/*---------------------------Module Defines ---------------------------------*/
//#define TestMain


/*---------------------------Module Variables--------------------------------*/


/*---------------------------Module Code-------------------------------------*/

#ifdef TestMain
void main() {
   
   //StartGameSM( EV_NO_EVENT );
   StartTransmitSM( EV_NO_EVENT );
   //StartReceiveSM( EV_NO_EVENT );

   Event_t StartupEvent = EV_ENTRY;// irrelevant (we don't care about history)
   MCU_t my_micro = E128;
   Comm_t my_protocol = UART;
   
   // values with which to build a test packet
   unsigned char to_addr_hb = AVC_05_HB;
   unsigned char to_addr_lb = AVC_05_LB;
   unsigned char length_frame_hb = 0x00;
   unsigned char length_frame_lb = 0x15;
   unsigned char data[15] = {0x09, 0x0A, 0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17};

   (void) printf("In TestSMTransmit Main\r\n");
    
   InitCommunication( my_protocol, my_micro );
   StartTransmitSM( StartupEvent );
   
   BuildPacket( to_addr_hb, to_addr_lb, length_frame_hb, length_frame_lb, data);

   while( TRUE ) {
      CurrentEvent = CheckEvents();
      
      //RunGameSM( CurrentEvent );
      
      RunTransmitSM( CurrentEvent );
      //RunReceiveSM( CurrentEvent );
   }
}


#endif



/*---------------------------End of File-------------------------------------*/
