// Flash sensor states
#define FLSH_OFF 0
#define FLSH_ON 1

void initFlash(void);

// GetFlash dummy declaration for compilation
char getFlash(void);