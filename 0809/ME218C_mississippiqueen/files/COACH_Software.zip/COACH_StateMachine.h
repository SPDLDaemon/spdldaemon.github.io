#ifndef COACH_STATEMACHINE_H
#define COACH_STATEMACHINE_H

// Master State Machine function
void MasterStateMachine(void);

#endif