#include <hidef.h>      /* common defines and macros */
#include <mc9s12e128.h>     /* derivative information */


#pragma LINK_INFO DERIVATIVE "SampleS12"

void main(void) {
  /* put your own code here */
  EnableInterrupts;
  for(;;) {} /* wait forever */
}
